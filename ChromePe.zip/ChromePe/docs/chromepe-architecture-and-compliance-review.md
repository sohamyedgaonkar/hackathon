# ChromePe Architecture and Compliance Review

## One-line positioning

**ChromePe is a desktop checkout surface for PhonePe Wallet.** It does **not** create a new payment rail or settlement system; it adds a new **client channel** on top of existing PhonePe wallet and payment infrastructure.

## Executive summary

ChromePe uses a merchant-side SDK plus a trusted Chrome extension to bring PhonePe Wallet checkout to desktop flows.

- The **merchant website** integrates the ChromePe SDK button.
- The **SDK** triggers the extension, but does not process money directly.
- The **extension** is the trusted client boundary for auth, payment confirmation, and wallet API calls.
- The **wallet and payment services** remain the system of record.
- The **success page** does not trust redirect params alone; it re-verifies the transaction through the extension against backend data.

From a leadership perspective, this is best described as a **new client experience on top of existing PhonePe systems**, not a new payment network.

---

## Architecture - technical view

### Main components

1. **Merchant website**
   - Integrates the ChromePe SDK button
   - Passes amount, receiver, currency, and redirect URL

2. **ChromePe SDK**
   - Calls `window.phonepe.request(...)`
   - Calls `window.phonepe.verifyPayment(...)` on the redirect/success page

3. **Chrome extension**
   - Injects the provider into the merchant page
   - Bridges page -> content script -> background worker
   - Owns the secure payment popup

4. **Extension popup**
   - Fetches wallet context and balance
   - Shows payment confirmation UI
   - Authenticates via Touch ID / WebAuthn with PIN fallback
   - Executes wallet payment

5. **PhonePe backend services**
   - **Wallet service**: debit, transaction history, transaction verification
   - **Payment service**: VPA validation / resolution for payee confirmation

6. **Redirect success page**
   - Gets redirect payload
   - Asks extension to verify the transaction
   - Shows verified success details only after backend-backed validation

### End-to-end flow

```text
Merchant page -> SDK button -> extension popup -> user auth -> wallet payment
-> redirect payload -> success page -> extension verification -> verified success UI
```

### Trust boundaries

- **Merchant page is untrusted**
- **Extension is the trusted client boundary**
- **Wallet and payment services are the source of truth**
- **Redirect URL is not trusted on its own**
- **Backend verification is what makes success credible**

### Data ownership

| Layer | Holds / sees |
| --- | --- |
| Merchant page | payment initiation params, redirect result, final verified result |
| SDK | request/verify bridge logic |
| Extension | wallet context, pending payment state, auth state, secure popup |
| Wallet backend | actual transaction status, ledger, amount, merchant binding, history |
| Payment backend | VPA resolution / validation data |

---

## Architecture - compliance and security view

### What is good in the current design

- Merchant page does **not** directly handle wallet JWT, PIN logic, or biometric verification logic
- User approval happens in **extension-owned UI**, not merchant DOM
- Redirect success is **verified against backend transaction data**
- P2P payee validation uses backend VPA resolution instead of blind client trust
- Auth is step-up capable: Touch ID / WebAuthn first, PIN fallback

### What is still PoC-grade

- Stage wallet JWT is stored in extension storage for demo convenience
- Success verification still depends on client-side extension orchestration
- Extension currently operates broadly on web pages and needs tighter merchant/domain scoping
- No production-grade merchant allowlisting or signed merchant intent yet
- No merchant webhook / server-to-server confirmation path yet
- Desktop auth model has not gone through formal compliance, risk, and partner review

---

## Questions a Head of Engineering will ask

### Technical architecture

| Question | Answer |
| --- | --- |
| Why use an extension plus SDK instead of only a JS SDK? | The merchant page is not a trusted environment. The extension gives us a separate trust boundary for wallet credentials, auth, and final confirmation UI. The SDK is only the trigger surface. |
| What is actually new here? | The new part is the desktop client channel and merchant integration pattern. Payment rails, wallet ledger, and verification stay in existing PhonePe systems. |
| How does payment actually happen? | Merchant site calls SDK -> SDK calls injected provider -> extension popup opens -> user authenticates -> wallet API executes payment -> result is returned -> redirect page re-verifies through backend-backed extension flow. |
| Why verify after redirect? | Redirect data alone is not trustworthy. Verification ensures the page reflects the real backend transaction and not just a browser-visible success string. |
| What is the source of truth? | The wallet backend transaction record, not redirect params or merchant UI. |
| How do you stop amount or receiver tampering? | User sees final amount and receiver in extension UI before approving. After redirect, verification cross-checks final transaction details against backend data. |
| What happens if extension is missing? | The SDK detects absence of the provider and fails gracefully instead of pretending checkout succeeded. |
| How do you handle extension reload/update issues? | The bridge detects invalidated context and can prompt reload. This already exists as part of extension lifecycle handling. |
| How scalable is this? | Most orchestration is client-side. Backend load is primarily the existing wallet/payment APIs plus a verification call after redirect. |

### Security and fraud

| Question | Answer |
| --- | --- |
| Can the merchant page steal wallet credentials? | Not by design. Merchant code talks only to the injected provider. Credentials and auth stay in the extension boundary. |
| Can a merchant fake a success page? | They can fake HTML, but not backend verification. Final success should only be trusted after extension-driven verification against backend transaction data. |
| Can success URLs be replayed? | The current PoC reduces risk through verification, but production should add one-time tokens, expiry, nonce binding, and replay protection. |
| How is user auth handled? | WebAuthn / Touch ID is primary, PIN is fallback, and session TTL is short. |
| Is this the bank UPI PIN? | No. ChromePe PIN is a local authorization layer for the extension, not the user's bank UPI PIN. |
| How are P2P payees validated? | Through backend VPA resolution using the Payment Service before confirmation. |
| Can any random website invoke checkout? | In the PoC, potentially yes if the extension is present. In production this must be restricted to onboarded/allowlisted merchants with signed requests. |
| What if merchant changes values before payment? | User still approves the final values in the extension. Production should additionally bind merchant order details server-side for stronger integrity and reconciliation. |

### Compliance / RBI / NPCI / governance

| Question | Answer |
| --- | --- |
| Is this a new payment system? | No. It is a new client/channel experience on top of existing PhonePe wallet/payment infrastructure. |
| Does this bypass existing backend controls? | No. KYC, wallet eligibility, balances, limits, and backend transaction controls remain in existing systems. |
| Does the merchant page handle regulated credentials? | No. Merchant page does not collect wallet secrets or bank UPI PIN. |
| Is biometric-only approval acceptable? | Good for PoC UX, but production would need explicit risk/compliance approval on whether WebAuthn alone is sufficient for this channel/instrument. |
| Would RBI/NPCI care about a desktop/browser channel? | Very likely yes from a governance perspective. Even if rails stay unchanged, new channel, auth surface, and merchant integration model usually require formal internal and partner review. |
| Are we exposing too much data to merchants? | For production, only minimal result data should be exposed. Some current PoC fields are more debug-oriented than production-safe. |
| Can merchants fulfill based only on redirect success? | No. Production fulfillment should depend on server-side confirmation, webhook, or verified backend status, not a browser redirect alone. |
| How does reconciliation work? | Final authority should be txn ID plus backend verification plus merchant-side order mapping. Current PoC proves UX feasibility, not full reconciliation design. |
| Any PCI concern? | Not for this wallet-only flow, since card PAN/CVV handling is not part of this path. |
| Any NPCI-specific concern? | If any production path touches UPI semantics, VPA handling, or desktop auth expectations, NPCI/bank policy review will be needed. |
| Any RBI data localization concern? | Yes, this must be reviewed carefully for logs, telemetry, relay layers, and storage locations before production. |

---

## Hard questions leadership will ask

### 1. Why is the browser extension trusted at all?

Because it is our controlled client boundary, separate from merchant DOM, and is the only place where auth and wallet access happen.

**Production caveat:** trust must be strengthened through official extension distribution, device binding, stronger key management, merchant allowlisting, and risk controls.

### 2. What proves this is not fake frontend success?

Redirect is not the source of truth. The success page asks the extension to verify the transaction, and the extension checks backend-backed wallet transaction data before showing final success.

### 3. What is the biggest production gap?

**Merchant trust and token trust.** We still need:

- merchant/domain allowlisting
- signed merchant intents
- one-time verification tokens
- server-to-server confirmation / webhook flow

### 4. What is the biggest compliance gap?

The current PoC uses extension-local demo credentials and a desktop auth model that has not yet been formally reviewed by security, compliance, risk, and partner stakeholders.

### 5. Could any website trigger payments?

In the current PoC, a site can invoke the provider if the extension is present.

**Production answer:** this must be locked to allowlisted merchants and signed checkout requests.

### 6. What if the browser is compromised?

Then the channel is unsafe like any compromised client environment. The mitigation is to keep trust anchored in backend verification, short-lived tokens, risk controls, device binding, and minimal data exposure to the merchant page.

### 7. How do merchants reconcile payments?

Not from redirect alone. Production merchants need server-side confirmation, webhook delivery, or backend verification APIs tied to merchant order IDs.

### 8. Is this shippable as-is?

No. This is a strong PoC / architecture prototype. Production requires:

- security hardening
- merchant trust model
- credential and token hardening
- compliance review
- proper merchant reconciliation

---

## Recommended leadership positioning

### Best technical explanation

The merchant integrates a lightweight ChromePe SDK button into checkout. That SDK does not process money itself; it invokes an injected provider exposed by the Chrome extension. The extension owns the trusted UX boundary: it opens the popup, fetches wallet context, authenticates the user via Touch ID or PIN, and calls existing PhonePe wallet APIs to execute the payment. On success, the SDK redirects to a merchant success page with a payment payload. That page does not trust the redirect alone; it asks the extension to verify the payment, and the extension checks the payload plus the backend transaction record before returning a verified result. So the merchant gets a simple integration model, while trust remains anchored in the extension and existing backend systems.

### Best compliance explanation

From a compliance standpoint, this project should be positioned as a **new client/channel experience** over existing PhonePe infrastructure, not a new payment rail. The merchant page is intentionally kept outside the trust boundary for credentials and authentication. User approval happens in extension-controlled UI, and backend transaction data remains the source of truth. That said, the current hackathon version is not production compliant yet: it still needs merchant allowlisting, stronger token issuance, safer credential handling, server-side reconciliation, and formal review of desktop biometric authorization under internal policy and any applicable RBI/NPCI or partner constraints.

### Best short answer to "What is this really?"

> **It is a desktop checkout channel for PhonePe Wallet, built as an SDK plus trusted browser extension, with backend verification.**  
> It is not a new payment rail. The PoC proves the UX and trust-boundary model; production would require hardening around merchant trust, credentials, compliance, and reconciliation.
