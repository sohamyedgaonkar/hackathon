# Payment History Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the hardcoded dummy "Recent activity" items on the ChromePe extension dashboard with live transaction history fetched from the PhonePe wallet API.

**Architecture:** Add a `getTransactions` function to `api.js` that calls `GET /v2/{userId}/transactions?limit=50&order=DESC`. In `popup.js`, add a `renderActivityList` helper and call it from `showDashboard`. In `popup.html`, replace the two hardcoded `activity-item` divs with a single `#activity-list` container.

**Tech Stack:** Vanilla JS ES modules (Chrome extension MV3), PhonePe Wallet REST API (stage), chrome.storage.local

---

## File Map

| File | Change |
|---|---|
| `extension/api.js` | Add `getTransactions` export |
| `extension/popup.html` | Replace static activity items with `#activity-list` div |
| `extension/popup.js` | Add `renderActivityList`, call from `showDashboard`, import `getTransactions` |

---

### Task 1: Add `getTransactions` to `api.js`

**Files:**
- Modify: `extension/api.js` (append after `p2pTransfer`)

- [ ] **Step 1: Add the function**

Open `extension/api.js` and append the following export after the `p2pTransfer` function (before the QR Onboarding section comment):

```js
export async function getTransactions({ userId }, jwt, limit = 50) {
  const response = await fetch(
    `${API_BASE}/v2/${encodeURIComponent(userId)}/transactions?limit=${limit}&order=DESC`,
    {
      method: 'GET',
      headers: buildAuthHeaders(jwt),
    },
  );

  const data = await parseResponse(response);

  return {
    success: response.ok && data?.responseCode === 'SUCCESS',
    transactions: Array.isArray(data?.transactions) ? data.transactions : [],
    responseCode: data?.responseCode || `HTTP_${response.status}`,
  };
}
```

- [ ] **Step 2: Verify the function is reachable from the browser console**

Load the extension in Chrome (`chrome://extensions` → Load unpacked → select `extension/` folder). Open the popup DevTools console and run:

```js
import('/api.js').then(m => console.log(typeof m.getTransactions));
// Expected: "function"
```

(If the extension is already loaded, reload it first.)

---

### Task 2: Replace hardcoded activity items in `popup.html`

**Files:**
- Modify: `extension/popup.html` lines 140–165 (the `<section class="stack">` containing "Recent activity")

- [ ] **Step 1: Replace the static items**

Find this block in `popup.html`:

```html
        <section class="stack">
          <div style="font-size:14px;font-weight:800;">Recent activity</div>
          <div class="activity-list">
            <div class="activity-item">
              <div class="activity-left">
                <div class="activity-icon outgoing">↗</div>
                <div>
                  <div style="font-weight:700;">merchant@phonepe</div>
                  <div class="caption">Payment • 2 mins ago</div>
                </div>
              </div>
              <div class="amount-negative">-₹500</div>
            </div>
            <div class="activity-item">
              <div class="activity-left">
                <div class="activity-icon incoming">↙</div>
                <div>
                  <div style="font-weight:700;">friend@phonepe</div>
                  <div class="caption">Received • 1 hour ago</div>
                </div>
              </div>
              <div class="amount-positive">+₹200</div>
            </div>
          </div>
        </section>
```

Replace it with:

```html
        <section class="stack">
          <div style="font-size:14px;font-weight:800;">Recent activity</div>
          <div id="activity-list" class="activity-list">
            <div class="caption">Loading transactions...</div>
          </div>
        </section>
```

- [ ] **Step 2: Verify HTML is valid**

Open `extension/popup.html` in a browser directly (`file://...`) and confirm the "Recent activity" section shows only "Loading transactions..." text with no dummy items.

---

### Task 3: Add `renderActivityList` helper to `popup.js`

**Files:**
- Modify: `extension/popup.js` — import section + new helper function

- [ ] **Step 1: Add `getTransactions` to the import**

Find the existing import at the top of `popup.js`:

```js
import {
  createQrSession,
  debitWallet,
  generateTxnId,
  getBalance,
  getQrLinkUrl,
  pollQrSession,
  interopDebitVpa,
  mapApiError,
} from './api.js';
```

Replace it with:

```js
import {
  createQrSession,
  debitWallet,
  generateTxnId,
  getBalance,
  getQrLinkUrl,
  getTransactions,
  pollQrSession,
  interopDebitVpa,
  mapApiError,
} from './api.js';
```

- [ ] **Step 2: Add helper constants and `renderActivityList` function**

Add the following block immediately after the `state` object definition (after the closing `};` of `state`):

```js
const CATEGORY_LABELS = {
  ORDER: 'Merchant payment',
  P2P: 'Wallet transfer',
  UPI_IOP_DEBIT: 'UPI send',
  UPI_IOP_CREDIT: 'UPI received',
  TOPUP: 'Top-up',
  TOPUP_REVERSAL: 'Top-up reversed',
  WITHDRAWAL: 'Withdrawal',
  WITHDRAWAL_REVERSAL: 'Withdrawal reversed',
  REFUND: 'Refund',
  REFUND_REVERSAL: 'Refund reversed',
  CASHBACK: 'Cashback',
  REVERSAL: 'Reversal',
  TOA: 'Transfer of amount',
  MOVEBACK: 'Move back',
};

function relativeTime(epochMs) {
  const diff = Date.now() - epochMs;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min${minutes === 1 ? '' : 's'} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

function renderActivityList(transactions) {
  const container = document.getElementById('activity-list');
  if (!container) return;

  // null signals a fetch error
  if (transactions === null) {
    container.innerHTML = '<div class="caption">Could not load transactions.</div>';
    return;
  }

  if (transactions.length === 0) {
    container.innerHTML = '<div class="caption">No transactions yet.</div>';
    return;
  }

  container.replaceChildren(
    ...transactions.map((tx) => {
      const isDebit = tx.transactionType === 'DEBIT';
      const isFailed = tx.transactionState !== 'SUCCESS';
      const label =
        tx.externalVpa || tx.merchantId || CATEGORY_LABELS[tx.category] || tx.category || 'Transaction';
      const categoryLabel = CATEGORY_LABELS[tx.category] || tx.category || '';
      const time = relativeTime(tx.transactionTime);
      const amountRupees = (tx.amount / 100).toFixed(2);

      const item = document.createElement('div');
      item.className = 'activity-item';
      if (isFailed) item.style.opacity = '0.5';

      item.innerHTML = `
        <div class="activity-left">
          <div class="activity-icon ${isDebit ? 'outgoing' : 'incoming'}">${isDebit ? '↗' : '↙'}</div>
          <div>
            <div style="font-weight:700;">${label}</div>
            <div class="caption">${categoryLabel ? `${categoryLabel} • ` : ''}${time}${isFailed ? ' • Failed' : ''}</div>
          </div>
        </div>
        <div class="${isFailed ? '' : isDebit ? 'amount-negative' : 'amount-positive'}">${isDebit ? '-' : '+'}₹${amountRupees}</div>
      `;

      return item;
    }),
  );
}
```

- [ ] **Step 3: Verify no syntax errors**

Open Chrome DevTools on the extension popup. The console should show no JS errors. The activity list should still show "Loading transactions..." (since we haven't wired the fetch call yet).

---

### Task 4: Wire `renderActivityList` into `showDashboard`

**Files:**
- Modify: `extension/popup.js` — `showDashboard` function

- [ ] **Step 1: Update `showDashboard` to fetch and render transactions**

Find the existing `showDashboard` function:

```js
async function showDashboard() {
  showScreen('dashboard');
  state.pendingTx = null;
  state.retryAction = null;
  state.errorCloseAction = null;

  const credentials = await getStoredCredentials();
  if (!credentials?.vpa || !credentials?.userId) {
    showScreen('credentials');
    return;
  }

  setText('dashboard-vpa', getDashboardPrimaryText(credentials));
  setText('dashboard-userid', getDashboardSecondaryText(credentials));
  setText('dashboard-initials', getDashboardAvatarText(credentials));
  populateSettingsForm(credentials);

  state.currentBalanceTab = 'wallet';
  resetBalanceTabs('wallet');
  await renderBalanceTab('wallet');
}
```

Replace it with:

```js
async function showDashboard() {
  showScreen('dashboard');
  state.pendingTx = null;
  state.retryAction = null;
  state.errorCloseAction = null;

  const credentials = await getStoredCredentials();
  if (!credentials?.vpa || !credentials?.userId) {
    showScreen('credentials');
    return;
  }

  setText('dashboard-vpa', getDashboardPrimaryText(credentials));
  setText('dashboard-userid', getDashboardSecondaryText(credentials));
  setText('dashboard-initials', getDashboardAvatarText(credentials));
  populateSettingsForm(credentials);

  state.currentBalanceTab = 'wallet';
  resetBalanceTabs('wallet');

  // Kick off balance and transaction history in parallel
  const [, txResult] = await Promise.allSettled([
    renderBalanceTab('wallet'),
    getTransactions({ userId: credentials.userId }, credentials.jwt),
  ]);

  if (txResult.status === 'fulfilled' && txResult.value.success) {
    renderActivityList(txResult.value.transactions);
  } else {
    renderActivityList(null);
  }
}
```

- [ ] **Step 2: Manual smoke test**

1. Reload the extension in Chrome
2. Open the popup — the "Recent activity" section should show real transactions from the wallet API
3. DEBIT transactions should have `↗`, negative red amount
4. CREDIT transactions should have `↙`, positive green amount
5. Failed/pending transactions should be visually muted (opacity 0.5)
6. If you have no transactions yet, it should show "No transactions yet."
7. Open DevTools → Network tab → confirm the request to `/v2/.../transactions` is made

---

### Task 5: End-to-end verification

- [ ] **Step 1: Make a payment via the extension**

Use the "Send" flow or trigger a merchant SDK payment. Complete it successfully.

- [ ] **Step 2: Return to dashboard and verify the transaction appears**

Click "Done" on the success screen. The dashboard's "Recent activity" list should immediately show the new transaction at the top with the correct amount, label, and "just now" timestamp.

- [ ] **Step 3: Verify with a direct API call (optional sanity check)**

```bash
curl -s \
  -H "Authorization: <your-jwt>" \
  "http://walletservice.nixy.stg-drove.phonepe.nb6/v2/<your-userId>/transactions?limit=5&order=DESC" \
  | python3 -m json.tool
```

Confirm the transaction from Step 1 appears in the API response and matches what is shown in the extension.
