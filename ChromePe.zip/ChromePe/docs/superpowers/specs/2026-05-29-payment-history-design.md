# Payment History Design

**Date:** 2026-05-29  
**Status:** Approved  

## Problem

The ChromePe extension dashboard shows a "Recent activity" section with hardcoded dummy data. Payments made through the extension are recorded in the PhonePe wallet service (`transaction_master` table) but the extension never fetches or displays this real history. The wallet API already exposes a paginated transaction history endpoint.

## Goal

Replace the hardcoded activity list on the dashboard with live data fetched from the wallet service, showing up to 50 of the most recent transactions.

## Architecture

### Wallet API Endpoint

```
GET /v2/{userId}/transactions?limit=50&order=DESC
Authorization: O-Bearer <jwt>
```

Returns:
```json
{
  "success": true,
  "responseCode": "SUCCESS",
  "transactions": [
    {
      "transactionId": "TXN_...",
      "amount": 9900,
      "currencyCode": "INR",
      "transactionType": "DEBIT",
      "transactionState": "SUCCESS",
      "category": "ORDER",
      "merchantId": "FXM",
      "externalVpa": null,
      "transactionTime": 1779990136056
    }
  ]
}
```

`amount` is in paise. `transactionType` is `DEBIT` or `CREDIT`. `transactionState` is `SUCCESS`, `FAILED`, or `PENDING`.

### Changes

#### 1. `extension/api.js` — new `getTransactions` function

```js
export async function getTransactions({ userId }, jwt, limit = 50) {
  const response = await fetch(
    `${API_BASE}/v2/${encodeURIComponent(userId)}/transactions?limit=${limit}&order=DESC`,
    { method: 'GET', headers: buildAuthHeaders(jwt) }
  );
  const data = await parseResponse(response);
  return {
    success: response.ok && data?.responseCode === 'SUCCESS',
    transactions: data?.transactions || [],
    responseCode: data?.responseCode || `HTTP_${response.status}`,
  };
}
```

#### 2. `extension/popup.html` — remove hardcoded items

Replace static `activity-item` divs inside `.activity-list` with a single placeholder:

```html
<div id="activity-list" class="activity-list">
  <div class="caption">Loading transactions...</div>
</div>
```

#### 3. `extension/popup.js` — render live transactions

**Import `getTransactions` from `api.js`.**

Add `renderActivityList(transactions)`:
- Clears `#activity-list`
- For each transaction, creates an `.activity-item` with:
  - Icon `↗` (outgoing, class `activity-icon outgoing`) for DEBIT, `↙` (incoming, class `activity-icon incoming`) for CREDIT
  - Label: `externalVpa` → `merchantId` → human category name (fallback chain)
  - Sub-label: human-readable category + relative time (`transactionTime` epoch ms → "X mins ago", "X hours ago", "X days ago")
  - Amount: `−₹X.XX` (class `amount-negative`) for DEBIT, `+₹X.XX` (class `amount-positive`) for CREDIT
  - Failed/pending transactions: muted opacity style on the row
- Empty state: show "No transactions yet." caption if array is empty
- Error state: show "Could not load transactions." caption on fetch failure

**Call from `showDashboard()`** after `renderBalanceTab('wallet')`:

```js
renderActivityList([]); // show loading state
const credentials = await getStoredCredentials();
try {
  const result = await getTransactions({ userId: credentials.userId }, credentials.jwt);
  renderActivityList(result.transactions);
} catch {
  renderActivityList(null); // triggers error state
}
```

## Display Logic

| Field | Display |
|---|---|
| Icon | `↗` DEBIT, `↙` CREDIT |
| Label | `externalVpa` → `merchantId` → category name |
| Sub-label | Category label + relative time |
| Amount | `−₹X.XX` DEBIT (red), `+₹X.XX` CREDIT (green) |
| Failed/Pending | Row opacity: 0.5, no colour on amount |

### Category → Human Label Map

| API Category | Display |
|---|---|
| ORDER | Merchant payment |
| P2P | Wallet transfer |
| UPI_IOP_DEBIT | UPI send |
| UPI_IOP_CREDIT | UPI received |
| TOPUP | Top-up |
| TOPUP_REVERSAL | Top-up reversed |
| WITHDRAWAL | Withdrawal |
| REFUND | Refund |
| CASHBACK | Cashback |
| REVERSAL | Reversal |
| (other) | category string as-is |

## Error Handling

- If fetch throws (network error): show "Could not load transactions." in the activity list
- If API returns non-SUCCESS responseCode: same error state
- Loading state shown immediately when `showDashboard()` is called

## Testing

1. Make a payment through the extension
2. Open the popup — "Recent activity" should list the transaction
3. Check that DEBIT shows `↗` and negative amount in red
4. Verify relative time label is correct
5. Confirm error state shows when credentials are invalid
