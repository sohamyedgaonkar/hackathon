 TOKEN='O-Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpZGVudGl0eU1hbmFnZXIiLCJ2ZXJzaW9uIjoiNC4wIiwidGlkIjoiOGE0ZjQ2NzctZjhiMS00NzE1LTkyZWMtZjgyNzI2NTYwMTJjIiwic2lkIjoiM2NjZDBiMWUtMWQxOS00YmE3LTgxZWUtYTQ4NmVhNjY5NGJhIiwiaWF0IjoxNzc5OTkwMDczLCJleHAiOjE3ODAwMDA4NzN9.OMMBMERkRYB6osXJhve7zCxKjMtlrlenZTKvTX-OAbkusjkO6lXBcOUAh9V7-sRdYhLe9IeiGuh4EEJUjT0HpQ'
 TXN_ID="HACK39485uehudffdfff444deh"
 NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

 curl -X POST \
   'http://walletservice.nixy.stg-drove.phonepe.nb6/credit/v1/topup?understandsMinKycV2=false' \
   -H "Authorization: $TOKEN" \
   -H 'Content-Type: application/json' \
   --data-raw "{
     \"merchantInformation\": {
       \"merchantId\": \"PHONEPEWALLETTOPUP\"
     },
     \"walletInformation\": {
       \"walletId\": \"W2602031505158102534238\",
       \"userId\": \"U2602031504530168449331\",
       \"kycType\": \"FULL_KYC_V2\"
     },
     \"amount\": 895000,
     \"currencyCode\": \"INR\",
     \"transactionId\": \"$TXN_ID\",
     \"context\": {
       \"merchantTransactionId\": \"$TXN_ID\",
       \"topupPaymentInstrument\": \"CREDIT_CARD\",
       \"topupAccountType\": \"CREDIT\",
       \"topupProcessingRail\": \"PG\",
       \"paymentReference\": \"$TXN_ID\",
       \"source\": \"NEXUS\",
       \"autoTopup\": false
     },
     \"transactionTime\": \"$NOW\"
   }"