# ChromePe — Copilot Instructions

A PhonePe-inspired UPI payments Android app built with React Native (TypeScript). All screens use mock/in-memory data except the **Delegate Pay** flow, which talks to a real Cloudflare relay worker.

## Commands

### React Native app (root)
```bash
npm run start           # Start Metro bundler
npm run android         # Build & install on Android device/emulator
npm run lint            # ESLint
npm test                # Run all Jest tests
npx jest --testPathPattern="chromePeMvp"  # Run a single test file
```

### Delegate server (server/)
```bash
cd server && npm start      # Start mock merchant server on :3000
cd server && npm run dev    # Start with --watch
```

## Architecture

### Two separate Node projects
- **Root** — React Native app (`package.json` at root)
- **`server/`** — standalone Express server that acts as a mock merchant; has its own `node_modules` and `package.json`

### App startup sequence (`App.tsx`)
1. Shows `SplashScreen` → transitions to main navigation
2. Intercepts `chromepe://link?session=<id>` deep links to render `DeviceLinkScreen` (QR device pairing) before the main navigator mounts
3. Starts `paymentPoller` on foreground, stops it on background

### Navigation structure
- **`RootStack`** (root-level modals)
  - `MainTabs` — 5-tab bottom navigator
    - `HomeTab` → nested `HomeStack` (Home → SendMoney / Recharge / Bills)
    - `ScanTab`, `HistoryTab` (nested stack → TransactionDetail), `WalletTab`, `ProfileTab`
  - `DelegatePay` (modal) → `BankSelect` (modal) → `PinEntry` (modal)

All navigation param types are exported from `src/navigation/AppNavigator.tsx`.

### Mock data vs real data
- `src/data/mockData.ts` — static seed data (User, Transaction, Contact, Bank, MobilePlan, BillCategory interfaces + exported constants used for display)
- `src/data/transactionStore.ts` — mutable in-memory array seeded from `mockData`; use `addTransaction()` / `getTransactions()` for runtime changes
- `src/data/user.json` — **real** user identity (VPA, userId, phone); used by `paymentPoller` for Cloudflare polling — do not use `currentUser` from `mockData` for anything that involves the relay

### Delegate Pay flow (the only real network path)
`paymentPoller.ts` polls `https://chromepe-relay.chromepe-relay.workers.dev/payment/pending?vpa=<vpa>` every 4 seconds. When a pending payment arrives:
1. A local `@notifee` notification is fired (params serialized into `android.tag`)
2. The in-app callback navigates directly to `DelegatePayScreen`
3. User edits amount (optional) → `BankSelect` → `PinEntry`

`server/index.js` initiates payments by POSTing to the same Cloudflare relay (`/payment/initiate`). The relay is the single source of truth for payment state.

## Key Conventions

- **Screen props pattern**: screens receive typed `navigation` and `route` props using `NativeStackNavigationProp<ParamList, 'ScreenName'>` and `RouteProp<ParamList, 'ScreenName'>` — always import param types from `AppNavigator.tsx`
- **Styling**: all styles are defined with `StyleSheet.create` at the bottom of each screen/component file; no shared style utilities
- **Colors**: use `colors` from `src/theme/colors.ts` (`primary: '#5f259f'`, etc.) — do not hard-code brand colors
- **Icons**: `react-native-vector-icons/MaterialIcons` throughout; icon names follow Material Icons naming
- **`SafeAreaView`**: import from `react-native-safe-area-context`, not from `react-native`; use `edges={['bottom']}` on screens inside the navigator (the top is handled by the header)
- **Notification params**: `DelegatePayParams` are serialized as JSON into `notification.android.tag` — any change to `DelegatePayParams` type must stay JSON-serializable
- **Polling dedup**: `shownTxnIds` (a module-level `Set`) in `paymentPoller.ts` prevents duplicate notifications per `txnId` within a session
