import 'react-native-gesture-handler';
import React, {useState, useEffect, useRef} from 'react';
import {Linking, AppState, AppStateStatus} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import AppNavigator from './src/navigation/AppNavigator';
import SplashScreen from './src/screens/SplashScreen';
import DeviceLinkScreen from './src/screens/DeviceLinkScreen';
import {navigationRef} from './src/navigation/navigationRef';
import type {DelegatePayParams} from './src/navigation/AppNavigator';
import {
  startPolling,
  stopPolling,
  registerForegroundNotificationHandler,
  handleInitialNotification,
  requestNotificationPermission,
} from './src/services/paymentPoller';
import {
  NotificationProvider,
  setGlobalNotificationAdder,
  useNotifications,
} from './src/context/NotificationContext';

/**
 * Parse a standard UPI QR deep link.
 * Format: upi://pay?pa=vpa&pn=payeeName&am=amount&tn=description&cu=INR&mc=mcc
 */
function parseUpiLink(url: string): DelegatePayParams | null {
  try {
    // Replace upi:// with https:// so URL constructor can parse it
    const normalized = url.replace('upi://', 'https://upi.app/');
    const parsed = new URL(normalized);
    const vpa = parsed.searchParams.get('pa') ?? '';
    const merchantName = parsed.searchParams.get('pn') ?? vpa.split('@')[0] ?? vpa;
    const amount = Number(parsed.searchParams.get('am') ?? 0);
    const description = parsed.searchParams.get('tn') ?? '';
    const txnId = `QR${Date.now()}`;
    if (!vpa) return null;
    return {amount, vpa, merchantName, txnId, description};
  } catch {
    return null;
  }
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [linkSessionId, setLinkSessionId] = useState<string | null>(null);
  const pendingPayRef = useRef<DelegatePayParams | null>(null);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);

  const navigateToPayScreen = (params: DelegatePayParams) => {
    setShowSplash(false);
    setLinkSessionId(null);
    if (navigationRef.isReady()) {
      navigationRef.navigate('DelegatePay', params);
    } else {
      pendingPayRef.current = params;
    }
  };

  const handlePaymentFound = (params: DelegatePayParams) => {
    navigateToPayScreen(params);
  };

  useEffect(() => {
    // Request OS notification permission (Android 13+)
    requestNotificationPermission();

    const handleDeepLink = (event: {url: string}) => {
      const url = event.url;

      // --- UPI QR code: upi://pay?pa=vpa&pn=name&am=amount&tn=desc&cu=INR ---
      if (url.startsWith('upi://pay')) {
        const params = parseUpiLink(url);
        if (params) {
          navigateToPayScreen(params);
        }
        return;
      }

      // --- ChromePe device-link QR (chromepe://link) — unchanged ---
      if (url.startsWith('chromepe://link')) {
        const sessionMatch = url.match(/session=([^&]+)/);
        if (sessionMatch) {
          setLinkSessionId(sessionMatch[1]);
        }
      }
    };

    Linking.getInitialURL().then(url => {
      if (url) handleDeepLink({url});
    });
    const linkSub = Linking.addEventListener('url', handleDeepLink);

    // --- Polling for delegate payments ---
    startPolling(handlePaymentFound);

    const appStateSub = AppState.addEventListener(
      'change',
      (nextState: AppStateStatus) => {
        if (appStateRef.current !== 'active' && nextState === 'active') {
          startPolling(handlePaymentFound);
        } else if (nextState === 'background' || nextState === 'inactive') {
          stopPolling();
        }
        appStateRef.current = nextState;
      },
    );

    // --- Foreground OS notification press handler ---
    const unsubNotif = registerForegroundNotificationHandler(handlePaymentFound);

    return () => {
      linkSub.remove();
      appStateSub.remove();
      stopPolling();
      unsubNotif();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNavReady = async () => {
    if (pendingPayRef.current) {
      navigationRef.navigate('DelegatePay', pendingPayRef.current);
      pendingPayRef.current = null;
    }
    await handleInitialNotification(handlePaymentFound);
  };

  if (linkSessionId) {
    return (
      <SafeAreaProvider>
        <DeviceLinkScreen
          key={linkSessionId}
          sessionId={linkSessionId}
          onComplete={() => setLinkSessionId(null)}
          onCancel={() => setLinkSessionId(null)}
        />
      </SafeAreaProvider>
    );
  }

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <SafeAreaProvider>
      <NotificationProvider>
        <NotificationBridge />
        <NavigationContainer ref={navigationRef} onReady={handleNavReady}>
          <AppNavigator />
        </NavigationContainer>
      </NotificationProvider>
    </SafeAreaProvider>
  );
}

/**
 * Lives inside NotificationProvider — wires addNotification into the
 * module-level bridge used by paymentPoller (outside React).
 */
function NotificationBridge() {
  const {addNotification} = useNotifications();
  useEffect(() => {
    setGlobalNotificationAdder(addNotification);
    return () => setGlobalNotificationAdder(() => {});
  }, [addNotification]);
  return null;
}
