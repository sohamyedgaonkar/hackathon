# Delegate Pay Flow Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a merchant-initiated (delegate) payment flow where a Node.js server sends a pay request to the ChromePe app via deep link, the app guides the user through amount confirmation → bank selection → PIN entry → success, and sends a callback to the server.

**Architecture:** A Node.js/Express server on port 3000 triggers `adb shell am start` with a `chromepe://pay?...` deep link. The React Native app handles that link via `Linking` API, navigates to a modal payment flow on top of the existing tab navigator (using a RootStack + global navigation ref), and on success POSTs a callback to `http://10.0.2.2:3000/payment-callback` (Android emulator's alias for host `localhost`).

**Tech Stack:** Node.js + Express (server), React Native Linking API, React Navigation native-stack (RootStack modal flow), TypeScript

---

## File Map

**New files:**
- `server/package.json` — Express server dependencies
- `server/index.js` — Express server: initiate-payment endpoint, callback receiver, serves dashboard HTML
- `server/public/index.html` — Simple web UI to trigger a test payment
- `src/navigation/navigationRef.ts` — Global navigation ref for navigating outside of component tree (deep link handler in App.tsx)
- `src/data/transactionStore.ts` — Mutable transaction list module; `addTransaction()` + `getTransactions()` so delegate-pay transactions appear in history
- `src/screens/DelegatePayScreen.tsx` — Shows merchant VPA at top + pre-filled amount, "Proceed to Pay" CTA
- `src/screens/BankSelectScreen.tsx` — List of linked bank accounts to pay from
- `src/screens/PinEntryScreen.tsx` — 6-dot PIN entry (mock), fires success + callback

**Modified files:**
- `src/navigation/AppNavigator.tsx` — Wrap existing tabs in a RootStack; add DelegatePay, BankSelect, PinEntry as modal screens; export `RootStackParams`
- `App.tsx` — Use navigationRef; handle `chromepe://pay` deep link and navigate to DelegatePay screen
- `src/screens/HistoryScreen.tsx` — Import from `transactionStore` instead of static `mockData.ts`

---

## Task 1: Create transaction store

**Files:**
- Create: `src/data/transactionStore.ts`
- Modify: `src/screens/HistoryScreen.tsx` (line 6: change import)

- [ ] **Step 1: Create `src/data/transactionStore.ts`**

```typescript
import {transactions as seedData, Transaction} from './mockData';

// Mutable in-memory store seeded with mock data
const store: Transaction[] = [...seedData];

export function getTransactions(): Transaction[] {
  return store;
}

export function addTransaction(txn: Transaction): void {
  store.unshift(txn); // newest first
}
```

- [ ] **Step 2: Update HistoryScreen to use store**

In `src/screens/HistoryScreen.tsx`, replace:
```typescript
import {transactions} from '../data/mockData';
```
with:
```typescript
import {getTransactions} from '../data/transactionStore';
```

Then replace every reference to `transactions` (there is one: in the `.filter()` call) with `getTransactions()`:
```typescript
const filtered = getTransactions().filter(t => {
```

- [ ] **Step 3: Commit**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay
git add src/data/transactionStore.ts src/screens/HistoryScreen.tsx
git commit -m "feat: add mutable transaction store

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 2: Add global navigation ref

**Files:**
- Create: `src/navigation/navigationRef.ts`
- Modify: `App.tsx` (pass ref to NavigationContainer)

- [ ] **Step 1: Create `src/navigation/navigationRef.ts`**

```typescript
import {createNavigationContainerRef} from '@react-navigation/native';
import type {RootStackParams} from './AppNavigator';

export const navigationRef = createNavigationContainerRef<RootStackParams>();
```

> Note: `RootStackParams` will be defined in Task 3. This file references it; TypeScript will not complain until we try to build. Create this file first, then Task 3 will satisfy the type.

- [ ] **Step 2: Pass ref to NavigationContainer in App.tsx**

In `App.tsx`, add import:
```typescript
import {navigationRef} from './src/navigation/navigationRef';
```

Change the `<NavigationContainer>` JSX line from:
```typescript
      <NavigationContainer>
```
to:
```typescript
      <NavigationContainer ref={navigationRef}>
```

- [ ] **Step 3: Commit**

```bash
git add src/navigation/navigationRef.ts App.tsx
git commit -m "feat: add global navigation ref

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 3: Add RootStack to AppNavigator

**Files:**
- Modify: `src/navigation/AppNavigator.tsx`

The existing `AppNavigator` exports a bottom-tab navigator. We need to wrap it in a `RootStack` that has `MainTabs` plus three new modal screens (`DelegatePay`, `BankSelect`, `PinEntry`). The new screens don't exist yet — we add them to the stack now with placeholder imports resolved in Tasks 4–6.

- [ ] **Step 1: Update `src/navigation/AppNavigator.tsx`**

Replace the entire file with:

```typescript
import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import colors from '../theme/colors';

import HomeScreen from '../screens/HomeScreen';
import SendMoneyScreen from '../screens/SendMoneyScreen';
import ScanPayScreen from '../screens/ScanPayScreen';
import HistoryScreen from '../screens/HistoryScreen';
import TransactionDetailScreen from '../screens/TransactionDetailScreen';
import WalletScreen from '../screens/WalletScreen';
import RechargeScreen from '../screens/RechargeScreen';
import BillsScreen from '../screens/BillsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import DelegatePayScreen from '../screens/DelegatePayScreen';
import BankSelectScreen from '../screens/BankSelectScreen';
import PinEntryScreen from '../screens/PinEntryScreen';

export type HomeStackParams = {
  Home: undefined;
  SendMoney: undefined;
  Recharge: undefined;
  Bills: undefined;
};

export type HistoryStackParams = {
  History: undefined;
  TransactionDetail: {transactionId: string};
};

export type DelegatePayParams = {
  amount: number;
  vpa: string;
  merchantName: string;
  txnId: string;
};

export type RootStackParams = {
  MainTabs: undefined;
  DelegatePay: DelegatePayParams;
  BankSelect: DelegatePayParams;
  PinEntry: DelegatePayParams & {bankId: string; bankName: string};
};

const RootStack = createNativeStackNavigator<RootStackParams>();
const HomeStack = createNativeStackNavigator<HomeStackParams>();
const HistoryStack = createNativeStackNavigator<HistoryStackParams>();
const Tab = createBottomTabNavigator();

const TAB_ICONS: Record<string, string> = {
  HomeTab: 'home',
  ScanTab: 'qr-code-scanner',
  HistoryTab: 'history',
  WalletTab: 'account-balance-wallet',
  ProfileTab: 'person',
};

function renderTabBarIcon(routeName: string) {
  return ({color, size}: {color: string; size: number}) => (
    <Icon name={TAB_ICONS[routeName] ?? 'circle'} size={size} color={color} />
  );
}

function HomeStackNav() {
  return (
    <HomeStack.Navigator screenOptions={{headerShown: false}}>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen
        name="SendMoney"
        component={SendMoneyScreen}
        options={{headerShown: true, title: 'Send Money', headerTintColor: colors.primary}}
      />
      <HomeStack.Screen
        name="Recharge"
        component={RechargeScreen}
        options={{headerShown: true, title: 'Recharge', headerTintColor: colors.primary}}
      />
      <HomeStack.Screen
        name="Bills"
        component={BillsScreen}
        options={{headerShown: true, title: 'Pay Bills', headerTintColor: colors.primary}}
      />
    </HomeStack.Navigator>
  );
}

function HistoryStackNav() {
  return (
    <HistoryStack.Navigator screenOptions={{headerShown: false}}>
      <HistoryStack.Screen name="History" component={HistoryScreen} />
      <HistoryStack.Screen
        name="TransactionDetail"
        component={TransactionDetailScreen}
        options={{headerShown: true, title: 'Details', headerTintColor: colors.primary}}
      />
    </HistoryStack.Navigator>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: '#999',
        tabBarStyle: {borderTopColor: '#eee', paddingBottom: 4, height: 60},
        tabBarIcon: renderTabBarIcon(route.name),
      })}>
      <Tab.Screen name="HomeTab" component={HomeStackNav} options={{title: 'Home'}} />
      <Tab.Screen name="ScanTab" component={ScanPayScreen} options={{title: 'Scan'}} />
      <Tab.Screen name="HistoryTab" component={HistoryStackNav} options={{title: 'History'}} />
      <Tab.Screen name="WalletTab" component={WalletScreen} options={{title: 'Wallet'}} />
      <Tab.Screen name="ProfileTab" component={ProfileScreen} options={{title: 'Profile'}} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <RootStack.Navigator screenOptions={{headerShown: false}}>
      <RootStack.Screen name="MainTabs" component={MainTabs} />
      <RootStack.Screen
        name="DelegatePay"
        component={DelegatePayScreen}
        options={{presentation: 'modal', headerShown: true, title: 'Pay', headerTintColor: colors.primary}}
      />
      <RootStack.Screen
        name="BankSelect"
        component={BankSelectScreen}
        options={{presentation: 'modal', headerShown: true, title: 'Select Bank', headerTintColor: colors.primary}}
      />
      <RootStack.Screen
        name="PinEntry"
        component={PinEntryScreen}
        options={{presentation: 'modal', headerShown: true, title: 'Enter UPI PIN', headerTintColor: colors.primary}}
      />
    </RootStack.Navigator>
  );
}
```

- [ ] **Step 2: Commit (will have TS errors until Tasks 4–6 create the screen files — that's fine for git)**

```bash
git add src/navigation/AppNavigator.tsx
git commit -m "feat: add RootStack with delegate pay modal screens

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 4: Create DelegatePayScreen

**Files:**
- Create: `src/screens/DelegatePayScreen.tsx`

This screen shows the merchant name and VPA at the top (purple banner, like PhonePe), with the pre-filled amount below, and a "Proceed to Pay" button.

- [ ] **Step 1: Create `src/screens/DelegatePayScreen.tsx`**

```typescript
import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'DelegatePay'>;
  route: RouteProp<RootStackParams, 'DelegatePay'>;
};

export default function DelegatePayScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId} = route.params;
  const [editAmount, setEditAmount] = useState(String(amount));

  const proceed = () => {
    navigation.navigate('BankSelect', {
      amount: Number(editAmount) || amount,
      vpa,
      merchantName,
      txnId,
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      {/* Merchant info banner */}
      <View style={styles.merchantBanner}>
        <View style={styles.merchantIcon}>
          <Icon name="store" size={32} color="#fff" />
        </View>
        <Text style={styles.merchantName}>{merchantName}</Text>
        <Text style={styles.merchantVpa}>{vpa}</Text>
        <View style={styles.verifiedRow}>
          <Icon name="verified" size={14} color="#4CAF50" />
          <Text style={styles.verifiedText}>Verified Merchant</Text>
        </View>
      </View>

      {/* Amount */}
      <View style={styles.amountSection}>
        <Text style={styles.amountLabel}>Amount</Text>
        <View style={styles.amountRow}>
          <Text style={styles.rupeeSymbol}>₹</Text>
          <TextInput
            style={styles.amountInput}
            value={editAmount}
            onChangeText={setEditAmount}
            keyboardType="numeric"
            selectTextOnFocus
          />
        </View>
        <Text style={styles.amountHint}>Amount set by merchant</Text>
      </View>

      {/* Transaction ID */}
      <View style={styles.txnRow}>
        <Text style={styles.txnLabel}>Transaction Ref</Text>
        <Text style={styles.txnValue}>{txnId}</Text>
      </View>

      <View style={styles.spacer} />

      <TouchableOpacity
        style={[styles.proceedBtn, !editAmount && styles.btnDisabled]}
        onPress={proceed}
        disabled={!editAmount || Number(editAmount) <= 0}>
        <Text style={styles.proceedText}>Proceed to Pay  ₹{editAmount}</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#f5f5f5'},
  merchantBanner: {
    backgroundColor: colors.primary,
    alignItems: 'center',
    paddingVertical: 28,
    paddingHorizontal: 20,
  },
  merchantIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  merchantName: {fontSize: 20, fontWeight: '700', color: '#fff', marginBottom: 4},
  merchantVpa: {fontSize: 14, color: 'rgba(255,255,255,0.85)', marginBottom: 6},
  verifiedRow: {flexDirection: 'row', alignItems: 'center', gap: 4},
  verifiedText: {fontSize: 12, color: '#4CAF50'},
  amountSection: {
    backgroundColor: '#fff',
    margin: 16,
    borderRadius: 12,
    padding: 20,
    elevation: 2,
  },
  amountLabel: {fontSize: 13, color: '#888', marginBottom: 8},
  amountRow: {flexDirection: 'row', alignItems: 'center'},
  rupeeSymbol: {fontSize: 28, color: '#222', marginRight: 4},
  amountInput: {
    fontSize: 36,
    fontWeight: '700',
    color: '#222',
    flex: 1,
    padding: 0,
  },
  amountHint: {fontSize: 12, color: '#aaa', marginTop: 6},
  txnRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  txnLabel: {fontSize: 13, color: '#888'},
  txnValue: {fontSize: 13, color: '#555', fontFamily: 'monospace'},
  spacer: {flex: 1},
  proceedBtn: {
    margin: 16,
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
  },
  btnDisabled: {backgroundColor: '#ccc'},
  proceedText: {color: '#fff', fontSize: 16, fontWeight: '700'},
});
```

- [ ] **Step 2: Commit**

```bash
git add src/screens/DelegatePayScreen.tsx
git commit -m "feat: add DelegatePayScreen with merchant banner

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 5: Create BankSelectScreen

**Files:**
- Create: `src/screens/BankSelectScreen.tsx`

Shows list of linked bank accounts. Selecting one navigates to PinEntry.

- [ ] **Step 1: Create `src/screens/BankSelectScreen.tsx`**

```typescript
import React from 'react';
import {FlatList, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import {banks} from '../data/mockData';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'BankSelect'>;
  route: RouteProp<RootStackParams, 'BankSelect'>;
};

export default function BankSelectScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId} = route.params;

  const selectBank = (bankId: string, bankName: string) => {
    navigation.navigate('PinEntry', {amount, vpa, merchantName, txnId, bankId, bankName});
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      {/* Payment summary */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryLabel}>Paying</Text>
        <Text style={styles.summaryAmount}>₹{amount}</Text>
        <Text style={styles.summaryVpa}>to {vpa}</Text>
      </View>

      <Text style={styles.sectionTitle}>Select Payment Account</Text>

      <FlatList
        data={banks}
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <TouchableOpacity
            style={styles.bankCard}
            onPress={() => selectBank(item.id, item.name)}
            activeOpacity={0.7}>
            <View style={styles.bankIconWrap}>
              <Icon name="account-balance" size={24} color={colors.primary} />
            </View>
            <View style={styles.bankInfo}>
              <Text style={styles.bankName}>{item.name}</Text>
              <Text style={styles.bankAccount}>
                {item.accountMasked} · {item.type}
              </Text>
              <Text style={styles.bankBalance}>Bal: ₹{item.balance.toLocaleString('en-IN')}</Text>
            </View>
            <Icon name="chevron-right" size={22} color="#ccc" />
          </TouchableOpacity>
        )}
        contentContainerStyle={styles.list}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#f5f5f5'},
  summaryCard: {
    backgroundColor: colors.primary,
    padding: 20,
    alignItems: 'center',
  },
  summaryLabel: {color: 'rgba(255,255,255,0.8)', fontSize: 13, marginBottom: 4},
  summaryAmount: {color: '#fff', fontSize: 28, fontWeight: '700'},
  summaryVpa: {color: 'rgba(255,255,255,0.8)', fontSize: 13, marginTop: 2},
  sectionTitle: {
    fontSize: 13,
    color: '#888',
    fontWeight: '600',
    paddingHorizontal: 16,
    paddingTop: 18,
    paddingBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  list: {paddingHorizontal: 16, gap: 10},
  bankCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    elevation: 2,
  },
  bankIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#f0e8fb',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  bankInfo: {flex: 1},
  bankName: {fontSize: 15, fontWeight: '600', color: '#222', marginBottom: 2},
  bankAccount: {fontSize: 13, color: '#888'},
  bankBalance: {fontSize: 12, color: '#4CAF50', marginTop: 2},
});
```

- [ ] **Step 2: Commit**

```bash
git add src/screens/BankSelectScreen.tsx
git commit -m "feat: add BankSelectScreen

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 6: Create PinEntryScreen

**Files:**
- Create: `src/screens/PinEntryScreen.tsx`

6-dot PIN entry (like PhonePe). On entering 6 digits, shows loading then success. On success: adds transaction to store + POSTs callback to server.

- [ ] **Step 1: Create `src/screens/PinEntryScreen.tsx`**

```typescript
import React, {useState} from 'react';
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  TouchableOpacity,
  Vibration,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import {addTransaction} from '../data/transactionStore';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'PinEntry'>;
  route: RouteProp<RootStackParams, 'PinEntry'>;
};

const KEYPAD = [
  ['1', '2', '3'],
  ['4', '5', '6'],
  ['7', '8', '9'],
  ['', '0', '⌫'],
];

// Android emulator → host machine alias
const CALLBACK_URL = 'http://10.0.2.2:3000/payment-callback';

type Phase = 'input' | 'processing' | 'success' | 'error';

export default function PinEntryScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId, bankName} = route.params;
  const [pin, setPin] = useState('');
  const [phase, setPhase] = useState<Phase>('input');

  const handleKey = (key: string) => {
    if (phase !== 'input') return;
    if (key === '⌫') {
      setPin(p => p.slice(0, -1));
      return;
    }
    if (key === '' || pin.length >= 6) return;
    const next = pin + key;
    setPin(next);
    if (next.length === 6) {
      submitPayment(next);
    }
  };

  const submitPayment = async (enteredPin: string) => {
    // Mock: any 6-digit PIN works
    void enteredPin;
    setPhase('processing');

    // Simulate network delay
    await new Promise(res => setTimeout(res, 1500));

    const txnDate = new Date().toISOString().split('T')[0];
    addTransaction({
      id: txnId,
      name: merchantName,
      amount,
      type: 'sent',
      date: txnDate,
      note: `UPI: ${vpa}`,
    });

    // Send callback to server (fire-and-forget)
    fetch(CALLBACK_URL, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        txnId,
        status: 'SUCCESS',
        amount,
        vpa,
        merchantName,
        timestamp: new Date().toISOString(),
      }),
    }).catch(() => {/* server may not be running — ignore */});

    setPhase('success');
    Vibration.vibrate(200);
  };

  if (phase === 'processing') {
    return (
      <View style={styles.centeredFull}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={styles.processingText}>Processing payment…</Text>
      </View>
    );
  }

  if (phase === 'success') {
    return (
      <View style={styles.centeredFull}>
        <View style={styles.successCircle}>
          <Icon name="check-circle" size={72} color="#4CAF50" />
        </View>
        <Text style={styles.successTitle}>Payment Successful!</Text>
        <Text style={styles.successAmount}>₹{amount}</Text>
        <Text style={styles.successSub}>paid to {merchantName}</Text>
        <Text style={styles.successVpa}>{vpa}</Text>
        <TouchableOpacity
          style={styles.doneBtn}
          onPress={() => navigation.popToTop()}>
          <Text style={styles.doneBtnText}>Done</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      {/* Payment summary */}
      <View style={styles.header}>
        <Text style={styles.headerSub}>Paying ₹{amount} to</Text>
        <Text style={styles.headerMerchant}>{merchantName}</Text>
        <Text style={styles.headerBank}>via {bankName}</Text>
      </View>

      {/* PIN dots */}
      <View style={styles.dotsRow}>
        {[0, 1, 2, 3, 4, 5].map(i => (
          <View
            key={i}
            style={[styles.dot, i < pin.length && styles.dotFilled]}
          />
        ))}
      </View>
      <Text style={styles.pinHint}>Enter 6-digit UPI PIN</Text>

      {/* Keypad */}
      <View style={styles.keypad}>
        {KEYPAD.map((row, ri) => (
          <View key={ri} style={styles.keyRow}>
            {row.map((key, ki) => (
              <TouchableOpacity
                key={ki}
                style={[styles.key, key === '' && styles.keyEmpty]}
                onPress={() => handleKey(key)}
                disabled={key === ''}>
                <Text style={styles.keyText}>{key}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff'},
  centeredFull: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    padding: 24,
  },
  processingText: {marginTop: 16, color: '#666', fontSize: 16},
  successCircle: {marginBottom: 20},
  successTitle: {fontSize: 22, fontWeight: '700', color: '#222', marginBottom: 8},
  successAmount: {fontSize: 36, fontWeight: '800', color: colors.primary},
  successSub: {fontSize: 15, color: '#666', marginTop: 4},
  successVpa: {fontSize: 13, color: '#aaa', marginTop: 2, marginBottom: 32},
  doneBtn: {
    backgroundColor: colors.primary,
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 60,
  },
  doneBtnText: {color: '#fff', fontSize: 16, fontWeight: '700'},
  header: {
    paddingTop: 20,
    paddingBottom: 16,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  headerSub: {fontSize: 13, color: '#888'},
  headerMerchant: {fontSize: 18, fontWeight: '700', color: '#222', marginTop: 2},
  headerBank: {fontSize: 13, color: '#888', marginTop: 4},
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 14,
    marginTop: 36,
    marginBottom: 8,
  },
  dot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.primary,
    backgroundColor: 'transparent',
  },
  dotFilled: {backgroundColor: colors.primary},
  pinHint: {textAlign: 'center', color: '#aaa', fontSize: 13, marginBottom: 32},
  keypad: {paddingHorizontal: 40},
  keyRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  key: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyEmpty: {backgroundColor: 'transparent'},
  keyText: {fontSize: 24, fontWeight: '600', color: '#222'},
});
```

- [ ] **Step 2: Commit**

```bash
git add src/screens/PinEntryScreen.tsx
git commit -m "feat: add PinEntryScreen with callback to server

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 7: Wire deep link for `chromepe://pay` in App.tsx

**Files:**
- Modify: `App.tsx`

When app receives `chromepe://pay?amount=X&vpa=Y&name=Z&txnId=T`, navigate to `DelegatePay` screen via the global navigationRef.

- [ ] **Step 1: Update `App.tsx` to handle pay deep links**

Replace the full `App.tsx` with:

```typescript
import 'react-native-gesture-handler';
import React, {useState, useEffect} from 'react';
import {Linking} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import AppNavigator from './src/navigation/AppNavigator';
import SplashScreen from './src/screens/SplashScreen';
import {navigationRef} from './src/navigation/navigationRef';

function parsePayLink(url: string) {
  // chromepe://pay?amount=500&vpa=merchant%40upi&name=Starbucks&txnId=TXN123
  try {
    const withHttps = url.replace('chromepe://', 'https://chromepe.app/');
    const parsed = new URL(withHttps);
    const amount = Number(parsed.searchParams.get('amount'));
    const vpa = parsed.searchParams.get('vpa') ?? '';
    const merchantName = parsed.searchParams.get('name') ?? vpa;
    const txnId = parsed.searchParams.get('txnId') ?? `TXN${Date.now()}`;
    if (amount > 0 && vpa) {
      return {amount, vpa, merchantName, txnId};
    }
  } catch {}
  return null;
}

function navigateToDelegate(params: {amount: number; vpa: string; merchantName: string; txnId: string}) {
  if (navigationRef.isReady()) {
    navigationRef.navigate('DelegatePay', params);
  }
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const handleDeepLink = (event: {url: string}) => {
      const url = event.url;
      console.log('[ChromePe] Deep link:', url);
      if (url.startsWith('chromepe://pay')) {
        const params = parsePayLink(url);
        if (params) {
          navigateToDelegate(params);
        }
      }
    };

    Linking.getInitialURL().then(url => {
      if (url) handleDeepLink({url});
    });

    const subscription = Linking.addEventListener('url', handleDeepLink);
    return () => subscription.remove();
  }, []);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  return (
    <SafeAreaProvider>
      <NavigationContainer ref={navigationRef}>
        <AppNavigator />
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
```

- [ ] **Step 2: Commit**

```bash
git add App.tsx
git commit -m "feat: handle chromepe://pay deep link, navigate to DelegatePay

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 8: Create Node.js delegate server

**Files:**
- Create: `server/package.json`
- Create: `server/index.js`
- Create: `server/public/index.html`

The server listens on port 3000. It has:
- `GET /` — serves dashboard HTML
- `POST /initiate-payment` — generates txnId, fires `adb` deep link to emulator, stores pending txn
- `POST /payment-callback` — receives success callback from app, logs it

- [ ] **Step 1: Create `server/package.json`**

```json
{
  "name": "chromepe-delegate-server",
  "version": "1.0.0",
  "description": "Mock merchant server for ChromePe delegate pay flow",
  "main": "index.js",
  "scripts": {
    "start": "node index.js",
    "dev": "node --watch index.js"
  },
  "dependencies": {
    "express": "^4.18.2"
  }
}
```

- [ ] **Step 2: Create `server/index.js`**

```javascript
const express = require('express');
const {execSync} = require('child_process');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory log of payment requests and callbacks
const paymentLog = [];

app.post('/initiate-payment', (req, res) => {
  const {amount = 500, vpa = 'merchant@chrompe', merchantName = 'ChromePe Store'} = req.body;

  if (!amount || !vpa) {
    return res.status(400).json({error: 'amount and vpa are required'});
  }

  const txnId = `TXN${Date.now()}`;
  const encodedVpa = encodeURIComponent(vpa);
  const encodedName = encodeURIComponent(merchantName);
  const deepLink = `chromepe://pay?amount=${amount}&vpa=${encodedVpa}&name=${encodedName}&txnId=${txnId}`;

  console.log(`\n[SERVER] Initiating payment`);
  console.log(`  TxnId: ${txnId}`);
  console.log(`  Amount: ₹${amount}`);
  console.log(`  VPA: ${vpa}`);
  console.log(`  Deep link: ${deepLink}`);

  // Fire deep link to emulator via adb
  try {
    const adbCmd = `adb shell am start -a android.intent.action.VIEW -d "${deepLink}" com.chromepe`;
    console.log(`  ADB: ${adbCmd}`);
    execSync(adbCmd, {timeout: 5000});
  } catch (err) {
    console.error('[SERVER] adb error:', err.message);
    return res.status(500).json({error: 'Failed to reach emulator via adb', detail: err.message});
  }

  const entry = {txnId, amount, vpa, merchantName, status: 'PENDING', initiatedAt: new Date().toISOString()};
  paymentLog.push(entry);

  res.json({success: true, txnId, deepLink});
});

app.post('/payment-callback', (req, res) => {
  const {txnId, status, amount, vpa, merchantName, timestamp} = req.body;
  console.log(`\n[SERVER] 🎉 Payment callback received!`);
  console.log(`  TxnId: ${txnId}`);
  console.log(`  Status: ${status}`);
  console.log(`  Amount: ₹${amount}`);
  console.log(`  VPA: ${vpa}`);
  console.log(`  Time: ${timestamp}`);

  const entry = paymentLog.find(e => e.txnId === txnId);
  if (entry) entry.status = status;
  else paymentLog.push({txnId, amount, vpa, merchantName, status, completedAt: timestamp});

  res.json({received: true});
});

app.get('/log', (req, res) => {
  res.json(paymentLog);
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`\n[ChromePe Delegate Server] Running on http://localhost:${PORT}`);
  console.log(`  Dashboard: http://localhost:${PORT}`);
  console.log(`  Initiate:  POST http://localhost:${PORT}/initiate-payment`);
  console.log(`  Callback:  POST http://localhost:${PORT}/payment-callback`);
  console.log(`\n  Make sure emulator is running and adb is in PATH.\n`);
});
```

- [ ] **Step 3: Create `server/public/index.html`**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>ChromePe Merchant Dashboard</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f5f5; min-height: 100vh; }
    .topbar { background: #5f259f; color: white; padding: 16px 24px; display: flex; align-items: center; gap: 12px; }
    .topbar h1 { font-size: 20px; font-weight: 700; }
    .topbar span { font-size: 13px; opacity: 0.8; }
    .container { max-width: 560px; margin: 32px auto; padding: 0 16px; }
    .card { background: white; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
    h2 { font-size: 16px; font-weight: 600; color: #333; margin-bottom: 16px; }
    label { display: block; font-size: 13px; color: #666; margin-bottom: 4px; }
    input { width: 100%; border: 1px solid #ddd; border-radius: 8px; padding: 10px 12px; font-size: 15px; margin-bottom: 12px; outline: none; }
    input:focus { border-color: #5f259f; }
    button { width: 100%; background: #5f259f; color: white; border: none; border-radius: 8px; padding: 14px; font-size: 16px; font-weight: 700; cursor: pointer; }
    button:hover { background: #4a1d7a; }
    button:disabled { background: #ccc; cursor: not-allowed; }
    #status { margin-top: 16px; padding: 12px 16px; border-radius: 8px; font-size: 14px; display: none; }
    .success { background: #e8f5e9; color: #2e7d32; border: 1px solid #a5d6a7; }
    .error { background: #ffebee; color: #c62828; border: 1px solid #ef9a9a; }
    #log { font-size: 13px; }
    .log-row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #f0f0f0; }
    .log-row:last-child { border-bottom: none; }
    .txn-id { font-family: monospace; color: #555; font-size: 12px; }
    .badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; }
    .PENDING { background: #fff3e0; color: #e65100; }
    .SUCCESS { background: #e8f5e9; color: #2e7d32; }
    .empty { color: #aaa; text-align: center; padding: 16px; }
  </style>
</head>
<body>
  <div class="topbar">
    <div>
      <h1>ChromePe Merchant Dashboard</h1>
      <span>Delegate Pay Test Server</span>
    </div>
  </div>

  <div class="container">
    <div class="card">
      <h2>🚀 Initiate Payment Request</h2>
      <label>Amount (₹)</label>
      <input type="number" id="amount" value="500" min="1" />
      <label>Merchant VPA</label>
      <input type="text" id="vpa" value="starbucks@chrompe" />
      <label>Merchant Name</label>
      <input type="text" id="name" value="Starbucks India" />
      <button id="payBtn" onclick="initiate()">Send Pay Request to App →</button>
      <div id="status"></div>
    </div>

    <div class="card">
      <h2>📋 Payment Log</h2>
      <div id="log"><div class="empty">No payments yet</div></div>
    </div>
  </div>

  <script>
    async function initiate() {
      const btn = document.getElementById('payBtn');
      const status = document.getElementById('status');
      btn.disabled = true;
      btn.textContent = 'Sending…';
      status.style.display = 'none';

      try {
        const res = await fetch('/initiate-payment', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            amount: Number(document.getElementById('amount').value),
            vpa: document.getElementById('vpa').value,
            merchantName: document.getElementById('name').value,
          }),
        });
        const data = await res.json();
        if (data.success) {
          status.className = 'success';
          status.textContent = `✅ Payment initiated! TxnId: ${data.txnId}`;
        } else {
          status.className = 'error';
          status.textContent = `❌ Error: ${data.error}`;
        }
      } catch (e) {
        status.className = 'error';
        status.textContent = `❌ Network error: ${e.message}`;
      }

      status.style.display = 'block';
      btn.disabled = false;
      btn.textContent = 'Send Pay Request to App →';
      loadLog();
    }

    async function loadLog() {
      const res = await fetch('/log');
      const log = await res.json();
      const el = document.getElementById('log');
      if (!log.length) { el.innerHTML = '<div class="empty">No payments yet</div>'; return; }
      el.innerHTML = log.reverse().map(e => `
        <div class="log-row">
          <div>
            <div style="font-weight:600">₹${e.amount} → ${e.vpa}</div>
            <div class="txn-id">${e.txnId}</div>
          </div>
          <span class="badge ${e.status}">${e.status}</span>
        </div>
      `).join('');
    }

    loadLog();
    setInterval(loadLog, 3000);
  </script>
</body>
</html>
```

- [ ] **Step 4: Install server dependencies**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay/server
npm install
```

Expected: `added 65 packages` (or similar)

- [ ] **Step 5: Commit**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay
git add server/
git commit -m "feat: add ChromePe delegate server with dashboard

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Task 9: Verify end-to-end

- [ ] **Step 1: Start the delegate server**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay/server
node index.js
```

Expected output:
```
[ChromePe Delegate Server] Running on http://localhost:3000
  Dashboard: http://localhost:3000
```

- [ ] **Step 2: Ensure emulator is running**

```bash
adb devices
```
Expected: `emulator-5554   device`

- [ ] **Step 3: Build & install app on emulator**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay
npx react-native run-android
```

- [ ] **Step 4: Test via curl**

```bash
curl -s -X POST http://localhost:3000/initiate-payment \
  -H "Content-Type: application/json" \
  -d '{"amount":500,"vpa":"starbucks@chrompe","merchantName":"Starbucks India"}' | python3 -m json.tool
```

Expected: `{"success": true, "txnId": "TXN...", "deepLink": "chromepe://pay?..."}`

- [ ] **Step 5: Complete flow in app**

1. App opens to DelegatePayScreen showing "Starbucks India" banner with VPA and ₹500 pre-filled
2. Tap "Proceed to Pay ₹500" → BankSelectScreen
3. Tap "HDFC Bank" → PinEntryScreen
4. Enter any 6 digits → processing spinner → success screen
5. Tap "Done" → back to home

- [ ] **Step 6: Verify callback and history**

Check server logs for callback:
```
[SERVER] 🎉 Payment callback received!
  TxnId: TXN...
  Status: SUCCESS
  Amount: 500
```

In the app, tap History tab → "Starbucks India ₹500" appears at top.

- [ ] **Step 7: Commit**

```bash
cd /Users/prasad.intern/Desktop/chrome-pay
git add -A
git commit -m "feat: delegate pay flow complete - e2e verified

Co-authored-by: Copilot <223556219+Copilot@users.noreply.github.com>"
```

---

## Summary of run commands

```bash
# Terminal 1 — start server
cd ~/Desktop/chrome-pay/server && node index.js

# Terminal 2 — start emulator (if not running)
emulator -avd ChromePe_Pixel7

# Terminal 3 — build & install app
cd ~/Desktop/chrome-pay && npx react-native run-android

# Trigger a payment (or use dashboard at http://localhost:3000)
curl -X POST http://localhost:3000/initiate-payment \
  -H "Content-Type: application/json" \
  -d '{"amount":500,"vpa":"starbucks@chrompe","merchantName":"Starbucks India"}'
```
