/**
 * @format
 */

import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import { registerBackgroundNotificationHandler } from './src/services/paymentPoller';

// Must be registered at module level (before any React tree mounts)
registerBackgroundNotificationHandler();

AppRegistry.registerComponent(appName, () => App);
