const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const CLOUDFLARE_RELAY = 'https://chromepe-relay.chromepe-relay.workers.dev';

app.post('/initiate-payment', async (req, res) => {
  const {amount = 500, vpa = 'merchant@chrompe', merchantName = 'ChromePe Store', description = ''} = req.body;

  if (!amount || !vpa) {
    return res.status(400).json({error: 'amount and vpa are required'});
  }

  console.log(`\n[SERVER] Initiating payment via Cloudflare`);
  console.log(`  Amount: ₹${amount}, VPA: ${vpa}, Merchant: ${merchantName}`);

  // Register intent on Cloudflare — app polls Cloudflare and shows notification
  try {
    const resp = await fetch(`${CLOUDFLARE_RELAY}/payment/initiate`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({amount, vpa, merchantName, description}),
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Cloudflare error');
    const {txnId} = data;
    console.log(`  TxnId: ${txnId}`);
    console.log(`  [OK] Payment registered — app will detect via polling`);
    return res.json({
      success: true,
      txnId,
      statusUrl: `${CLOUDFLARE_RELAY}/payment/${txnId}/status`,
    });
  } catch (err) {
    console.error('[SERVER] Cloudflare error:', err.message);
    return res.status(502).json({error: 'Failed to register payment on Cloudflare', detail: err.message});
  }
});

// Proxy: fetch payment status from Cloudflare
app.get('/payment/:txnId/status', async (req, res) => {
  try {
    const resp = await fetch(`${CLOUDFLARE_RELAY}/payment/${req.params.txnId}/status`);
    const data = await resp.json();
    res.status(resp.status).json(data);
  } catch (err) {
    res.status(502).json({error: err.message});
  }
});

// Legacy local callback (kept for compatibility — app also posts to Cloudflare directly)
app.post('/payment-callback', (req, res) => {
  const {txnId, status, amount, vpa, merchantName, timestamp} = req.body;
  console.log(`\n[SERVER] 🎉 Payment callback (local): txnId=${txnId} status=${status} amount=₹${amount}`);
  res.json({received: true});
});

app.get('/log', async (_req, res) => {
  // Proxy log is not available from Cloudflare (no list endpoint),
  // so just return a tip to use the status endpoint per txnId
  res.json({info: 'Use GET /payment/:txnId/status to check individual payments', relay: CLOUDFLARE_RELAY});
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`\n[ChromePe Delegate Server] Running on http://localhost:${PORT}`);
  console.log(`  Initiate:  POST http://localhost:${PORT}/initiate-payment`);
  console.log(`  Status:    GET  http://localhost:${PORT}/payment/:txnId/status`);
  console.log(`  Relay:     ${CLOUDFLARE_RELAY}`);
  console.log(`\n  App polls Cloudflare for pending payments — no adb required.\n`);
});
