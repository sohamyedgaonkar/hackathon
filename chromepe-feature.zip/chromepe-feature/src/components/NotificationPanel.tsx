import React from 'react';
import {
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import colors from '../theme/colors';
import type {InAppNotification} from '../context/NotificationContext';

type Props = {
  visible: boolean;
  notifications: InAppNotification[];
  onClose: () => void;
  onPressItem: (n: InAppNotification) => void;
  onClearAll: () => void;
};

function timeAgo(ts: number): string {
  const secs = Math.floor((Date.now() - ts) / 1000);
  if (secs < 60) return 'just now';
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  return `${Math.floor(mins / 60)}h ago`;
}

export default function NotificationPanel({
  visible,
  notifications,
  onClose,
  onPressItem,
  onClearAll,
}: Props) {
  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}>
      {/* Dim backdrop */}
      <Pressable style={styles.backdrop} onPress={onClose} />

      <View style={styles.panel}>
        {/* Header */}
        <View style={styles.panelHeader}>
          <Text style={styles.panelTitle}>Notifications</Text>
          <View style={styles.headerActions}>
            {notifications.length > 0 && (
              <TouchableOpacity onPress={onClearAll} style={styles.clearBtn}>
                <Text style={styles.clearText}>Clear all</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={onClose} hitSlop={12}>
              <Icon name="close" size={22} color={colors.textPrimary} />
            </TouchableOpacity>
          </View>
        </View>

        {notifications.length === 0 ? (
          <View style={styles.emptyBox}>
            <Icon name="notifications-none" size={48} color="#ccc" />
            <Text style={styles.emptyText}>No notifications yet</Text>
          </View>
        ) : (
          <FlatList
            data={notifications}
            keyExtractor={item => item.txnId}
            renderItem={({item}) => (
              <TouchableOpacity
                style={[styles.item, !item.read && styles.itemUnread]}
                onPress={() => onPressItem(item)}
                activeOpacity={0.7}>
                <View style={styles.itemIcon}>
                  <Icon name="payment" size={22} color={colors.primary} />
                </View>
                <View style={styles.itemBody}>
                  <Text style={styles.itemTitle} numberOfLines={1}>
                    💳 {item.merchantName}
                  </Text>
                  <Text style={styles.itemSub} numberOfLines={1}>
                    ₹{item.amount}
                    {item.description ? ` · ${item.description}` : ''}
                  </Text>
                  <Text style={styles.itemTime}>{timeAgo(item.receivedAt)}</Text>
                </View>
                {!item.read && <View style={styles.unreadDot} />}
              </TouchableOpacity>
            )}
            ItemSeparatorComponent={() => <View style={styles.separator} />}
          />
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.35)',
  },
  panel: {
    position: 'absolute',
    top: 0,
    right: 0,
    width: '88%',
    maxHeight: '75%',
    backgroundColor: '#fff',
    borderBottomLeftRadius: 20,
    borderTopLeftRadius: 0,
    shadowColor: '#000',
    shadowOffset: {width: -2, height: 4},
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 16,
  },
  panelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
    backgroundColor: colors.primary,
    borderTopLeftRadius: 0,
  },
  panelTitle: {
    fontSize: 17,
    fontWeight: '700',
    color: '#fff',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  clearBtn: {paddingHorizontal: 4},
  clearText: {fontSize: 13, color: 'rgba(255,255,255,0.85)', fontWeight: '500'},
  emptyBox: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 48,
  },
  emptyText: {color: '#bbb', marginTop: 10, fontSize: 14},
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    backgroundColor: '#fff',
  },
  itemUnread: {backgroundColor: '#f8f4ff'},
  itemIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ede7f6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  itemBody: {flex: 1},
  itemTitle: {fontSize: 14, fontWeight: '600', color: colors.textPrimary},
  itemSub: {fontSize: 13, color: colors.textSecondary, marginTop: 2},
  itemTime: {fontSize: 11, color: '#aaa', marginTop: 3},
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.primary,
    marginLeft: 8,
  },
  separator: {height: 1, backgroundColor: '#f5f5f5', marginLeft: 68},
});
