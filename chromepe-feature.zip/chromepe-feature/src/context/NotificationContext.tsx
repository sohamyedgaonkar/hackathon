import React, {createContext, useCallback, useContext, useState} from 'react';
import type {DelegatePayParams} from '../navigation/AppNavigator';

export type InAppNotification = DelegatePayParams & {
  receivedAt: number;
  read: boolean;
};

type NotificationContextValue = {
  notifications: InAppNotification[];
  unreadCount: number;
  addNotification: (params: DelegatePayParams) => void;
  markAllRead: () => void;
  clearAll: () => void;
};

const NotificationContext = createContext<NotificationContextValue>({
  notifications: [],
  unreadCount: 0,
  addNotification: () => {},
  markAllRead: () => {},
  clearAll: () => {},
});

export function NotificationProvider({children}: {children: React.ReactNode}) {
  const [notifications, setNotifications] = useState<InAppNotification[]>([]);

  const addNotification = useCallback((params: DelegatePayParams) => {
    setNotifications(prev => {
      if (prev.some(n => n.txnId === params.txnId)) return prev;
      return [{...params, receivedAt: Date.now(), read: false}, ...prev];
    });
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({...n, read: true})));
  }, []);

  const clearAll = useCallback(() => setNotifications([]), []);

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <NotificationContext.Provider
      value={{notifications, unreadCount, addNotification, markAllRead, clearAll}}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  return useContext(NotificationContext);
}

// Module-level bridge so paymentPoller (non-React) can push to the context
let _addNotification: ((params: DelegatePayParams) => void) | null = null;

export function setGlobalNotificationAdder(fn: (params: DelegatePayParams) => void) {
  _addNotification = fn;
}

export function pushGlobalNotification(params: DelegatePayParams) {
  _addNotification?.(params);
}
