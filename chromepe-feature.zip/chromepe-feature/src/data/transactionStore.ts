import {transactions as seedData, Transaction} from './mockData';

// Mutable in-memory store seeded with mock data
const store: Transaction[] = [...seedData];

export function getTransactions(): Transaction[] {
  return store;
}

export function addTransaction(txn: Transaction): void {
  store.unshift(txn); // newest first
}
