import React from 'react';
import {View} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import colors from '../theme/colors';

import HomeScreen from '../screens/HomeScreen';
import SendMoneyScreen from '../screens/SendMoneyScreen';
import ScanPayScreen from '../screens/ScanPayScreen';
import HistoryScreen from '../screens/HistoryScreen';
import TransactionDetailScreen from '../screens/TransactionDetailScreen';
import WalletScreen from '../screens/WalletScreen';
import RechargeScreen from '../screens/RechargeScreen';
import BillsScreen from '../screens/BillsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import DelegatePayScreen from '../screens/DelegatePayScreen';
import BankSelectScreen from '../screens/BankSelectScreen';
import PinEntryScreen from '../screens/PinEntryScreen';

export type HomeStackParams = {
  Home: undefined;
  SendMoney: undefined;
  Recharge: undefined;
  Bills: undefined;
};

export type HistoryStackParams = {
  History: undefined;
  TransactionDetail: {transactionId: string};
};

export type DelegatePayParams = {
  amount: number;
  vpa: string;
  merchantName: string;
  txnId: string;
  description?: string;
};

export type RootStackParams = {
  MainTabs: undefined;
  DelegatePay: DelegatePayParams;
  BankSelect: DelegatePayParams;
  PinEntry: DelegatePayParams & {bankId: string; bankName: string};
};

const RootStack = createNativeStackNavigator<RootStackParams>();
const HomeStack = createNativeStackNavigator<HomeStackParams>();
const HistoryStack = createNativeStackNavigator<HistoryStackParams>();
const Tab = createBottomTabNavigator();

const TAB_ICONS: Record<string, string> = {
  HomeTab: 'home',
  HistoryTab: 'history',
  ScanTab: 'qr-code-scanner',
  WalletTab: 'account-balance-wallet',
  ProfileTab: 'person',
};

function renderTabBarIcon(routeName: string) {
  return ({color, size}: {color: string; size: number}) => (
    <Icon name={TAB_ICONS[routeName] ?? 'circle'} size={size} color={color} />
  );
}

function HomeStackNav() {
  return (
    <HomeStack.Navigator screenOptions={{headerShown: false}}>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen
        name="SendMoney"
        component={SendMoneyScreen}
        options={{headerShown: true, title: 'Send Money', headerTintColor: colors.primary}}
      />
      <HomeStack.Screen
        name="Recharge"
        component={RechargeScreen}
        options={{headerShown: true, title: 'Recharge', headerTintColor: colors.primary}}
      />
      <HomeStack.Screen
        name="Bills"
        component={BillsScreen}
        options={{headerShown: true, title: 'Pay Bills', headerTintColor: colors.primary}}
      />
    </HomeStack.Navigator>
  );
}

function HistoryStackNav() {
  return (
    <HistoryStack.Navigator screenOptions={{headerShown: false}}>
      <HistoryStack.Screen name="History" component={HistoryScreen} />
      <HistoryStack.Screen
        name="TransactionDetail"
        component={TransactionDetailScreen}
        options={{headerShown: true, title: 'Details', headerTintColor: colors.primary}}
      />
    </HistoryStack.Navigator>
  );
}

function ScanTabIcon({color, size}: {color: string; size: number}) {
  return (
    <View
      style={{
        width: 52,
        height: 52,
        borderRadius: 26,
        backgroundColor: colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 18,
        elevation: 6,
        shadowColor: colors.primary,
        shadowOffset: {width: 0, height: 3},
        shadowOpacity: 0.4,
        shadowRadius: 6,
      }}>
      <Icon name="qr-code-scanner" size={26} color="#fff" />
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({route}) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: '#b0b0b0',
        tabBarStyle: {
          borderTopColor: '#f0f0f0',
          borderTopWidth: 1,
          height: 62,
          paddingBottom: 6,
          paddingTop: 6,
          backgroundColor: '#fff',
          elevation: 8,
        },
        tabBarLabelStyle: {fontSize: 10, fontWeight: '600', marginTop: 0},
        tabBarIcon: route.name === 'ScanTab'
          ? ScanTabIcon
          : renderTabBarIcon(route.name),
      })}>
      <Tab.Screen name="HomeTab" component={HomeStackNav} options={{title: 'Home'}} />
      <Tab.Screen name="HistoryTab" component={HistoryStackNav} options={{title: 'History'}} />
      <Tab.Screen
        name="ScanTab"
        component={ScanPayScreen}
        options={{title: '', tabBarLabel: () => null}}
      />
      <Tab.Screen name="WalletTab" component={WalletScreen} options={{title: 'Wallet'}} />
      <Tab.Screen name="ProfileTab" component={ProfileScreen} options={{title: 'Profile'}} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <RootStack.Navigator screenOptions={{headerShown: false}}>
      <RootStack.Screen name="MainTabs" component={MainTabs} />
      <RootStack.Screen
        name="DelegatePay"
        component={DelegatePayScreen}
        options={{presentation: 'modal', headerShown: true, title: 'Pay', headerTintColor: colors.primary}}
      />
      <RootStack.Screen
        name="BankSelect"
        component={BankSelectScreen}
        options={{presentation: 'transparentModal', headerShown: false, animation: 'slide_from_bottom'}}
      />
      <RootStack.Screen
        name="PinEntry"
        component={PinEntryScreen}
        options={{presentation: 'modal', headerShown: true, title: 'Enter UPI PIN', headerTintColor: colors.primary}}
      />
    </RootStack.Navigator>
  );
}
