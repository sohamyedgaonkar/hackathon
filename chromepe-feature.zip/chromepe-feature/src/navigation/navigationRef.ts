import {createNavigationContainerRef} from '@react-navigation/native';
import type {RootStackParams} from './AppNavigator';

export const navigationRef = createNavigationContainerRef<RootStackParams>();
