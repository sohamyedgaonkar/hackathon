import React from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import {banks} from '../data/mockData';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'BankSelect'>;
  route: RouteProp<RootStackParams, 'BankSelect'>;
};

export default function BankSelectScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId, description} = route.params;
  const insets = useSafeAreaInsets();

  const selectBank = (bankId: string, bankName: string) => {
    navigation.navigate('PinEntry', {
      amount,
      vpa,
      merchantName,
      txnId,
      description,
      bankId,
      bankName,
    });
  };

  return (
    <TouchableWithoutFeedback onPress={() => navigation.goBack()}>
      <View style={styles.overlay}>
        {/* Bottom sheet */}
        <TouchableWithoutFeedback>
          <View style={[styles.sheet, {paddingBottom: insets.bottom + 16}]}>
            {/* Drag handle */}
            <View style={styles.handleWrap}>
              <View style={styles.handle} />
            </View>

            {/* Payment summary */}
            <View style={styles.summaryRow}>
              <View style={styles.summaryLeft}>
                <Text style={styles.summaryLabel}>Paying to</Text>
                <Text style={styles.summaryMerchant} numberOfLines={1}>
                  {merchantName}
                </Text>
                <Text style={styles.summaryVpa}>{vpa}</Text>
              </View>
              <View style={styles.summaryRight}>
                <Text style={styles.summaryAmountLabel}>Amount</Text>
                <Text style={styles.summaryAmount}>₹{amount}</Text>
              </View>
            </View>

            <View style={styles.divider} />

            <Text style={styles.sectionTitle}>SELECT PAYMENT ACCOUNT</Text>

            <FlatList
              data={banks}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={styles.bankRow}
                  onPress={() => selectBank(item.id, item.name)}
                  activeOpacity={0.7}>
                  <View style={styles.bankIconWrap}>
                    <Icon name="account-balance" size={22} color={colors.primary} />
                  </View>
                  <View style={styles.bankInfo}>
                    <Text style={styles.bankName}>{item.name}</Text>
                    <Text style={styles.bankSub}>
                      {item.accountMasked} · {item.type}
                    </Text>
                  </View>
                  <View style={styles.balanceWrap}>
                    <Text style={styles.bankBalance}>
                      ₹{item.balance.toLocaleString('en-IN')}
                    </Text>
                    <Icon name="chevron-right" size={20} color="#bbb" />
                  </View>
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={styles.itemSep} />}
            />
          </View>
        </TouchableWithoutFeedback>
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.45)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  handleWrap: {alignItems: 'center', paddingVertical: 10},
  handle: {width: 40, height: 4, borderRadius: 2, backgroundColor: '#ddd'},

  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
  },
  summaryLeft: {flex: 1},
  summaryLabel: {fontSize: 12, color: '#888', marginBottom: 2},
  summaryMerchant: {fontSize: 15, fontWeight: '700', color: '#222'},
  summaryVpa: {fontSize: 12, color: '#999', marginTop: 2},
  summaryRight: {alignItems: 'flex-end'},
  summaryAmountLabel: {fontSize: 12, color: '#888', marginBottom: 2},
  summaryAmount: {fontSize: 22, fontWeight: '700', color: colors.primary},

  divider: {height: 1, backgroundColor: '#f0f0f0', marginBottom: 14},
  sectionTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: '#aaa',
    letterSpacing: 0.8,
    marginBottom: 12,
  },

  bankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  bankIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#f0e8fb',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  bankInfo: {flex: 1},
  bankName: {fontSize: 14, fontWeight: '600', color: '#222'},
  bankSub: {fontSize: 12, color: '#999', marginTop: 2},
  balanceWrap: {alignItems: 'flex-end', flexDirection: 'row', gap: 2},
  bankBalance: {fontSize: 13, color: '#4CAF50', fontWeight: '600'},
  itemSep: {height: 1, backgroundColor: '#f5f5f5'},
});
