import React, {useState} from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'DelegatePay'>;
  route: RouteProp<RootStackParams, 'DelegatePay'>;
};

export default function DelegatePayScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId, description} = route.params;
  const [editAmount, setEditAmount] = useState(String(amount));
  const [message, setMessage] = useState(description ?? '');
  const [isEditing, setIsEditing] = useState(false);

  const initials = merchantName
    .split(' ')
    .map((w: string) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const handleKey = (key: string) => {
    if (key === 'backspace') {
      setEditAmount(prev => prev.slice(0, -1));
    } else if (key === '.') {
      if (!editAmount.includes('.')) {
        setEditAmount(prev => (prev === '' ? '0.' : prev + '.'));
      }
    } else {
      setEditAmount(prev => (prev === '0' ? key : prev + key));
    }
  };

  const canProceed = !!editAmount && Number(editAmount) > 0;

  const proceed = () => {
    navigation.navigate('BankSelect', {
      amount: Number(editAmount) || amount,
      vpa,
      merchantName,
      txnId,
      description: message || description,
    });
  };

  const keys = [
    ['1', '2', '3'],
    ['4', '5', '6'],
    ['7', '8', '9'],
    ['.', '0', 'backspace'],
  ];

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      {/* Merchant row */}
      <View style={styles.merchantRow}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{initials}</Text>
        </View>
        <View style={styles.merchantInfo}>
          <Text style={styles.merchantName} numberOfLines={1}>{merchantName}</Text>
          <Text style={styles.merchantVpa} numberOfLines={1}>{vpa}</Text>
        </View>
        <TouchableOpacity>
          <Text style={styles.viewHistory}>VIEW HISTORY</Text>
        </TouchableOpacity>
      </View>

      {/* Amount display / edit row */}
      {isEditing ? (
        /* ── Editing mode: input box ── */
        <View style={styles.amountBox}>
          <Text style={styles.rupee}>₹</Text>
          <TextInput
            style={styles.amountInput}
            value={editAmount}
            placeholder="Enter amount"
            placeholderTextColor="#bbb"
            showSoftInputOnFocus={false}
            caretHidden={false}
            editable={false}
            selectTextOnFocus={false}
            autoFocus={false}
          />
          <TouchableOpacity
            style={styles.doneEditBtn}
            onPress={() => setIsEditing(false)}>
            <Icon name="check-circle" size={26} color={colors.primary} />
          </TouchableOpacity>
        </View>
      ) : (
        /* ── Display mode: tap to edit ── */
        <TouchableOpacity style={styles.amountDisplay} onPress={() => setIsEditing(true)}>
          <Text style={styles.rupeeDisplay}>₹</Text>
          <Text style={styles.amountDisplayText}>
            {editAmount || '0'}
          </Text>
          <View style={styles.editChip}>
            <Icon name="edit" size={13} color={colors.primary} />
            <Text style={styles.editChipText}>Edit</Text>
          </View>
        </TouchableOpacity>
      )}

      {/* Message input */}
      <TextInput
        style={styles.messageInput}
        placeholder="Add a message (optional)"
        placeholderTextColor="#bbb"
        value={message}
        onChangeText={setMessage}
        maxLength={60}
      />

      <View style={styles.spacer} />

      {/* Proceed bar — always visible */}
      <TouchableOpacity
        style={[styles.proceedBar, canProceed && styles.proceedBarActive]}
        onPress={proceed}
        activeOpacity={0.8}
        disabled={!canProceed}>
        <Text style={[styles.proceedText, canProceed && styles.proceedTextActive]}>
          PROCEED TO PAY
        </Text>
      </TouchableOpacity>

      {/* Custom numpad — only when editing */}
      {isEditing && (
        <View style={styles.numpad}>
          {keys.map((row, ri) => (
            <View key={ri} style={styles.numRow}>
              {row.map(k => (
                <TouchableOpacity
                  key={k}
                  style={styles.numKey}
                  onPress={() => handleKey(k)}
                  activeOpacity={0.6}>
                  {k === 'backspace' ? (
                    <Icon name="backspace" size={22} color="#444" />
                  ) : (
                    <Text style={styles.numText}>{k}</Text>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          ))}
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff'},

  merchantRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FF8C00',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  avatarText: {fontSize: 17, fontWeight: '700', color: '#fff'},
  merchantInfo: {flex: 1},
  merchantName: {fontSize: 15, fontWeight: '600', color: '#222'},
  merchantVpa: {fontSize: 12, color: '#888', marginTop: 2},
  viewHistory: {fontSize: 12, fontWeight: '700', color: colors.primary, letterSpacing: 0.3},

  /* Amount display (non-editing) */
  amountDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginTop: 28,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 12,
    backgroundColor: '#faf5ff',
    borderWidth: 1.5,
    borderColor: '#e8d5ff',
  },
  rupeeDisplay: {fontSize: 28, color: '#555', marginRight: 4},
  amountDisplayText: {flex: 1, fontSize: 36, fontWeight: '800', color: '#1a1a1a'},
  editChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f3e8ff',
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  editChipText: {fontSize: 11, fontWeight: '700', color: colors.primary},

  /* Amount input (editing) */
  amountBox: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: colors.primary,
    borderRadius: 6,
    marginHorizontal: 16,
    marginTop: 20,
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: '#fff',
  },
  rupee: {fontSize: 22, color: '#444', marginRight: 6},
  amountInput: {flex: 1, fontSize: 22, color: '#222', padding: 0},
  doneEditBtn: {padding: 4},

  messageInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 6,
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    color: '#444',
  },

  spacer: {flex: 1},

  proceedBar: {backgroundColor: '#e0e0e0', paddingVertical: 16, alignItems: 'center'},
  proceedBarActive: {backgroundColor: colors.primary},
  proceedText: {fontSize: 14, fontWeight: '700', color: '#aaa', letterSpacing: 1},
  proceedTextActive: {color: '#fff'},

  numpad: {backgroundColor: '#f5f5f5'},
  numRow: {flexDirection: 'row'},
  numKey: {
    flex: 1,
    paddingVertical: 18,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 0.5,
    borderColor: '#e0e0e0',
    backgroundColor: '#fff',
  },
  numText: {fontSize: 22, color: '#222', fontWeight: '400'},
});
