import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import colors from '../theme/colors';
import USER from '../data/user.json';

const RELAY_BASE = 'https://chromepe-relay.chromepe-relay.workers.dev';

type Props = {
  sessionId: string;
  onComplete: () => void;
  onCancel: () => void;
};

export default function DeviceLinkScreen({sessionId, onComplete, onCancel}: Props) {
  const [status, setStatus] = useState<'confirming' | 'linking' | 'success' | 'error'>('confirming');
  const [errorMessage, setErrorMessage] = useState('');

  const linkDevice = async () => {
    setStatus('linking');

    const url = `${RELAY_BASE}/session/${sessionId}/credentials`;
    console.log('[ChromePe] linkDevice called, session:', sessionId);

    const MAX_RETRIES = 5;
    const RETRY_DELAY_MS = 2000; // 2s between retries (KV eventual consistency)

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        console.log(`[ChromePe] Attempt ${attempt}/${MAX_RETRIES} → POST ${url}`);
        const response = await fetch(url, {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(USER),
        });

        console.log(`[ChromePe] Response: ${response.status}`);
        const rawText = await response.text();
        console.log('[ChromePe] Body:', rawText);

        if (response.status === 404 && attempt < MAX_RETRIES) {
          // Session not yet propagated across Cloudflare KV — wait and retry
          console.log(`[ChromePe] Session not ready yet, retrying in ${RETRY_DELAY_MS}ms...`);
          await new Promise<void>(resolve => setTimeout(() => resolve(), RETRY_DELAY_MS));
          continue;
        }

        if (!response.ok) {
          let errMsg = 'Failed to link device';
          try { errMsg = JSON.parse(rawText).error || errMsg; } catch (_) {}
          throw new Error(`HTTP ${response.status}: ${errMsg}`);
        }

        console.log('[ChromePe] Link successful!');
        setStatus('success');
        setTimeout(() => { onComplete(); }, 2000);
        return;

      } catch (error: any) {
        if (attempt < MAX_RETRIES && error.message?.includes('404')) {
          await new Promise<void>(resolve => setTimeout(() => resolve(), RETRY_DELAY_MS));
          continue;
        }
        console.log('[ChromePe] Link error:', error.message);
        setStatus('error');
        setErrorMessage(error.message || 'Connection failed');
        return;
      }
    }

    // All retries exhausted
    setStatus('error');
    setErrorMessage('Session not found or expired. Please try again.');
  };

  if (status === 'confirming') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.content}>
          <View style={styles.iconContainer}>
            <Icon name="devices" size={64} color={colors.primary} />
          </View>
          
          <Text style={styles.title}>Link Browser Extension</Text>
          <Text style={styles.subtitle}>
            ChromePe Extension wants to link with your account
          </Text>
          
          <View style={styles.infoBox}>
            <Icon name="info" size={20} color={colors.primary} />
            <Text style={styles.infoText}>
              This will allow the browser extension to make payments using your ChromePe account
            </Text>
          </View>

          <View style={styles.credentialBox}>
            <Text style={styles.credentialLabel}>Account</Text>
            <Text style={styles.credentialValue}>{USER.vpa}</Text>
          </View>

          <TouchableOpacity style={styles.confirmBtn} onPress={linkDevice}>
            <Icon name="check" size={20} color="#fff" />
            <Text style={styles.confirmBtnText}>Confirm & Link</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
            <Text style={styles.cancelBtnText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (status === 'linking') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.content}>
          <ActivityIndicator size="large" color={colors.primary} />
          <Text style={styles.loadingText}>Linking device...</Text>
          <Text style={[styles.loadingText, {fontSize: 12, marginTop: 4}]}>This may take a few seconds</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (status === 'success') {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.content}>
          <View style={[styles.iconContainer, styles.successIcon]}>
            <Icon name="check-circle" size={80} color="#4CAF50" />
          </View>
          <Text style={styles.title}>Device Linked!</Text>
          <Text style={styles.subtitle}>
            Your browser extension is now connected to your ChromePe account
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  // Error state
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <View style={[styles.iconContainer, styles.errorIcon]}>
          <Icon name="error" size={64} color="#f44336" />
        </View>
        <Text style={styles.title}>Link Failed</Text>
        <Text style={styles.subtitle}>{errorMessage}</Text>
        
        <TouchableOpacity style={styles.retryBtn} onPress={linkDevice}>
          <Text style={styles.retryBtnText}>Retry</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.cancelBtn} onPress={onCancel}>
          <Text style={styles.cancelBtnText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#f0f4ff',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  successIcon: {
    backgroundColor: '#e8f5e9',
  },
  errorIcon: {
    backgroundColor: '#ffebee',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  infoBox: {
    flexDirection: 'row',
    backgroundColor: '#f0f4ff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
    gap: 12,
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: colors.textPrimary,
    lineHeight: 18,
  },
  credentialBox: {
    width: '100%',
    backgroundColor: '#f5f5f5',
    padding: 16,
    borderRadius: 12,
    marginBottom: 24,
  },
  credentialLabel: {
    fontSize: 12,
    color: colors.textSecondary,
    marginBottom: 4,
  },
  credentialValue: {
    fontSize: 16,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  confirmBtn: {
    flexDirection: 'row',
    backgroundColor: colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
    width: '100%',
    justifyContent: 'center',
    marginBottom: 12,
  },
  confirmBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  cancelBtn: {
    paddingVertical: 12,
  },
  cancelBtnText: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: colors.textSecondary,
  },
  retryBtn: {
    backgroundColor: colors.primary,
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 12,
    marginBottom: 12,
  },
  retryBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
