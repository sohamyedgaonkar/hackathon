import React, {useState} from 'react';
import {
  SectionList,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {getTransactions} from '../data/transactionStore';
import type {Transaction} from '../data/mockData';
import type {HistoryStackParams} from '../navigation/AppNavigator';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<HistoryStackParams, 'History'>;
};

const FILTERS = ['All', 'Sent', 'Received', 'Recharge'] as const;
type Filter = (typeof FILTERS)[number];

const TYPE_META: Record<
  Transaction['type'],
  {icon: string; color: string; bg: string; label: string}
> = {
  sent:     {icon: 'arrow-upward',   color: '#E53935', bg: '#FFEBEE', label: 'Paid'},
  received: {icon: 'arrow-downward', color: '#2E7D32', bg: '#E8F5E9', label: 'Received'},
  recharge: {icon: 'smartphone',     color: '#5f259f', bg: '#f3e8ff', label: 'Recharge'},
  bill:     {icon: 'receipt-long',   color: '#E65100', bg: '#FFF3E0', label: 'Bill'},
};

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString('en-IN', {day: 'numeric', month: 'long', year: 'numeric'});
}

function groupByDate(txns: Transaction[]) {
  const map: Record<string, Transaction[]> = {};
  for (const t of txns) {
    if (!map[t.date]) map[t.date] = [];
    map[t.date].push(t);
  }
  return Object.entries(map)
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([date, data]) => ({title: date, data}));
}

export default function HistoryScreen({navigation}: Props) {
  const [filter, setFilter] = useState<Filter>('All');

  const all = getTransactions();
  const filtered = all.filter(t => {
    if (filter === 'All') return true;
    if (filter === 'Sent') return t.type === 'sent' || t.type === 'bill';
    if (filter === 'Received') return t.type === 'received';
    if (filter === 'Recharge') return t.type === 'recharge';
    return true;
  });

  const sections = groupByDate(filtered);

  const totalSent = all
    .filter(t => t.type === 'sent' || t.type === 'bill' || t.type === 'recharge')
    .reduce((s, t) => s + t.amount, 0);
  const totalReceived = all
    .filter(t => t.type === 'received')
    .reduce((s, t) => s + t.amount, 0);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTopRow}>
          <Text style={styles.headerTitle}>Transaction History</Text>
          <TouchableOpacity style={styles.searchBtn}>
            <Icon name="search" size={22} color="#fff" />
          </TouchableOpacity>
        </View>
        {/* Summary chips */}
        <View style={styles.summaryRow}>
          <View style={styles.summaryChip}>
            <Icon name="arrow-downward" size={14} color="#4CAF50" />
            <Text style={styles.summaryLabel}>Received</Text>
            <Text style={styles.summaryAmt}>
              ₹{totalReceived.toLocaleString('en-IN')}
            </Text>
          </View>
          <View style={styles.summaryDivider} />
          <View style={styles.summaryChip}>
            <Icon name="arrow-upward" size={14} color="#E53935" />
            <Text style={styles.summaryLabel}>Paid</Text>
            <Text style={styles.summaryAmt}>
              ₹{totalSent.toLocaleString('en-IN')}
            </Text>
          </View>
        </View>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterTab, filter === f && styles.filterTabActive]}
            onPress={() => setFilter(f)}>
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <SectionList
        sections={sections}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        stickySectionHeadersEnabled={false}
        renderSectionHeader={({section}) => (
          <View style={styles.dateHeader}>
            <View style={styles.dateLine} />
            <Text style={styles.dateText}>{formatDate(section.title)}</Text>
            <View style={styles.dateLine} />
          </View>
        )}
        renderItem={({item}) => {
          const meta = TYPE_META[item.type];
          const isCredited = item.type === 'received';
          return (
            <TouchableOpacity
              style={styles.txnCard}
              activeOpacity={0.7}
              onPress={() =>
                navigation.navigate('TransactionDetail', {transactionId: item.id})
              }>
              {/* Icon */}
              <View style={[styles.txnIconWrap, {backgroundColor: meta.bg}]}>
                <Icon name={meta.icon} size={20} color={meta.color} />
              </View>

              {/* Details */}
              <View style={styles.txnInfo}>
                <Text style={styles.txnName} numberOfLines={1}>
                  {item.name}
                </Text>
                <View style={styles.txnMeta}>
                  <View style={[styles.txnTypePill, {backgroundColor: meta.bg}]}>
                    <Text style={[styles.txnTypeText, {color: meta.color}]}>
                      {meta.label}
                    </Text>
                  </View>
                  {!!item.note && (
                    <Text style={styles.txnNote} numberOfLines={1}>
                      · {item.note}
                    </Text>
                  )}
                </View>
              </View>

              {/* Amount + chevron */}
              <View style={styles.txnRight}>
                <Text style={[styles.txnAmount, {color: isCredited ? '#2E7D32' : '#E53935'}]}>
                  {isCredited ? '+' : '-'}₹{item.amount.toLocaleString('en-IN')}
                </Text>
                <Icon name="chevron-right" size={16} color="#ddd" />
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyWrap}>
            <Icon name="receipt-long" size={52} color="#ddd" />
            <Text style={styles.emptyText}>No transactions found</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {flex: 1, backgroundColor: '#f0f0f5'},

  /* Header */
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 20,
  },
  headerTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  headerTitle: {fontSize: 18, fontWeight: '800', color: '#fff'},
  searchBtn: {padding: 4},

  summaryRow: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 14,
    padding: 14,
  },
  summaryChip: {flex: 1, alignItems: 'center', gap: 4},
  summaryDivider: {width: 1, backgroundColor: 'rgba(255,255,255,0.3)', marginHorizontal: 8},
  summaryLabel: {fontSize: 11, color: 'rgba(255,255,255,0.75)'},
  summaryAmt: {fontSize: 16, fontWeight: '800', color: '#fff'},

  /* Filters */
  filterRow: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    elevation: 1,
  },
  filterTab: {
    flex: 1,
    paddingVertical: 13,
    alignItems: 'center',
    borderBottomWidth: 2.5,
    borderBottomColor: 'transparent',
  },
  filterTabActive: {borderBottomColor: colors.primary},
  filterText: {fontSize: 13, color: '#aaa', fontWeight: '500'},
  filterTextActive: {color: colors.primary, fontWeight: '700'},

  /* List */
  list: {paddingHorizontal: 12, paddingTop: 8, paddingBottom: 24},

  /* Date group header */
  dateHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    gap: 8,
  },
  dateLine: {flex: 1, height: 1, backgroundColor: '#e0e0e0'},
  dateText: {fontSize: 11, fontWeight: '700', color: '#aaa', letterSpacing: 0.3},

  /* Transaction card */
  txnCard: {
    backgroundColor: '#fff',
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingVertical: 13,
    marginBottom: 8,
    elevation: 1,
  },
  txnIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 13,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  txnInfo: {flex: 1},
  txnName: {fontSize: 14, fontWeight: '600', color: '#1a1a1a'},
  txnMeta: {flexDirection: 'row', alignItems: 'center', marginTop: 4, gap: 4, flexWrap: 'wrap'},
  txnTypePill: {
    borderRadius: 8,
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
  txnTypeText: {fontSize: 10, fontWeight: '700'},
  txnNote: {fontSize: 11, color: '#999', flex: 1},
  txnRight: {alignItems: 'flex-end', gap: 4},
  txnAmount: {fontSize: 14, fontWeight: '700'},

  /* Empty */
  emptyWrap: {alignItems: 'center', paddingTop: 60, gap: 12},
  emptyText: {fontSize: 14, color: '#bbb'},
});
