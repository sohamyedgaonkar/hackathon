import React, {useState} from 'react';
import {
  Image,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

const PHONEPE_LOGO = require('../assets/phonepe-logo.jpg');
import {SafeAreaView} from 'react-native-safe-area-context';
import type {CompositeNavigationProp} from '@react-navigation/native';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import Icon from 'react-native-vector-icons/MaterialIcons';
import NotificationPanel from '../components/NotificationPanel';
import {currentUser} from '../data/mockData';
import type {HomeStackParams, RootStackParams} from '../navigation/AppNavigator';
import {useNotifications, type InAppNotification} from '../context/NotificationContext';
import {navigationRef} from '../navigation/navigationRef';
import colors from '../theme/colors';

type Props = {
  navigation: CompositeNavigationProp<
    NativeStackNavigationProp<HomeStackParams, 'Home'>,
    NativeStackNavigationProp<RootStackParams>
  >;
};

const BILL_SERVICES = [
  {id: 'b1', icon: 'smartphone',            label: 'Mobile\nRecharge', color: '#5f259f', bg: '#f3e8ff'},
  {id: 'b2', icon: 'flash-on',              label: 'Electricity',      color: '#FF8F00', bg: '#FFF8E1'},
  {id: 'b3', icon: 'live-tv',               label: 'DTH / Cable',      color: '#1565C0', bg: '#E3F2FD'},
  {id: 'b4', icon: 'local-fire-department', label: 'Gas Cylinder',     color: '#E53935', bg: '#FFEBEE'},
  {id: 'b5', icon: 'wifi',                  label: 'Broadband',        color: '#00796B', bg: '#E0F2F1'},
  {id: 'b6', icon: 'water-drop',            label: 'Water',            color: '#0288D1', bg: '#E1F5FE'},
  {id: 'b7', icon: 'health-and-safety',     label: 'Insurance',        color: '#2E7D32', bg: '#E8F5E9'},
  {id: 'b8', icon: 'phone-in-talk',         label: 'Postpaid',         color: '#6A1B9A', bg: '#EDE7F6'},
];

const FINANCE_SERVICES = [
  {id: 'f1', icon: 'trending-up',   label: 'Mutual\nFunds', color: '#5f259f', bg: '#f3e8ff'},
  {id: 'f2', icon: 'stars',         label: 'Gold',          color: '#FF8F00', bg: '#FFF8E1'},
  {id: 'f3', icon: 'auto-awesome',  label: 'Silver',        color: '#546E7A', bg: '#ECEFF1'},
  {id: 'f4', icon: 'account-balance',label: 'Fixed\nDeposit',color: '#1565C0', bg: '#E3F2FD'},
  {id: 'f5', icon: 'credit-score',  label: 'Loans',         color: '#2E7D32', bg: '#E8F5E9'},
  {id: 'f6', icon: 'verified-user', label: 'Life\nInsurance',color: '#AD1457', bg: '#FCE4EC'},
];

const TRAVEL_SERVICES = [
  {id: 't1', icon: 'flight',         label: 'Flights', color: '#1565C0', bg: '#E3F2FD'},
  {id: 't2', icon: 'train',          label: 'Trains',  color: '#2E7D32', bg: '#E8F5E9'},
  {id: 't3', icon: 'directions-bus', label: 'Bus',     color: '#E65100', bg: '#FFF3E0'},
  {id: 't4', icon: 'hotel',          label: 'Hotels',  color: '#6A1B9A', bg: '#F3E5F5'},
  {id: 't5', icon: 'local-movies',   label: 'Movies',  color: '#B71C1C', bg: '#FFEBEE'},
  {id: 't6', icon: 'event',          label: 'Events',  color: '#006064', bg: '#E0F7FA'},
];

const MF_BARS = [35, 50, 42, 65, 58, 80, 72, 95];

export default function HomeScreen({navigation}: Props) {
  const [panelVisible, setPanelVisible] = useState(false);
  const [balanceVisible, setBalanceVisible] = useState(false);
  const {notifications, unreadCount, markAllRead, clearAll} = useNotifications();

  const balance = currentUser.walletBalance;

  const openPanel = () => {
    markAllRead();
    setPanelVisible(true);
  };

  const handleNotificationPress = (n: InAppNotification) => {
    setPanelVisible(false);
    navigationRef.navigate('DelegatePay', {
      txnId: n.txnId,
      amount: n.amount,
      vpa: n.vpa,
      merchantName: n.merchantName,
      description: n.description,
    });
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />

      <ScrollView showsVerticalScrollIndicator={false}>

        {/* ── HEADER ─────────────────────────────────────── */}
        <View style={styles.header}>
          {/* Logo row */}
          <View style={styles.headerTopRow}>
            <View style={styles.logoWrap}>
              <Image source={PHONEPE_LOGO} style={styles.logoImage} />
              <Text style={styles.appName}>
                chrome<Text style={styles.appNameBold}>Pe</Text>
              </Text>
            </View>
            <View style={styles.headerRight}>
              <TouchableOpacity style={styles.headerIconBtn}>
                <Icon name="search" size={22} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.headerIconBtn} onPress={openPanel} hitSlop={8}>
                <Icon name="notifications-none" size={22} color="#fff" />
                {unreadCount > 0 && (
                  <View style={styles.badge}>
                    <Text style={styles.badgeText}>{unreadCount > 9 ? '9+' : unreadCount}</Text>
                  </View>
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* User / UPI row */}
          <View style={styles.upiRow}>
            <View style={styles.userAvatar}>
              <Text style={styles.userAvatarText}>
                {currentUser.name.charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.userInfo}>
              <Text style={styles.userName}>{currentUser.name}</Text>
              <Text style={styles.upiId}>{currentUser.upiId}</Text>
            </View>
            <TouchableOpacity
              style={styles.balanceBtn}
              onPress={() => setBalanceVisible(v => !v)}>
              <Icon
                name={balanceVisible ? 'visibility' : 'visibility-off'}
                size={13}
                color={colors.primary}
              />
              <Text style={styles.balanceBtnText}>
                {balanceVisible
                  ? `₹${balance.toLocaleString('en-IN')}`
                  : 'View Balance'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* ── TOP 4 ACTIONS ───────────────────────────────── */}
        <View style={styles.topActionsCard}>
          <TouchableOpacity
            style={styles.topAction}
            onPress={() => navigation.navigate('SendMoney')}>
            <View style={[styles.topActionIcon, {backgroundColor: '#f3e8ff'}]}>
              <Icon name="send" size={22} color={colors.primary} />
            </View>
            <Text style={styles.topActionLabel}>{'Send\nMoney'}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.topAction}>
            <View style={[styles.topActionIcon, {backgroundColor: '#E3F2FD'}]}>
              <Icon name="call-received" size={22} color="#1565C0" />
            </View>
            <Text style={styles.topActionLabel}>{'Request\nMoney'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.topAction}
            onPress={() => navigation.navigate('Recharge')}>
            <View style={[styles.topActionIcon, {backgroundColor: '#FFF3E0'}]}>
              <Icon name="smartphone" size={22} color="#E65100" />
            </View>
            <Text style={styles.topActionLabel}>{'Mobile\nRecharge'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.topAction}
            onPress={() => navigation.navigate('Bills')}>
            <View style={[styles.topActionIcon, {backgroundColor: '#E8F5E9'}]}>
              <Icon name="receipt-long" size={22} color="#2E7D32" />
            </View>
            <Text style={styles.topActionLabel}>{'Pay\nBills'}</Text>
          </TouchableOpacity>
        </View>

        {/* ── MUTUAL FUND AD BANNER ───────────────────────── */}
        <TouchableOpacity activeOpacity={0.9} style={styles.mfBanner}>
          <View style={styles.mfLeft}>
            <View style={styles.mfNewTag}>
              <Text style={styles.mfNewTagText}>WEALTH</Text>
            </View>
            <Text style={styles.mfTitle}>PhonePe Mutual Funds</Text>
            <Text style={styles.mfSubtitle}>Start SIP from just ₹100/month</Text>
            <Text style={styles.mfReturn}>Up to 31.4% returns*</Text>
            <View style={styles.mfInvestBtn}>
              <Text style={styles.mfInvestText}>Invest Now</Text>
              <Icon name="arrow-forward" size={13} color={colors.primary} />
            </View>
          </View>
          <View style={styles.mfRight}>
            <View style={styles.mfChart}>
              {MF_BARS.map((h, i) => (
                <View
                  key={i}
                  style={[
                    styles.mfBar,
                    {height: h * 0.7, opacity: 0.25 + i * 0.1},
                  ]}
                />
              ))}
            </View>
          </View>
        </TouchableOpacity>

        {/* ── RECHARGE & BILL PAYMENTS ────────────────────── */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recharge &amp; Bill Payments</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.grid}>
            {BILL_SERVICES.map(item => (
              <TouchableOpacity
                key={item.id}
                style={styles.gridItem}
                onPress={
                  item.id === 'b1'
                    ? () => navigation.navigate('Recharge')
                    : item.id === 'b2' || item.id === 'b5' || item.id === 'b6'
                    ? () => navigation.navigate('Bills')
                    : undefined
                }>
                <View style={[styles.gridIconWrap, {backgroundColor: item.bg}]}>
                  <Icon name={item.icon} size={22} color={item.color} />
                </View>
                <Text style={styles.gridLabel}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── FINANCIAL SERVICES ──────────────────────────── */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Financial Services</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.grid}>
            {FINANCE_SERVICES.map(item => (
              <TouchableOpacity key={item.id} style={styles.gridItem}>
                <View style={[styles.gridIconWrap, {backgroundColor: item.bg}]}>
                  <Icon name={item.icon} size={22} color={item.color} />
                </View>
                <Text style={styles.gridLabel}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* ── TRAVEL & ENTERTAINMENT ──────────────────────── */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Travel &amp; Entertainment</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See all</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.grid}>
            {TRAVEL_SERVICES.map(item => (
              <TouchableOpacity key={item.id} style={styles.gridItem}>
                <View style={[styles.gridIconWrap, {backgroundColor: item.bg}]}>
                  <Icon name={item.icon} size={22} color={item.color} />
                </View>
                <Text style={styles.gridLabel}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.footer}>
          <View style={styles.footerLogoRow}>
            <Image source={PHONEPE_LOGO} style={styles.footerLogoImage} />
            <Text style={styles.footerBrand}>chromePe</Text>
          </View>
          <Text style={styles.footerSub}>Secured by UPI · NPCI Certified</Text>
        </View>
      </ScrollView>

      <NotificationPanel
        visible={panelVisible}
        notifications={notifications}
        onClose={() => setPanelVisible(false)}
        onPressItem={handleNotificationPress}
        onClearAll={() => {
          clearAll();
          setPanelVisible(false);
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {flex: 1, backgroundColor: '#f0f0f5'},

  /* ── Header ── */
  header: {
    backgroundColor: colors.primary,
    paddingHorizontal: 16,
    paddingTop: 6,
    paddingBottom: 22,
  },
  headerTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  logoWrap: {flexDirection: 'row', alignItems: 'center', gap: 8},
  logoImage: {
    width: 36,
    height: 36,
    borderRadius: 18,
    resizeMode: 'cover',
  },
  appName: {fontSize: 19, color: 'rgba(255,255,255,0.8)', fontWeight: '300', letterSpacing: 0.2},
  appNameBold: {fontWeight: '800', color: '#fff'},
  headerRight: {flexDirection: 'row', alignItems: 'center', gap: 2},
  headerIconBtn: {padding: 7, position: 'relative'},
  badge: {
    position: 'absolute',
    top: 4,
    right: 4,
    minWidth: 15,
    height: 15,
    borderRadius: 8,
    backgroundColor: '#FF3D00',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 2,
  },
  badgeText: {color: '#fff', fontSize: 8, fontWeight: '800'},

  /* UPI row */
  upiRow: {flexDirection: 'row', alignItems: 'center', gap: 10},
  userAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.22)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.4)',
  },
  userAvatarText: {fontSize: 17, fontWeight: '700', color: '#fff'},
  userInfo: {flex: 1},
  userName: {fontSize: 14, fontWeight: '700', color: '#fff'},
  upiId: {fontSize: 11, color: 'rgba(255,255,255,0.65)', marginTop: 1},
  balanceBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: '#fff',
    borderRadius: 20,
    paddingHorizontal: 11,
    paddingVertical: 6,
    elevation: 1,
  },
  balanceBtnText: {fontSize: 11, fontWeight: '700', color: colors.primary},

  /* ── Top 4 actions ── */
  topActionsCard: {
    backgroundColor: '#fff',
    flexDirection: 'row',
    paddingVertical: 18,
    paddingHorizontal: 4,
    elevation: 1,
    marginBottom: 2,
  },
  topAction: {flex: 1, alignItems: 'center', gap: 7},
  topActionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topActionLabel: {fontSize: 11, color: '#333', textAlign: 'center', lineHeight: 16},

  /* ── MF Banner ── */
  mfBanner: {
    backgroundColor: '#fff',
    marginHorizontal: 12,
    marginTop: 12,
    marginBottom: 6,
    borderRadius: 18,
    flexDirection: 'row',
    overflow: 'hidden',
    elevation: 3,
    borderWidth: 1,
    borderColor: '#ede0ff',
  },
  mfLeft: {flex: 1, padding: 16, justifyContent: 'center'},
  mfNewTag: {
    backgroundColor: colors.primary,
    borderRadius: 5,
    paddingHorizontal: 7,
    paddingVertical: 2,
    alignSelf: 'flex-start',
    marginBottom: 7,
  },
  mfNewTagText: {color: '#fff', fontSize: 8, fontWeight: '800', letterSpacing: 1},
  mfTitle: {fontSize: 14, fontWeight: '800', color: '#1a1a1a'},
  mfSubtitle: {fontSize: 12, color: '#777', marginTop: 2},
  mfReturn: {fontSize: 20, fontWeight: '900', color: colors.primary, marginTop: 5},
  mfInvestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f3e8ff',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    alignSelf: 'flex-start',
    marginTop: 12,
  },
  mfInvestText: {fontSize: 12, fontWeight: '700', color: colors.primary},
  mfRight: {
    width: 110,
    backgroundColor: '#f8f0ff',
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 12,
    paddingHorizontal: 8,
  },
  mfChart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 4,
    height: 80,
  },
  mfBar: {width: 10, borderRadius: 4, backgroundColor: colors.primary},

  /* ── Section cards ── */
  sectionCard: {
    backgroundColor: '#fff',
    marginHorizontal: 12,
    marginBottom: 10,
    borderRadius: 18,
    padding: 16,
    elevation: 1,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {fontSize: 14, fontWeight: '700', color: '#1a1a1a'},
  seeAll: {fontSize: 12, fontWeight: '600', color: colors.primary},

  /* Icon grid — 4 cols */
  grid: {flexDirection: 'row', flexWrap: 'wrap'},
  gridItem: {width: '25%', alignItems: 'center', marginBottom: 16},
  gridIconWrap: {
    width: 54,
    height: 54,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
    elevation: 0,
  },
  gridLabel: {fontSize: 11, color: '#444', textAlign: 'center', lineHeight: 15},

  /* Footer */
  footer: {paddingVertical: 28, alignItems: 'center', gap: 6},
  footerLogoRow: {flexDirection: 'row', alignItems: 'center', gap: 6},
  footerLogoImage: {
    width: 26,
    height: 26,
    borderRadius: 13,
    resizeMode: 'cover',
  },
  footerBrand: {fontSize: 14, fontWeight: '700', color: '#888'},
  footerSub: {fontSize: 10, color: '#bbb'},
});

