import React, {useEffect, useRef, useState} from 'react';
import {
  ActivityIndicator,
  Animated,
  Easing,
  StyleSheet,
  Text,
  TouchableOpacity,
  Vibration,
  View,
} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialIcons';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import type {RouteProp} from '@react-navigation/native';
import type {RootStackParams} from '../navigation/AppNavigator';
import {addTransaction} from '../data/transactionStore';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParams, 'PinEntry'>;
  route: RouteProp<RootStackParams, 'PinEntry'>;
};

const KEYPAD = [
  ['1', '2', '3'],
  ['4', '5', '6'],
  ['7', '8', '9'],
  ['', '0', '⌫'],
];

const CLOUDFLARE_RELAY = 'https://chromepe-relay.chromepe-relay.workers.dev';
const LOCAL_CALLBACK_URL = 'http://10.0.2.2:3000/payment-callback';

/* Confetti particle colors */
const CONFETTI_COLORS = ['#5f259f', '#FF8C00', '#4CAF50', '#2196F3', '#FF3D00', '#FFD600', '#E91E63'];

/* Single animated confetti dot */
function ConfettiDot({
  color,
  angle,
  delay,
}: {
  color: string;
  angle: number;
  delay: number;
}) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, {
      toValue: 1,
      duration: 700,
      delay,
      easing: Easing.out(Easing.quad),
      useNativeDriver: true,
    }).start();
  }, [anim, delay]);

  const distance = 110;
  const rad = (angle * Math.PI) / 180;
  const translateX = anim.interpolate({inputRange: [0, 1], outputRange: [0, Math.cos(rad) * distance]});
  const translateY = anim.interpolate({inputRange: [0, 1], outputRange: [0, Math.sin(rad) * distance]});
  const opacity = anim.interpolate({inputRange: [0, 0.6, 1], outputRange: [1, 1, 0]});
  const scale = anim.interpolate({inputRange: [0, 0.3, 1], outputRange: [0, 1.2, 0.6]});

  return (
    <Animated.View
      style={{
        position: 'absolute',
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: color,
        opacity,
        transform: [{translateX}, {translateY}, {scale}],
      }}
    />
  );
}

/* ── Animated success screen ── */
function SuccessScreen({
  amount,
  merchantName,
  vpa,
  bankName,
  txnId,
  onDone,
}: {
  amount: number;
  merchantName: string;
  vpa: string;
  bankName: string;
  txnId: string;
  onDone: () => void;
}) {
  const circleScale = useRef(new Animated.Value(0)).current;
  const checkOpacity = useRef(new Animated.Value(0)).current;
  const checkScale = useRef(new Animated.Value(0.4)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const textTranslate = useRef(new Animated.Value(24)).current;
  const detailsOpacity = useRef(new Animated.Value(0)).current;
  const btnTranslate = useRef(new Animated.Value(40)).current;
  const btnOpacity = useRef(new Animated.Value(0)).current;
  const ripple1 = useRef(new Animated.Value(0)).current;
  const ripple2 = useRef(new Animated.Value(0)).current;
  const ripple3 = useRef(new Animated.Value(0)).current;

  /* confetti angles */
  const confetti = Array.from({length: 16}, (_, i) => ({
    angle: i * (360 / 16),
    color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
    delay: 200 + i * 20,
  }));

  useEffect(() => {
    /* ripple pulses */
    const pulse = (val: Animated.Value, delay: number) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(val, {
            toValue: 1,
            duration: 1200,
            easing: Easing.out(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(val, {toValue: 0, duration: 0, useNativeDriver: true}),
        ]),
      );

    /* Main sequence */
    Animated.sequence([
      /* 1. circle pops in */
      Animated.spring(circleScale, {
        toValue: 1,
        tension: 180,
        friction: 8,
        useNativeDriver: true,
      }),
      /* 2. checkmark fades + scales */
      Animated.parallel([
        Animated.timing(checkOpacity, {toValue: 1, duration: 220, useNativeDriver: true}),
        Animated.spring(checkScale, {toValue: 1, tension: 200, friction: 7, useNativeDriver: true}),
      ]),
      /* 3. amount text slides up */
      Animated.parallel([
        Animated.timing(textOpacity, {toValue: 1, duration: 300, useNativeDriver: true}),
        Animated.timing(textTranslate, {toValue: 0, duration: 300, easing: Easing.out(Easing.quad), useNativeDriver: true}),
      ]),
      /* 4. details fade */
      Animated.timing(detailsOpacity, {toValue: 1, duration: 280, useNativeDriver: true}),
      /* 5. done button slides up */
      Animated.parallel([
        Animated.timing(btnOpacity, {toValue: 1, duration: 250, useNativeDriver: true}),
        Animated.timing(btnTranslate, {toValue: 0, duration: 250, easing: Easing.out(Easing.quad), useNativeDriver: true}),
      ]),
    ]).start();

    pulse(ripple1, 0).start();
    pulse(ripple2, 400).start();
    pulse(ripple3, 800).start();
  }, []);

  const makeRippleStyle = (val: Animated.Value) => ({
    position: 'absolute' as const,
    width: 130,
    height: 130,
    borderRadius: 65,
    borderWidth: 2,
    borderColor: '#4CAF50',
    opacity: val.interpolate({inputRange: [0, 1], outputRange: [0.5, 0]}),
    transform: [{scale: val.interpolate({inputRange: [0, 1], outputRange: [1, 2.2]})}],
  });

  return (
    <View style={ss.root}>
      {/* Ripple rings */}
      <View style={ss.circleZone}>
        <Animated.View style={makeRippleStyle(ripple3)} />
        <Animated.View style={makeRippleStyle(ripple2)} />
        <Animated.View style={makeRippleStyle(ripple1)} />

        {/* Confetti */}
        {confetti.map((c, i) => (
          <ConfettiDot key={i} color={c.color} angle={c.angle} delay={c.delay} />
        ))}

        {/* Green circle */}
        <Animated.View style={[ss.circle, {transform: [{scale: circleScale}]}]}>
          <Animated.View style={{opacity: checkOpacity, transform: [{scale: checkScale}]}}>
            <Icon name="check" size={52} color="#fff" />
          </Animated.View>
        </Animated.View>
      </View>

      {/* Amount */}
      <Animated.Text
        style={[ss.amount, {opacity: textOpacity, transform: [{translateY: textTranslate}]}]}>
        ₹{amount.toLocaleString('en-IN')}
      </Animated.Text>

      <Animated.Text
        style={[ss.successLabel, {opacity: textOpacity, transform: [{translateY: textTranslate}]}]}>
        Payment Successful!
      </Animated.Text>

      {/* Details card */}
      <Animated.View style={[ss.detailsCard, {opacity: detailsOpacity}]}>
        <View style={ss.detailRow}>
          <Text style={ss.detailLabel}>Paid to</Text>
          <Text style={ss.detailValue}>{merchantName}</Text>
        </View>
        <View style={ss.detailDivider} />
        <View style={ss.detailRow}>
          <Text style={ss.detailLabel}>UPI</Text>
          <Text style={ss.detailValue}>{vpa}</Text>
        </View>
        <View style={ss.detailDivider} />
        <View style={ss.detailRow}>
          <Text style={ss.detailLabel}>Bank</Text>
          <Text style={ss.detailValue}>{bankName}</Text>
        </View>
        <View style={ss.detailDivider} />
        <View style={ss.detailRow}>
          <Text style={ss.detailLabel}>Txn ID</Text>
          <Text style={[ss.detailValue, ss.mono]} numberOfLines={1}>{txnId}</Text>
        </View>
      </Animated.View>

      {/* Done button */}
      <Animated.View
        style={[ss.btnWrap, {opacity: btnOpacity, transform: [{translateY: btnTranslate}]}]}>
        <TouchableOpacity style={ss.doneBtn} onPress={onDone} activeOpacity={0.85}>
          <Text style={ss.doneBtnText}>Done</Text>
        </TouchableOpacity>
        <TouchableOpacity style={ss.receiptBtn}>
          <Icon name="receipt-long" size={16} color={colors.primary} />
          <Text style={ss.receiptBtnText}>View Receipt</Text>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

type Phase = 'input' | 'processing' | 'success' | 'error';

export default function PinEntryScreen({navigation, route}: Props) {
  const {amount, vpa, merchantName, txnId, bankName} = route.params;
  const [pin, setPin] = useState('');
  const [phase, setPhase] = useState<Phase>('input');

  const handleKey = (key: string) => {
    if (phase !== 'input') return;
    if (key === '⌫') { setPin(p => p.slice(0, -1)); return; }
    if (key === '' || pin.length >= 6) return;
    const next = pin + key;
    setPin(next);
    if (next.length === 6) submitPayment(next);
  };

  const submitPayment = async (enteredPin: string) => {
    void enteredPin;
    setPhase('processing');
    await new Promise<void>(resolve => setTimeout(resolve, 1500));

    const txnDate = new Date().toISOString().split('T')[0];
    addTransaction({id: txnId, name: merchantName, amount, type: 'sent', date: txnDate, note: `UPI: ${vpa}`});

    const callbackBody = JSON.stringify({txnId, status: 'SUCCESS', amount, vpa, merchantName, timestamp: new Date().toISOString()});
    fetch(`${CLOUDFLARE_RELAY}/payment/${txnId}/callback`, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: callbackBody}).catch(() => {});
    fetch(LOCAL_CALLBACK_URL, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: callbackBody}).catch(() => {});

    setPhase('success');
    Vibration.vibrate([0, 80, 60, 120]);
  };

  if (phase === 'processing') {
    return (
      <View style={styles.centeredFull}>
        <View style={styles.processingRing}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
        <Text style={styles.processingTitle}>Processing…</Text>
        <Text style={styles.processingText}>Please do not press back</Text>
      </View>
    );
  }

  if (phase === 'success') {
    return (
      <SuccessScreen
        amount={amount}
        merchantName={merchantName}
        vpa={vpa}
        bankName={bankName}
        txnId={txnId}
        onDone={() => navigation.popToTop()}
      />
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      {/* Payment summary */}
      <View style={styles.header}>
        <Text style={styles.headerSub}>Paying to</Text>
        <Text style={styles.headerMerchant}>{merchantName}</Text>
        <Text style={styles.headerBank}>{vpa}</Text>
        <View style={styles.amountPill}>
          <Text style={styles.amountPillText}>₹{amount.toLocaleString('en-IN')}</Text>
        </View>
      </View>

      <Text style={styles.bankChip}>via {bankName}</Text>

      {/* PIN dots */}
      <View style={styles.dotsRow}>
        {[0, 1, 2, 3, 4, 5].map(i => (
          <View key={i} style={[styles.dot, i < pin.length && styles.dotFilled]} />
        ))}
      </View>
      <Text style={styles.pinHint}>Enter 6-digit UPI PIN</Text>

      {/* Keypad */}
      <View style={styles.keypad}>
        {KEYPAD.map((row, ri) => (
          <View key={ri} style={styles.keyRow}>
            {row.map((key, ki) => (
              <TouchableOpacity
                key={ki}
                style={[styles.key, key === '' && styles.keyEmpty]}
                onPress={() => handleKey(key)}
                disabled={key === ''}>
                {key === '⌫' ? (
                  <Icon name="backspace" size={22} color="#444" />
                ) : (
                  <Text style={styles.keyText}>{key}</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

/* ── Main screen styles ── */
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff'},
  centeredFull: {flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', padding: 24},
  processingRing: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: '#f3e8ff', alignItems: 'center', justifyContent: 'center', marginBottom: 20,
  },
  processingTitle: {fontSize: 18, fontWeight: '700', color: '#222', marginBottom: 6},
  processingText: {fontSize: 13, color: '#aaa'},

  header: {backgroundColor: colors.primary, paddingTop: 24, paddingBottom: 20, alignItems: 'center', paddingHorizontal: 20},
  headerSub: {fontSize: 12, color: 'rgba(255,255,255,0.75)'},
  headerMerchant: {fontSize: 20, fontWeight: '800', color: '#fff', marginTop: 4},
  headerBank: {fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 2},
  amountPill: {
    marginTop: 12,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 24,
    paddingHorizontal: 20,
    paddingVertical: 8,
  },
  amountPillText: {fontSize: 22, fontWeight: '800', color: '#fff'},
  bankChip: {textAlign: 'center', fontSize: 12, color: '#888', paddingVertical: 10, backgroundColor: '#faf5ff', marginBottom: 8},

  dotsRow: {flexDirection: 'row', justifyContent: 'center', gap: 14, marginTop: 28, marginBottom: 8},
  dot: {width: 17, height: 17, borderRadius: 9, borderWidth: 2, borderColor: colors.primary, backgroundColor: 'transparent'},
  dotFilled: {backgroundColor: colors.primary},
  pinHint: {textAlign: 'center', color: '#bbb', fontSize: 12, marginBottom: 28},

  keypad: {paddingHorizontal: 36},
  keyRow: {flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14},
  key: {
    width: 76, height: 76, borderRadius: 38,
    backgroundColor: '#f7f7f7', alignItems: 'center', justifyContent: 'center',
    elevation: 1,
  },
  keyEmpty: {backgroundColor: 'transparent', elevation: 0},
  keyText: {fontSize: 26, fontWeight: '500', color: '#222'},
});

/* ── Success screen styles ── */
const ss = StyleSheet.create({
  root: {
    flex: 1, backgroundColor: '#fff',
    alignItems: 'center', justifyContent: 'center', paddingHorizontal: 24,
  },
  circleZone: {
    width: 130, height: 130,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 28,
  },
  circle: {
    width: 100, height: 100, borderRadius: 50,
    backgroundColor: '#4CAF50',
    alignItems: 'center', justifyContent: 'center',
    elevation: 8,
    shadowColor: '#4CAF50',
    shadowOffset: {width: 0, height: 6},
    shadowOpacity: 0.45,
    shadowRadius: 12,
  },
  amount: {fontSize: 42, fontWeight: '900', color: colors.primary, letterSpacing: -1},
  successLabel: {fontSize: 17, fontWeight: '700', color: '#333', marginTop: 6, marginBottom: 24},

  detailsCard: {
    width: '100%',
    backgroundColor: '#faf5ff',
    borderRadius: 16,
    paddingHorizontal: 18,
    paddingVertical: 4,
    marginBottom: 28,
    borderWidth: 1,
    borderColor: '#ede0ff',
  },
  detailRow: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 12},
  detailDivider: {height: 1, backgroundColor: '#ede0ff'},
  detailLabel: {fontSize: 12, color: '#aaa', fontWeight: '500'},
  detailValue: {fontSize: 13, fontWeight: '700', color: '#333', maxWidth: '60%', textAlign: 'right'},
  mono: {fontFamily: 'monospace', fontSize: 11},

  btnWrap: {width: '100%', gap: 10},
  doneBtn: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 15,
    alignItems: 'center',
    elevation: 3,
  },
  doneBtnText: {color: '#fff', fontSize: 16, fontWeight: '800', letterSpacing: 0.3},
  receiptBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 6, paddingVertical: 10,
  },
  receiptBtnText: {fontSize: 13, fontWeight: '600', color: colors.primary},
});
