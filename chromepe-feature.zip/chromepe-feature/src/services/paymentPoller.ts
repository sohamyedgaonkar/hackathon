/**
 * paymentPoller.ts — ultra-fast polling build
 *
 * Strategy:
 *  • Recursive setTimeout (not setInterval) so a slow fetch never causes overlap
 *  • 250 ms base delay between polls
 *  • Hard 2-second fetch timeout via AbortController
 *  • In-app callback + pushGlobalNotification fire IMMEDIATELY on hit
 *  • notifee.displayNotification runs fire-and-forget (non-blocking)
 *  • Channel is created once at startup and cached
 */

import notifee, {AndroidImportance, EventType, AuthorizationStatus} from '@notifee/react-native';
import USER from '../data/user.json';
import type {DelegatePayParams} from '../navigation/AppNavigator';
import {pushGlobalNotification} from '../context/NotificationContext';

const RELAY_BASE = 'https://chromepe-relay.chromepe-relay.workers.dev';
const POLL_INTERVAL_MS = 250;   // ← ultra-fast: 250 ms
const FETCH_TIMEOUT_MS = 2000;  // ← abort slow requests quickly
const CHANNEL_ID = 'chromepe_payments';

const shownTxnIds = new Set<string>();

let running = false;
let onPaymentFoundCallback: ((params: DelegatePayParams) => void) | null = null;
let channelReady = false;

async function ensureChannel() {
  if (channelReady) return;
  await notifee.createChannel({
    id: CHANNEL_ID,
    name: 'Payment Requests',
    importance: AndroidImportance.HIGH,
    sound: 'default',
  });
  channelReady = true;
}

// Pre-warm the channel immediately on module load
ensureChannel().catch(() => {});

async function pollOnce() {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);

    const resp = await fetch(
      `${RELAY_BASE}/payment/pending?vpa=${encodeURIComponent(USER.vpa)}`,
      {signal: controller.signal},
    );
    clearTimeout(timer);

    if (!resp.ok) return;
    const data = await resp.json();
    if (!data.pending || !data.txnId) return;
    if (shownTxnIds.has(data.txnId)) return;

    shownTxnIds.add(data.txnId);
    const params: DelegatePayParams = {
      txnId: data.txnId,
      amount: data.amount,
      vpa: data.vpa,
      merchantName: data.merchantName,
      description: data.description || '',
    };

    // ── IMMEDIATE: in-app callback + notification panel (no await) ──
    pushGlobalNotification(params);
    onPaymentFoundCallback?.(params);   // navigate to DelegatePayScreen NOW

    // ── BACKGROUND: OS notification (fire-and-forget, never awaited) ──
    ensureChannel()
      .then(() =>
        notifee.displayNotification({
          id: data.txnId,
          title: `💳 Payment Request — ${data.merchantName}`,
          body: data.description
            ? `₹${data.amount} · ${data.description}`
            : `Collect ₹${data.amount} from your account`,
          android: {
            channelId: CHANNEL_ID,
            importance: AndroidImportance.HIGH,
            pressAction: {id: 'default'},
            tag: JSON.stringify(params),
          },
        }),
      )
      .catch(() => {});
  } catch {
    // Abort errors and network errors are silent; next poll will retry
  }
}

async function loop() {
  if (!running) return;
  await pollOnce();
  if (running) {
    setTimeout(loop, POLL_INTERVAL_MS);
  }
}

export async function requestNotificationPermission() {
  const settings = await notifee.requestPermission();
  return settings.authorizationStatus >= AuthorizationStatus.AUTHORIZED;
}

export function startPolling(onPaymentFound: (params: DelegatePayParams) => void) {
  onPaymentFoundCallback = onPaymentFound;
  if (running) return;
  running = true;
  loop(); // kick off immediately — no initial delay
}

export function stopPolling() {
  running = false;
}

export function registerForegroundNotificationHandler(
  onPress: (params: DelegatePayParams) => void,
): () => void {
  return notifee.onForegroundEvent(({type, detail}) => {
    if (type === EventType.PRESS && detail.notification?.android?.tag) {
      try {
        const params: DelegatePayParams = JSON.parse(detail.notification.android.tag);
        onPress(params);
      } catch {}
    }
  });
}

export function registerBackgroundNotificationHandler() {
  notifee.onBackgroundEvent(async ({type, detail}) => {
    if (type === EventType.PRESS) {
      // Handled by getInitialNotification on next launch
    }
  });
}

export async function handleInitialNotification(
  onPaymentFound: (params: DelegatePayParams) => void,
) {
  const initial = await notifee.getInitialNotification();
  if (initial?.notification?.android?.tag) {
    try {
      const params: DelegatePayParams = JSON.parse(initial.notification.android.tag);
      onPaymentFound(params);
    } catch {}
  }
}
