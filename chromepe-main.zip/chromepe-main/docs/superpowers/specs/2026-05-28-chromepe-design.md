# ChromePe — Design Specification

**Date:** 2026-05-28
**Project:** ChromePe — Web3-style PhonePe Wallet Browser Extension
**Context:** PhonePe Hackathon PoC

---

## 1. Overview

ChromePe is a Chrome extension that brings the PhonePe Wallet experience to the browser, mimicking MetaMask's architecture. It enables merchants to accept wallet payments via an embeddable SDK button and allows users to manage their wallet directly from the browser.

**Three components:**
1. **React SDK** — `PhonePePayButton` component for merchant websites
2. **Merchant Demo** — Single-page checkout site using the SDK
3. **Chrome Extension** — MV3 extension with onboarding, dashboard, and payment flows

## 2. Project Structure

```
ChromePe/
├── sdk/                        # React SDK (Vite library)
│   ├── src/
│   │   └── PhonePePayButton.jsx
│   ├── package.json
│   └── vite.config.js
├── merchant-demo/              # Merchant checkout site (Vite app)
│   ├── src/
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── extension/                  # Chrome Extension (Vanilla JS, MV3)
│   ├── manifest.json
│   ├── background.js           # Service worker
│   ├── content.js              # Content script (bridge)
│   ├── inpage.js               # Injected into page (window.phonepe)
│   ├── popup.html
│   ├── popup.js                # All popup UI logic + state machine
│   ├── popup.css               # PhonePe purple theme styles
│   ├── api.js                  # Caishen API helper functions
│   └── icons/                  # Extension icons
└── docs/
```

## 3. Architecture & Communication Protocol

### 3.1 Extension Detection

Content script injects `inpage.js` into the page world (`"world": "MAIN"` in manifest). This creates `window.phonepe` with a `request()` method. The SDK checks for this object to determine if the extension is installed.

### 3.2 Payment Flow (9 Steps)

```
Merchant Page          Content Script       Background (SW)      Popup              Caishen API
     │                       │                    │                 │                    │
     │  1. postMessage       │                    │                 │                    │
     │  {CHROMEPE_PAY_REQ}   │                    │                 │                    │
     │──────────────────────>│                    │                 │                    │
     │                       │  2. runtime.send   │                 │                    │
     │                       │  {PAY_REQUEST}     │                 │                    │
     │                       │──────────────────>│                 │                    │
     │                       │                    │  3. Store tx    │                    │
     │                       │                    │  openPopup()    │                    │
     │                       │                    │────────────────>│                    │
     │                       │                    │                 │  4. Show confirm   │
     │                       │                    │                 │  + PIN entry       │
     │                       │                    │                 │                    │
     │                       │        [User enters PIN & confirms]  │                    │
     │                       │                    │                 │                    │
     │                       │                    │                 │  5. POST /debit    │
     │                       │                    │                 │──────────────────>│
     │                       │                    │                 │  6. {SUCCESS}      │
     │                       │                    │                 │<──────────────────│
     │                       │                    │  7. PAY_RESULT  │                    │
     │                       │                    │<────────────────│                    │
     │                       │  8. postMessage    │                 │                    │
     │                       │  {CHROMEPE_PAY_RES}│                 │                    │
     │<──────────────────────│                    │                 │                    │
     │  9. onSuccess()       │                    │                 │                    │
```

### 3.3 Message Types

| Type | Direction | Payload |
|------|-----------|---------|
| `CHROMEPE_PAY_REQUEST` | Page → Content Script | `{receiverVpa, amount, currency}` |
| `PAY_REQUEST` | Content Script → Background | `{receiverVpa, amount, currency, tabId}` |
| `PAY_RESULT` | Background → Content Script | `{success, txnId, error?}` |
| `CHROMEPE_PAY_RESPONSE` | Content Script → Page | `{success, txnId, error?}` |
| `CHROMEPE_DETECT` | Page → Content Script | `{}` (extension detection ping) |
| `CHROMEPE_DETECTED` | Content Script → Page | `{version}` |

## 4. Component Specifications

### 4.1 React SDK — `PhonePePayButton`

**Props:**
| Prop | Type | Required | Description |
|------|------|----------|-------------|
| `receiverVpa` | string | yes | Merchant VPA |
| `amount` | number | yes | Amount in rupees |
| `currency` | string | yes | Currency code ("INR") |
| `onSuccess` | function | no | Called with `{txnId, amount, status}` |
| `onFailure` | function | no | Called with `{error, code}` |

**Behavior:**
1. On click, checks `window.phonepe` exists
2. If not installed → alerts user to install extension
3. If installed → calls `window.phonepe.request({receiverVpa, amount, currency})`
4. Listens for response via `postMessage`, calls `onSuccess` or `onFailure`
5. Shows loading state while payment is pending

**Styling:** Purple gradient button with "₹ Pay with ChromePe" label. Self-contained CSS (no external dependencies).

### 4.2 Merchant Demo

Single-page Vite+React app with:
- Fake product card (headphones, ₹500)
- Order summary
- `PhonePePayButton` with hardcoded values: `receiverVpa="merchant@phonepe"`, `amount=500`, `currency="INR"`
- Dark status log panel showing real-time events (extension detected, payment sent, success/failure)

### 4.3 Chrome Extension

#### Manifest V3 Configuration
```json
{
  "manifest_version": 3,
  "permissions": ["storage", "activeTab"],
  "action": { "default_popup": "popup.html" },
  "background": { "service_worker": "background.js" },
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"]
    },
    {
      "matches": ["<all_urls>"],
      "js": ["inpage.js"],
      "world": "MAIN"
    }
  ]
}
```

#### Popup UI States (State Machine)

```
                    ┌──────────────┐
                    │   LOADING    │ (check chrome.storage)
                    └──────┬───────┘
                           │
              ┌────────────┴────────────┐
              │                         │
     ┌────────▼────────┐     ┌──────────▼──────────┐
     │    WELCOME      │     │     DASHBOARD        │
     │  (onboarded=F)  │     │   (onboarded=T,      │
     └────────┬────────┘     │    no pendingTx)      │
              │              └──────────┬────────────┘
     ┌────────▼────────┐               │
     │   CREDENTIALS   │        ┌──────▼───────┐
     └────────┬────────┘        │   SEND FORM  │
              │                 └──────┬───────┘
     ┌────────▼────────┐               │
     │   PIN SETUP     │        ┌──────▼───────┐
     └────────┬────────┘        │  PIN VERIFY  │
              │                 └──────┬───────┘
              │                        │
              └────────┐    ┌──────────┘
                       ▼    ▼
                  ┌──────────────┐
                  │  PROCESSING  │ (API call in flight)
                  └──────┬───────┘
                         │
                ┌────────┴────────┐
                ▼                 ▼
         ┌──────────┐     ┌──────────┐
         │ SUCCESS  │     │  ERROR   │
         └──────────┘     └──────────┘

     Special entry: pendingTx exists → CONFIRM_TX
     ┌──────────────────┐
     │    CONFIRM_TX    │ (shows merchant, amount, source)
     │  → PIN_VERIFY    │
     │  → PROCESSING    │
     │  → SUCCESS/ERROR │
     └──────────────────┘
```

#### Onboarding Screens

**Welcome:** Logo, tagline, QR placeholder, "Get Started" button.

**Credentials:** JWT Token (textarea), VPA (text input), UserID (text input). All saved to `chrome.storage.local` under `credentials` key.

**PIN Setup:** 4-digit PIN with confirmation step. Stored as SHA-256 hash in `chrome.storage.local` under `pin.hash`. `pin.lastValidated` set to current timestamp.

#### Dashboard

**Profile Header:** Gradient purple header with identicon (generated from VPA initials), VPA display, settings gear icon.

**Balance Tabs:**
- **Wallet** — fetches real balance from `GET /v1/{userId}/balance` via caishen API. Displays `availableBalance` (converted from paise to rupees).
- **UPI Lite** — mock value ₹2,000
- **Send to Mobile** — mock value ₹500

**Quick Actions:** Send button (opens send form), Receive button (shows VPA as copyable text).

**Recent Activity:** Placeholder list of recent transactions.

#### Send Form (Direct Send)

Fields: Destination VPA, Amount (₹), Currency (INR only). Payment source selector (Wallet active, others disabled). Triggers PIN verification → API call → result.

#### Transaction Confirmation (SDK-triggered)

Shown when `pendingTx` exists in storage (set by background script on SDK trigger):
- Merchant VPA with identicon
- Amount in large text
- Payment source selector
- Inline PIN entry
- Reject / Confirm buttons
- On confirm: validates PIN → calls debit API → sends result back to merchant tab

#### PIN Expiry Logic

- `pin.lastValidated`: epoch timestamp of last successful PIN entry
- On any transaction: always prompt for PIN
- On popup open (non-transaction): check if `Date.now() - lastValidated > 3600000` (1 hour). If expired, show PIN verification before dashboard.
- On successful PIN entry: update `lastValidated` to `Date.now()`

## 5. Caishen API Integration

### 5.1 Base Configuration

```javascript
const API_BASE = 'http://localhost:8080'; // Caishen wallet service
```

### 5.2 API Helper Functions

**getBalance(userId, jwt):**
- `GET {API_BASE}/v1/{userId}/balance`
- Headers: `Authorization: Bearer {jwt}`
- Returns: `availableBalance` (Long, in paise) → divide by 100 for display

**debitWallet(params, jwt):**
- `POST {API_BASE}/debit/v1/moveout`
- Headers: `Authorization: Bearer {jwt}`, `Content-Type: application/json`
- Body: `WalletMerchantTransactionRequest` with `walletInformation.userId`, `amount` (paise), `currencyCode: "INR"`, `transactionId` (UUID)
- Returns: response with `responseCode` ("SUCCESS" or error)

**p2pTransfer(params, jwt):**
- `POST {API_BASE}/peer/to/peer/v1`
- Headers: `Authorization: Bearer {jwt}`, `Content-Type: application/json`
- Body: `WalletToWalletTransactionRequest` with sender/receiver wallet info
- Returns: response with `responseCode`

### 5.3 Error Handling

All API calls wrapped in try-catch. Known response codes:
- `SUCCESS` → payment succeeded
- `INSUFFICIENT_BALANCE` → show "Insufficient funds" error
- `WALLET_NOT_FOUND` → show "Wallet not found" error
- `FAILED` → generic error with retry option
- Network errors → show "Connection failed, check if wallet service is running"

## 6. Storage Schema

```javascript
// chrome.storage.local
{
  credentials: { jwt: string, vpa: string, userId: string },
  pin: { hash: string, lastValidated: number },
  onboarded: boolean,
  pendingTx: null | {
    receiverVpa: string,
    amount: number,
    currency: string,
    source: 'sdk' | 'manual',
    tabId: number,
    timestamp: number
  }
}
```

## 7. Visual Design

- **Primary:** #5f259f (PhonePe purple)
- **Gradient:** linear-gradient(135deg, #5f259f, #8e44ad)
- **Success:** #27ae60
- **Error:** #e74c3c
- **Background:** #f5f0fa
- **Cards:** white with `box-shadow: 0 2px 8px rgba(0,0,0,0.08)`
- **Border radius:** 8-12px throughout
- **Font:** system-ui, -apple-system, sans-serif
- **Extension popup size:** 360px wide (standard Chrome extension width)

## 8. Build & Development

- **SDK:** `cd sdk && npm install && npm run build` → outputs to `sdk/dist/`
- **Merchant Demo:** `cd merchant-demo && npm install && npm run dev` → dev server on port 5173
- **Extension:** No build step. Load `extension/` as unpacked extension in `chrome://extensions`
- **Caishen API:** Must be running on `localhost:8080` for real API calls

## 9. Scope Boundaries

**In scope for this PoC:**
- Full onboarding flow (welcome → credentials → PIN)
- Dashboard with real wallet balance
- SDK-triggered payment flow (merchant → extension → API)
- Direct send from extension
- PIN verification with 1-hour expiry

**Out of scope:**
- Real OAuth/SSO (using PoC credential bypass)
- UPI Lite / Send to Mobile actual functionality (mock values only)
- Transaction history from API (placeholder UI)
- Extension icon badge notifications
- Multiple wallet support
- Production error recovery / retry logic
