import { toPaise } from './shared.js';

export const API_BASE = 'http://walletservice.nixy.stg-drove.phonepe.nb6';
export const PAYMENT_API_BASE = 'http://paymentservice.nixy.stg-drove.phonepe.nb6';
export const RELAY_BASE = 'https://chromepe-relay.chromepe-relay.workers.dev';
function normalizeToken(jwt) {
  const token = String(jwt || '').trim();
  if (!token) {
    return '';
  }

  if (token.startsWith('Bearer ') || token.startsWith('O-Bearer ')) {
    return token;
  }

  return `O-Bearer ${token}`;
}

function buildAuthRecordDetails(bindingEntity = 'PHONEPE_ENTITY') {
  const transactionTime = new Date().toISOString();

  return {
    authRecords: [
      {
        type: 'DEVICE_BINDING',
        deviceFingerprint: 'chromepe-demo-device',
        deviceBindingEntity: bindingEntity,
      },
      {
        type: 'DEVICE_LOCK',
        deviceUnlockTimestamp: transactionTime,
        deviceFingerprint: 'chromepe-demo-device',
      },
    ],
  };
}

function buildMerchantAuthRecordDetails() {
  return {
    authRecords: [
      ...buildAuthRecordDetails().authRecords,
      {
        type: 'TEE_HW_SIGNATURE',
        deviceFingerprint: 'chromepe-demo-device',
        dynamicAuthIdentifier: 'chromepe-stage-auth',
        dynamicAuthVersion: 'v1',
      },
    ],
  };
}

export function buildAuthHeaders(jwt, extraHeaders = {}) {
  const normalizedToken = normalizeToken(jwt);

  return {
    Authorization: normalizedToken,
    'Content-Type': 'application/json',
    ...extraHeaders,
  };
}

export function buildDebitPayload({
  userId,
  walletId,
  merchantId,
  amount,
  currency = 'INR',
  transactionId,
  mcc = '1234',
}) {
  const transactionTime = new Date().toISOString();

  return {
    sender: {
      walletId,
      userId,
      transactionActorType: 'WALLET',
    },
    receiver: {
      merchantId,
      transactionActorType: 'MERCHANT',
    },
    amount: toPaise(amount),
    currencyCode: currency,
    context: {
      transferMode: 'WALLET_MERCHANT_DEBIT',
      merchantOrderId: `ORDER_${transactionId}`,
      merchantTransactionId: transactionId,
      transactionId,
      transactionTime,
      mcc,
      authRecordDetails: buildMerchantAuthRecordDetails(),
    },
  };
}

export function buildInteropDebitPayload({
  userId,
  walletId,
  senderVpa,
  receiverVpa,
  amount,
  currency = 'INR',
  transactionId,
  message = 'ChromePe direct send',
}) {
  const transactionTime = new Date().toISOString();
  const compactTxnId = String(transactionId).replace(/[^a-zA-Z0-9]/g, '').slice(-12);

  return {
    sender: {
      transactionActorType: 'VPA',
      userId,
      walletId,
      vpa: senderVpa,
      mcc: '0000',
    },
    receiver: {
      transactionActorType: 'VPA',
      vpa: receiverVpa,
      mcc: '0000',
    },
    amount: toPaise(amount),
    currencyCode: currency,
    context: {
      transferMode: 'UPI_WALLET_DEBIT',
      transactionId,
      upiTransactionId: `UPI${compactTxnId}`,
      utr: `UTR${compactTxnId}`,
      transactionTime,
      message,
      authRecordDetails: buildAuthRecordDetails('BANK_PSP'),
    },
  };
}

export function buildPeerTransferPayload({
  senderUserId,
  senderWalletId,
  receiverUserId,
  receiverWalletId,
  amount,
  currency = 'INR',
  transactionId,
}) {
  const transactionTime = new Date().toISOString();

  return {
    sender: {
      walletId: senderWalletId,
      userId: senderUserId,
      transactionActorType: 'WALLET',
    },
    receiver: {
      walletId: receiverWalletId,
      userId: receiverUserId,
      transactionActorType: 'WALLET',
    },
    amount: toPaise(amount),
    currencyCode: currency,
    context: {
      transferMode: 'WALLET_TO_WALLET',
      transactionId,
      transactionTime,
      beneficiaryId: receiverUserId,
      authRecordDetails: buildAuthRecordDetails(),
    },
  };
}

function parseAvailableBalance(data) {
  return (
    Number(data?.walletBalance?.availableBalance) ||
    Number(data?.availableBalance) ||
    Number(data?.data?.walletBalance?.availableBalance) ||
    Number(data?.data?.availableBalance) ||
    0
  );
}

async function parseResponse(response) {
  const text = await response.text();

  try {
    return text ? JSON.parse(text) : {};
  } catch {
    return { raw: text };
  }
}

function buildApiResult(response, data, fallbackCode = 'FAILED') {
  const responseCode =
    data?.responseCode ||
    data?.errorCode ||
    (response.ok ? 'SUCCESS' : `HTTP_${response.status}`);

  return {
    ok: response.ok,
    responseCode: responseCode || fallbackCode,
    message: data?.message || data?.error || '',
    raw: data,
  };
}

export function mapApiError(code, message = '') {
  if (code === 'OIM004') {
    return 'The stage token is unauthorized or expired. Update it in Settings.';
  }

  switch (code) {
    case 'INSUFFICIENT_BALANCE':
      return 'Insufficient wallet balance.';
    case 'WALLET_NOT_FOUND':
      return 'Wallet not found for the configured wallet/user combination.';
    case 'NETWORK_ERROR':
      return 'Could not reach the wallet service. Check the stage URL and network.';
    case 'REJECTED':
      return 'Payment was rejected.';
    case 'FAILED':
      return message || 'Payment failed on the wallet service.';
    default:
      return message || (code ? `Wallet service returned ${code}.` : 'Something went wrong.');
  }
}

export function generateTxnId() {
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `TXN_${Date.now().toString(36).toUpperCase()}_${random}`;
}

export async function getBalance({ userId, walletId }, jwt) {
  const lookupPath = walletId
    ? `/v2/wallet/${encodeURIComponent(
        walletId,
      )}/suggest/all?walletStateActivatedAlways=false&understandsMinKycV2=true`
    : `/v2/${encodeURIComponent(
        userId,
      )}/suggest/all?walletStateActivatedAlways=false&understandsMinKycV2=true&includeKycWorkflowDetails=true&context=SPLIT_BALANCES`;

  const response = await fetch(`${API_BASE}${lookupPath}`, {
    method: 'GET',
    headers: buildAuthHeaders(jwt),
  });

  const data = await parseResponse(response);
  const result = buildApiResult(response, data);
  const availableBalance = parseAvailableBalance(data);

  return {
    success: result.ok && result.responseCode === 'SUCCESS',
    responseCode: result.responseCode,
    message: result.message,
    availableBalance,
    balanceInRupees: availableBalance / 100,
    walletId: data?.walletId || data?.data?.walletId || null,
    raw: data,
  };
}

export async function debitWallet(params, jwt) {
  const payload = buildDebitPayload(params);
  const response = await fetch(
    `${API_BASE}/debit/v2/redeem?understandsMinKycV2=false`,
    {
      method: 'POST',
      headers: buildAuthHeaders(jwt),
      body: JSON.stringify(payload),
    },
  );

  const data = await parseResponse(response);
  const result = buildApiResult(response, data);

  return {
    success: result.ok && result.responseCode === 'SUCCESS',
    responseCode: result.responseCode,
    message: result.message,
    txnId: payload.context.transactionId,
    raw: data,
  };
}

export async function interopDebitVpa(params, jwt) {
  const payload = buildInteropDebitPayload(params);
  const response = await fetch(`${API_BASE}/interop/upi/debit`, {
    method: 'POST',
    headers: buildAuthHeaders(jwt),
    body: JSON.stringify(payload),
  });

  const data = await parseResponse(response);
  const result = buildApiResult(response, data);

  return {
    success: result.ok && result.responseCode === 'SUCCESS',
    responseCode: result.responseCode,
    message: result.message,
    txnId: payload.context.transactionId,
    raw: data,
  };
}

export async function p2pTransfer(params, jwt) {
  const payload = buildPeerTransferPayload(params);
  const response = await fetch(
    `${API_BASE}/peer/to/peer/v2?understandsMinKycV2=false`,
    {
      method: 'POST',
      headers: buildAuthHeaders(jwt),
      body: JSON.stringify(payload),
    },
  );

  const data = await parseResponse(response);
  const result = buildApiResult(response, data);

  return {
    success: result.ok && result.responseCode === 'SUCCESS',
    responseCode: result.responseCode,
    message: result.message,
    txnId: payload.context.transactionId,
    raw: data,
  };
}

export async function getTransactions({ userId }, jwt, limit = 50) {
  const response = await fetch(
    `${API_BASE}/v2/${encodeURIComponent(userId)}/transactions?limit=${limit}&order=DESC`,
    {
      method: 'GET',
      headers: buildAuthHeaders(jwt),
    },
  );

  const data = await parseResponse(response);

  return {
    success: response.ok && data?.responseCode === 'SUCCESS',
    transactions: Array.isArray(data?.transactions) ? data.transactions : [],
    responseCode: data?.responseCode || `HTTP_${response.status}`,
  };
}

/**
 * Resolve a VPA via the payment service to validate it exists and get payee name.
 * Returns { valid: true, name, userType } on success or { valid: false, error } on failure.
 */
export async function resolveVpa({ userId, vpa }, jwt) {
  try {
    const url = `${PAYMENT_API_BASE}/v2/upi/${encodeURIComponent(userId)}/operations/vpa/details?vpa=${encodeURIComponent(vpa)}`;
    const response = await fetch(url, {
      method: 'GET',
      headers: buildAuthHeaders(jwt),
    });

    const data = await parseResponse(response);

    if (!response.ok || data?.errorCode) {
      return {
        valid: false,
        error: `VPA "${vpa}" could not be found or does not exist. Please verify the VPA and try again.`,
      };
    }

    const name = data?.name || data?.entityName || data?.vpa || vpa;
    const userType = data?.userType || data?.entityType || 'PERSON';

    return { valid: true, name, userType };
  } catch {
    // Network error — fall back to format-only validation so we don't block on infra issues
    return { valid: null, error: null };
  }
}

// --- QR Onboarding Session APIs ---

export async function createQrSession() {
  const response = await fetch(`${RELAY_BASE}/session`, { method: 'POST' });
  const data = await response.json();
  return data.sessionId;
}

export function getQrLinkUrl(sessionId) {
  // Deep link for mobile app - opens ChromePe app directly
  return `chromepe://link?session=${encodeURIComponent(sessionId)}`;
}

export async function pollQrSession(sessionId) {
  const response = await fetch(`${RELAY_BASE}/session/${encodeURIComponent(sessionId)}`);
  if (!response.ok) {
    return { status: 'expired' };
  }
  return response.json();
}

// --- Delegate Payment APIs (UPI via ChromePe mobile app) ---

/**
 * Initiate a delegate payment intent on Cloudflare.
 * The ChromePe mobile app will poll for this and show a notification to the user.
 * Returns { ok, txnId, statusUrl } on success, throws on network error.
 */
export async function initiateDelegate({ amount, vpa, merchantName, description = '' }) {
  const response = await fetch(`${RELAY_BASE}/payment/initiate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount, vpa, merchantName, description }),
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Failed to initiate delegate payment');
  return { ok: true, txnId: data.txnId, statusUrl: data.statusUrl };
}

/**
 * Poll the status of a delegate payment.
 * Returns { status: 'PENDING' | 'COMPLETED' | 'FAILED' | 'EXPIRED', txnId, ... }
 */
export async function pollDelegateStatus(txnId) {
  const response = await fetch(
    `${RELAY_BASE}/payment/${encodeURIComponent(txnId)}/status`,
  );
  if (!response.ok) return { status: 'FAILED', txnId };
  return response.json();
}
