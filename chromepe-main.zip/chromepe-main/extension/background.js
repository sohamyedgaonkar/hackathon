const BADGE_TEXT = 'PAY';
const BADGE_COLOR = '#5f259f';
const API_BASE = 'http://walletservice.nixy.stg-drove.phonepe.nb6';
const LOCAL_MERCHANT_HOSTS = new Set(['localhost', '127.0.0.1']);

function clearPendingIndicator() {
  return chrome.action.setBadgeText({ text: '' });
}

async function setPendingIndicator() {
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR });
  await chrome.action.setBadgeText({ text: BADGE_TEXT });
}

async function openPopupOrNotify() {
  try {
    await chrome.action.openPopup();
  } catch (error) {
    await setPendingIndicator();
  }
}

function isLocalMerchantTab(url) {
  try {
    const parsedUrl = new URL(String(url || ''));
    return (
      (parsedUrl.protocol === 'http:' || parsedUrl.protocol === 'https:') &&
      LOCAL_MERCHANT_HOSTS.has(parsedUrl.hostname)
    );
  } catch {
    return false;
  }
}

async function reloadMerchantTabs() {
  const tabs = await chrome.tabs.query({});
  const reloads = tabs
    .filter((tab) => Number.isInteger(tab.id) && isLocalMerchantTab(tab.url))
    .map((tab) => chrome.tabs.reload(tab.id));

  await Promise.all(reloads);
}

async function handleInstalled() {
  await clearPendingIndicator();
  await reloadMerchantTabs();
}

function normalizeToken(jwt) {
  const token = String(jwt || '').trim();
  if (!token) {
    return '';
  }

  if (token.startsWith('Bearer ') || token.startsWith('O-Bearer ')) {
    return token;
  }

  return `O-Bearer ${token}`;
}

function buildAuthHeaders(jwt) {
  return {
    Authorization: normalizeToken(jwt),
    'Content-Type': 'application/json',
  };
}

async function parseJsonResponse(response) {
  const text = await response.text();

  try {
    return text ? JSON.parse(text) : {};
  } catch {
    return { raw: text };
  }
}

function toPaise(amount) {
  return Math.round(Number(amount || 0) * 100);
}

function decodeBase64UrlJson(value) {
  const normalized = String(value || '').replace(/-/g, '+').replace(/_/g, '/');
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
  const binary = atob(padded);
  const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
  return JSON.parse(new TextDecoder().decode(bytes));
}

async function sha256Hex(value) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}

async function verifyPaymentToken(paymentToken, jwt) {
  const [encodedPayload, signature] = String(paymentToken || '').split('.');
  if (!encodedPayload || !signature) {
    return {
      ok: false,
      code: 'INVALID_TOKEN',
      message: 'ChromePe payment token is malformed.',
    };
  }

  let payload;
  try {
    payload = decodeBase64UrlJson(encodedPayload);
  } catch (error) {
    return {
      ok: false,
      code: 'INVALID_TOKEN',
      message: 'ChromePe payment token could not be decoded.',
    };
  }

  const expectedSignature = await sha256Hex(
    [
      String(jwt || ''),
      String(payload.txnId || ''),
      String(payload.amount || 0),
      String(payload.currency || ''),
      String(payload.receiverVpa || ''),
      String(payload.issuedAt || ''),
      String(payload.expiresAt || ''),
    ].join(':'),
  );

  if (signature !== expectedSignature) {
    return {
      ok: false,
      code: 'INVALID_TOKEN',
      message: 'ChromePe payment token signature is invalid.',
    };
  }

  if (payload.expiresAt && Date.parse(payload.expiresAt) < Date.now()) {
    return {
      ok: false,
      code: 'TOKEN_EXPIRED',
      message: 'ChromePe payment token has expired.',
    };
  }

  return { ok: true, payload };
}

function buildVerificationFailure({
  payload,
  code,
  message,
  transactionState = '',
  walletId = '',
}) {
  return {
    success: false,
    verified: false,
    txnId: String(payload.txnId || ''),
    amount: Number(payload.amount || 0),
    currency: String(payload.currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(payload.receiverVpa || '').trim(),
    paymentToken: String(payload.paymentToken || '').trim(),
    status: 'FAILED',
    redirectStatus: String(payload.status || '').trim().toUpperCase(),
    responseCode: String(code || 'FAILED').trim().toUpperCase(),
    transactionState: String(transactionState || '').trim().toUpperCase(),
    walletId: String(walletId || ''),
    message,
    verifiedAt: new Date().toISOString(),
  };
}

function extractTransaction(data, txnId) {
  const transactions = Array.isArray(data?.transactions)
    ? data.transactions
    : Array.isArray(data?.data?.transactions)
      ? data.data.transactions
      : [];

  return (
    transactions.find(
      (transaction) =>
        String(transaction?.transactionId || '').trim() === String(txnId || '').trim(),
    ) ||
    transactions[0] ||
    null
  );
}

function sanitizeVerifiedTransaction(transaction) {
  if (!transaction || typeof transaction !== 'object') {
    return null;
  }

  return {
    transactionId: String(transaction.transactionId || '').trim(),
    merchantId: String(transaction.merchantId || '').trim(),
    externalVpa: String(transaction.externalVpa || '').trim(),
    amount: Number(transaction.amount || 0),
    currencyCode: String(transaction.currencyCode || 'INR')
      .trim()
      .toUpperCase(),
    transactionState: String(transaction.transactionState || '')
      .trim()
      .toUpperCase(),
    transactionType: String(transaction.transactionType || '')
      .trim()
      .toUpperCase(),
    category: String(transaction.category || '').trim().toUpperCase(),
    responseCode: String(transaction.responseCode || '').trim().toUpperCase(),
    message: String(transaction.message || '').trim(),
    transactionTime: Number(transaction.transactionTime || 0),
  };
}

async function verifyPaymentRequest(payload) {
  const { credentials } = await chrome.storage.local.get(['credentials']);
  const jwt = credentials?.jwt || '';
  const configuredWalletId = credentials?.walletId || '';

  if (!jwt) {
    return buildVerificationFailure({
      payload,
      code: 'MISSING_CREDENTIALS',
      message: 'Save the wallet JWT and wallet ID in ChromePe Settings before verifying payments.',
      walletId: configuredWalletId,
    });
  }

  const tokenCheck = await verifyPaymentToken(payload.paymentToken, jwt);
  if (!tokenCheck.ok) {
    return buildVerificationFailure({
      payload,
      code: tokenCheck.code,
      message: tokenCheck.message,
      walletId: configuredWalletId,
    });
  }

  const tokenPayload = tokenCheck.payload;
  const walletId = String(tokenPayload.walletId || configuredWalletId || '').trim();

  if (!walletId) {
    return buildVerificationFailure({
      payload,
      code: 'MISSING_WALLET_ID',
      message: 'No wallet ID was available to verify this payment.',
      walletId,
    });
  }

  const normalizedPayload = {
    txnId: String(payload.txnId || '').trim(),
    amount: Number(payload.amount || 0),
    currency: String(payload.currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(payload.receiverVpa || '').trim(),
    paymentToken: String(payload.paymentToken || '').trim(),
    status: String(payload.status || '').trim().toUpperCase(),
  };

  if (normalizedPayload.txnId && normalizedPayload.txnId !== String(tokenPayload.txnId || '')) {
    return buildVerificationFailure({
      payload: normalizedPayload,
      code: 'PAYLOAD_MISMATCH',
      message: 'Redirect transaction ID does not match the signed ChromePe token.',
      walletId,
    });
  }

  if (
    normalizedPayload.receiverVpa &&
    normalizedPayload.receiverVpa !== String(tokenPayload.receiverVpa || '')
  ) {
    return buildVerificationFailure({
      payload: normalizedPayload,
      code: 'PAYLOAD_MISMATCH',
      message: 'Redirect receiver does not match the signed ChromePe token.',
      walletId,
    });
  }

  if (
    normalizedPayload.amount &&
    normalizedPayload.amount !== Number(tokenPayload.amount || 0)
  ) {
    return buildVerificationFailure({
      payload: normalizedPayload,
      code: 'PAYLOAD_MISMATCH',
      message: 'Redirect amount does not match the signed ChromePe token.',
      walletId,
    });
  }

  const expectedPayload = {
    ...normalizedPayload,
    txnId: String(tokenPayload.txnId || ''),
    amount: Number(tokenPayload.amount || 0),
    currency: String(tokenPayload.currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(tokenPayload.receiverVpa || '').trim(),
  };

  const response = await fetch(
    `${API_BASE}/debug/v1/wallet/${encodeURIComponent(
      walletId,
    )}/transaction/${encodeURIComponent(expectedPayload.txnId)}?understandsMinKycV2=true`,
    {
      method: 'GET',
      headers: buildAuthHeaders(jwt),
    },
  );

  const data = await parseJsonResponse(response);
  const transaction = extractTransaction(data, expectedPayload.txnId);

  if (!response.ok) {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: data?.responseCode || data?.errorCode || `HTTP_${response.status}`,
      message:
        data?.message ||
        data?.error ||
        'ChromePe could not verify the payment with the wallet API.',
      walletId,
    });
  }

  if (!transaction) {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: 'TXN_NOT_FOUND',
      message: 'The wallet API did not return a transaction for this redirect.',
      walletId,
    });
  }

  const responseCode = String(
    transaction.responseCode || data?.responseCode || 'FAILED',
  ).trim().toUpperCase();
  const transactionState = String(transaction.transactionState || '')
    .trim()
    .toUpperCase();
  const merchantId = String(transaction.merchantId || '').trim();
  const currencyCode = String(transaction.currencyCode || 'INR')
    .trim()
    .toUpperCase();

  if (merchantId !== expectedPayload.receiverVpa) {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: 'MERCHANT_MISMATCH',
      message: 'The wallet API returned a transaction for a different merchant.',
      transactionState,
      walletId,
    });
  }

  if (Number(transaction.amount || 0) !== toPaise(expectedPayload.amount)) {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: 'AMOUNT_MISMATCH',
      message: 'The wallet API returned a different amount than the redirect payload.',
      transactionState,
      walletId,
    });
  }

  if (currencyCode !== expectedPayload.currency) {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: 'CURRENCY_MISMATCH',
      message: 'The wallet API returned a different currency than the redirect payload.',
      transactionState,
      walletId,
    });
  }

  if (transactionState !== 'SUCCESS' || responseCode !== 'SUCCESS') {
    return buildVerificationFailure({
      payload: expectedPayload,
      code: responseCode || 'FAILED',
      message:
        transaction.message ||
        'The wallet API found the transaction, but it was not successful.',
      transactionState,
      walletId,
    });
  }

  return {
    success: true,
    verified: true,
    txnId: expectedPayload.txnId,
    amount: expectedPayload.amount,
    currency: expectedPayload.currency,
    receiverVpa: expectedPayload.receiverVpa,
    paymentToken: expectedPayload.paymentToken,
    status: 'SUCCESS',
    redirectStatus: expectedPayload.status,
    responseCode,
    transactionState,
    walletId,
    message: 'Verified with wallet API.',
    verifiedAt: new Date().toISOString(),
    verifiedTransaction: sanitizeVerifiedTransaction(transaction),
  };
}

function createPendingTx(payload, tabId, requestId) {
  return {
    receiverVpa: String(payload.receiverVpa || '').trim(),
    amount: Number(payload.amount || 0),
    currency: String(payload.currency || 'INR').trim().toUpperCase(),
    redirectUrl: String(payload.redirectUrl || '').trim(),
    source: 'sdk',
    tabId,
    requestId,
    timestamp: Date.now(),
  };
}

function getResolvedPaymentContext(message, pendingTx) {
  const rawTabId =
    message.tabId !== undefined && message.tabId !== null
      ? message.tabId
      : pendingTx?.tabId;

  return {
    tabId: Number.isInteger(rawTabId) ? rawTabId : null,
    requestId: message.requestId || pendingTx?.requestId || null,
    amount: Number(
      message.amount !== undefined && message.amount !== null
        ? message.amount
        : pendingTx?.amount || 0,
    ),
    currency: String(message.currency || pendingTx?.currency || 'INR')
      .trim()
      .toUpperCase(),
    receiverVpa: String(message.receiverVpa || pendingTx?.receiverVpa || '').trim(),
    redirectUrl: String(message.redirectUrl || pendingTx?.redirectUrl || '').trim(),
    paymentToken: String(message.paymentToken || '').trim(),
    txnId: message.txnId || null,
    success: Boolean(message.success),
    error: message.error || null,
    code: message.code || null,
  };
}

async function forwardPaymentResult(message) {
  const { pendingTx } = await chrome.storage.local.get(['pendingTx']);
  const context = getResolvedPaymentContext(message, pendingTx);

  if (context.tabId === null || !context.requestId) {
    return;
  }

  await chrome.tabs.sendMessage(context.tabId, {
    action: 'PAY_RESULT',
    requestId: context.requestId,
    success: context.success,
    txnId: context.txnId,
    amount: context.amount,
    currency: context.currency,
    receiverVpa: context.receiverVpa,
    paymentToken: context.paymentToken,
    redirectUrl: context.redirectUrl,
    error: context.error,
    code: context.code,
  });
}

chrome.runtime.onInstalled.addListener(() => {
  handleInstalled().catch((error) => {
    console.error('ChromePe could not refresh merchant tabs after update.', error);
  });
});
chrome.runtime.onStartup.addListener(clearPendingIndicator);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.action === 'PAY_REQUEST') {
    const tabId = sender.tab?.id ?? null;
    const payload = message.payload || {};

    chrome.storage.local
      .set({
        pendingTx: createPendingTx(payload, tabId, message.requestId),
      })
      .then(openPopupOrNotify)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));

    return true;
  }

  if (message?.action === 'PAY_CONFIRMED' || message?.action === 'PAY_REJECTED') {
    forwardPaymentResult(message)
      .then(async () => {
        await chrome.storage.local.remove('pendingTx');
        await clearPendingIndicator();
        sendResponse({ ok: true });
      })
      .catch(async (error) => {
        await chrome.storage.local.remove('pendingTx');
        await clearPendingIndicator();
        sendResponse({ ok: false, error: error.message });
      });

    return true;
  }

  if (message?.action === 'VERIFY_PAYMENT_REQUEST') {
    verifyPaymentRequest(message.payload || {})
      .then((result) => sendResponse(result))
      .catch((error) =>
        sendResponse({
          success: false,
          verified: false,
          responseCode: 'VERIFY_FAILED',
          message: error?.message || 'ChromePe could not verify this payment.',
          status: 'FAILED',
        }),
      );

    return true;
  }

  return false;
});
