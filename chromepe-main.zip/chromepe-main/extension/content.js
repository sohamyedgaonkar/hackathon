function postBridgeResponse(type, requestId, payload) {
  window.postMessage(
    {
      source: 'chromepe-extension',
      type,
      requestId,
      ...payload,
    },
    '*',
  );
}

function buildRuntimeFailure(error, fallbackCode, fallbackMessage) {
  const message = String(error?.message || '').trim();
  const invalidated = /Extension context invalidated/i.test(message);

  if (invalidated) {
    return {
      success: false,
      error: 'ChromePe was updated. Reload this tab to reconnect the extension.',
      code: 'EXTENSION_CONTEXT_INVALIDATED',
    };
  }

  return {
    success: false,
    error: message || fallbackMessage,
    code: error?.code || fallbackCode,
  };
}

function safeSendRuntimeMessage(runtimeMessage) {
  try {
    return Promise.resolve(chrome.runtime.sendMessage(runtimeMessage));
  } catch (error) {
    return Promise.reject(error);
  }
}

window.addEventListener('message', (event) => {
  if (event.source !== window) {
    return;
  }

  const message = event.data;
  if (!message || message.source !== 'chromepe-inpage') {
    return;
  }

  if (message.type === 'CHROMEPE_PAY_REQUEST') {
    safeSendRuntimeMessage({
      action: 'PAY_REQUEST',
      requestId: message.requestId,
      payload: message.payload,
    })
      .then((response) => {
        if (response?.ok === false) {
          postBridgeResponse('CHROMEPE_PAY_RESPONSE', message.requestId, {
            success: false,
            error: response.error || 'ChromePe could not start this payment.',
            code: 'PAY_REQUEST_FAILED',
          });
        }
      })
      .catch((error) => {
        postBridgeResponse(
          'CHROMEPE_PAY_RESPONSE',
          message.requestId,
          buildRuntimeFailure(
            error,
            'PAY_REQUEST_FAILED',
            'ChromePe could not start this payment.',
          ),
        );
      });
  }

  if (message.type === 'CHROMEPE_VERIFY_REQUEST') {
    safeSendRuntimeMessage({
      action: 'VERIFY_PAYMENT_REQUEST',
      requestId: message.requestId,
      payload: message.payload,
    })
      .then((response) => {
        postBridgeResponse('CHROMEPE_VERIFY_RESPONSE', message.requestId, {
          ...(response || {
            success: false,
            error: 'No verification response received from ChromePe.',
            code: 'NO_VERIFY_RESPONSE',
          }),
        });
      })
      .catch((error) => {
        postBridgeResponse(
          'CHROMEPE_VERIFY_RESPONSE',
          message.requestId,
          buildRuntimeFailure(
            error,
            'VERIFY_REQUEST_FAILED',
            'ChromePe could not verify this payment.',
          ),
        );
      });
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.action !== 'PAY_RESULT') {
    return;
  }

  window.postMessage(
    {
      source: 'chromepe-extension',
      type: 'CHROMEPE_PAY_RESPONSE',
      requestId: message.requestId,
      success: message.success,
      txnId: message.txnId,
      amount: message.amount,
      currency: message.currency,
      receiverVpa: message.receiverVpa,
      paymentToken: message.paymentToken,
      redirectUrl: message.redirectUrl,
      error: message.error,
      code: message.code,
    },
    '*',
  );
});
