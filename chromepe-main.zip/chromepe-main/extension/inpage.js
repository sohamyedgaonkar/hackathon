(function injectChromePeProvider() {
  if (window.phonepe && window.phonepe.isChromePe) {
    return;
  }

  const pendingRequests = new Map();
  let sequence = 0;

  function createRequestId() {
    sequence += 1;
    return `chromepe_${Date.now()}_${sequence}`;
  }

  function createPendingRequest({
    requestType,
    responseType,
    payload,
    timeoutMessage,
  }) {
    return new Promise((resolve, reject) => {
      const requestId = createRequestId();
      const timer = window.setTimeout(() => {
        pendingRequests.delete(requestId);
        reject({
          error: timeoutMessage,
          code: 'TIMEOUT',
        });
      }, 5 * 60 * 1000);

      pendingRequests.set(requestId, {
        responseType,
        resolve(value) {
          window.clearTimeout(timer);
          resolve(value);
        },
        reject(error) {
          window.clearTimeout(timer);
          reject(error);
        },
      });

      window.postMessage(
        {
          source: 'chromepe-inpage',
          type: requestType,
          requestId,
          payload,
        },
        '*',
      );
    });
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window) {
      return;
    }

    const message = event.data;
    if (!message || message.source !== 'chromepe-extension') {
      return;
    }

    const pending = pendingRequests.get(message.requestId);
    if (!pending || message.type !== pending.responseType) {
      return;
    }

    pendingRequests.delete(message.requestId);

    if (message.success) {
      pending.resolve(message);
      return;
    }

    pending.reject({
      error: message.error || 'Payment failed.',
      code: message.code || 'FAILED',
    });
  });

  const provider = {
    isChromePe: true,
    version: '1.0.0',
    request(payload) {
      return createPendingRequest({
        requestType: 'CHROMEPE_PAY_REQUEST',
        responseType: 'CHROMEPE_PAY_RESPONSE',
        payload,
        timeoutMessage: 'Payment request timed out.',
      });
    },
    verifyPayment(payload) {
      return createPendingRequest({
        requestType: 'CHROMEPE_VERIFY_REQUEST',
        responseType: 'CHROMEPE_VERIFY_RESPONSE',
        payload,
        timeoutMessage: 'Payment verification timed out.',
      });
    },
  };

  Object.defineProperty(window, 'phonepe', {
    configurable: false,
    enumerable: false,
    writable: false,
    value: provider,
  });

  window.dispatchEvent(new Event('phonepe#initialized'));
})();
