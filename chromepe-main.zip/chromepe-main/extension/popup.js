import {
  createQrSession,
  debitWallet,
  generateTxnId,
  getBalance,
  getQrLinkUrl,
  getTransactions,
  pollQrSession,
  interopDebitVpa,
  mapApiError,
  resolveVpa,
  initiateDelegate,
  pollDelegateStatus,
} from './api.js';
import {
  formatAmount,
  getInitialPopupScreen,
  getInitials,
  normalizeLinkedCredentials,
  splitAmountParts,
  validateVpa,
} from './shared.js';

const state = {
  currentScreen: 'loading',
  pinSetupFirst: '',
  pinConfirmMode: false,
  afterPinVerify: null,
  currentBalanceTab: 'wallet',
  pendingTx: null,
  retryAction: null,
  errorCloseAction: null,
  qrSessionId: null,
  qrPollTimer: null,
  confirmPaySource: 'wallet',  // 'wallet' | 'upi'
  delegatePollTimer: null,
};

const CATEGORY_LABELS = {
  ORDER: 'Merchant payment',
  P2P: 'Wallet transfer',
  UPI_IOP_DEBIT: 'UPI send',
  UPI_IOP_CREDIT: 'UPI received',
  TOPUP: 'Top-up',
  TOPUP_REVERSAL: 'Top-up reversed',
  WITHDRAWAL: 'Withdrawal',
  WITHDRAWAL_REVERSAL: 'Withdrawal reversed',
  REFUND: 'Refund',
  REFUND_REVERSAL: 'Refund reversed',
  CASHBACK: 'Cashback',
  REVERSAL: 'Reversal',
  TOA: 'Transfer of amount',
  MOVEBACK: 'Move back',
};

function relativeTime(epochMs) {
  const diff = Date.now() - epochMs;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min${minutes === 1 ? '' : 's'} ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}

function renderActivityList(transactions) {
  const container = document.getElementById('activity-list');
  if (!container) return;

  if (transactions === null) {
    container.innerHTML = '<div class="caption">Could not load transactions.</div>';
    return;
  }

  if (transactions.length === 0) {
    container.innerHTML = '<div class="caption">No transactions yet.</div>';
    return;
  }

  container.replaceChildren(
    ...transactions.map((tx) => {
      const isDebit = tx.transactionType === 'DEBIT';
      const isFailed = tx.transactionState !== 'SUCCESS';
      const label =
        tx.externalVpa || tx.merchantId || CATEGORY_LABELS[tx.category] || tx.category || 'Transaction';
      const categoryLabel = CATEGORY_LABELS[tx.category] || tx.category || '';
      const time = relativeTime(tx.transactionTime);
      const amountRupees = (tx.amount / 100).toFixed(2);

      const item = document.createElement('div');
      item.className = 'activity-item';
      if (isFailed) item.style.opacity = '0.5';

      item.innerHTML = `
        <div class="activity-left">
          <div class="activity-icon ${isDebit ? 'outgoing' : 'incoming'}">${isDebit ? '↗' : '↙'}</div>
          <div>
            <div style="font-weight:700;">${label}</div>
            <div class="caption">${categoryLabel ? `${categoryLabel} • ` : ''}${time}${isFailed ? ' • Failed' : ''}</div>
          </div>
        </div>
        <div class="${isFailed ? '' : isDebit ? 'amount-negative' : 'amount-positive'}">${isDebit ? '-' : '+'}₹${amountRupees}</div>
      `;

      return item;
    }),
  );
}

// --- Touch ID / WebAuthn helpers ---

async function isTouchIdAvailable() {
  try {
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

async function isTouchIdEnrolled() {
  const { touchIdCredId } = await chrome.storage.local.get(['touchIdCredId']);
  return !!touchIdCredId;
}

async function enrollTouchId() {
  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const credential = await navigator.credentials.create({
    publicKey: {
      challenge,
      rp: { name: 'ChromePe' },
      user: {
        id: crypto.getRandomValues(new Uint8Array(16)),
        name: 'chromepe-user',
        displayName: 'ChromePe User',
      },
      pubKeyCredParams: [
        { alg: -7, type: 'public-key' },
        { alg: -257, type: 'public-key' },
      ],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        userVerification: 'required',
        residentKey: 'preferred',
      },
      timeout: 60000,
    },
  });

  const credId = btoa(String.fromCharCode(...new Uint8Array(credential.rawId)));
  await chrome.storage.local.set({ touchIdCredId: credId });
}

async function verifyWithTouchId() {
  const { touchIdCredId } = await chrome.storage.local.get(['touchIdCredId']);
  if (!touchIdCredId) throw new Error('Touch ID not enrolled');

  const challenge = crypto.getRandomValues(new Uint8Array(32));
  const credIdBytes = Uint8Array.from(atob(touchIdCredId), (c) => c.charCodeAt(0));

  const assertion = await navigator.credentials.get({
    publicKey: {
      challenge,
      allowCredentials: [{ id: credIdBytes, type: 'public-key' }],
      userVerification: 'required',
      timeout: 60000,
    },
  });

  if (!assertion) throw new Error('Touch ID assertion failed');

  // Refresh the PIN session TTL so user isn't re-prompted shortly after
  const { pin } = await chrome.storage.local.get(['pin']);
  if (pin) {
    await chrome.storage.local.set({ pin: { ...pin, lastValidated: Date.now() } });
  }
}

async function disableTouchId() {
  await chrome.storage.local.remove(['touchIdCredId']);
}

function showScreen(screenName) {
  document.querySelectorAll('.screen').forEach((screen) => {
    screen.classList.toggle('active', screen.id === `screen-${screenName}`);
  });

  state.currentScreen = screenName;

  // Stop QR polling when leaving the welcome screen
  if (screenName !== 'welcome' && state.qrPollTimer) {
    clearInterval(state.qrPollTimer);
    state.qrPollTimer = null;
  }
}

function setQrStatus(text, className = '') {
  const el = document.getElementById('qr-status');
  if (el) {
    el.textContent = text;
    el.className = `qr-status ${className}`.trim();
  }
}

async function startQrSession() {
  const qrImage = document.getElementById('qr-image');
  if (!qrImage) return;

  // Stop any existing poll
  if (state.qrPollTimer) {
    clearInterval(state.qrPollTimer);
    state.qrPollTimer = null;
  }

  qrImage.style.display = 'none';
  setQrStatus('Generating QR code...');

  try {
    const sessionId = await createQrSession();
    state.qrSessionId = sessionId;

    const linkUrl = getQrLinkUrl(sessionId);
    // Use QR image API instead of custom generator
    qrImage.src = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(linkUrl)}`;
    qrImage.style.display = 'block';

    setQrStatus('Waiting for device scan...');

    // Poll every 500ms
    state.qrPollTimer = setInterval(async () => {
      try {
        const result = await pollQrSession(sessionId);

        // A concurrent callback already handled the result (linked or expired)
        if (!state.qrPollTimer) return;

        if (result.status === 'linked' && result.credentials) {
          clearInterval(state.qrPollTimer);
          state.qrPollTimer = null;
          state.qrSessionId = null;

          setQrStatus('✓ Device linked!', 'linked');

          const nextCredentials = await persistCredentials(
            result.credentials,
            await getStoredCredentials(),
          );
          populateSettingsForm(nextCredentials);

          // Small delay so user sees the success state
          setTimeout(() => {
            state.pinSetupFirst = '';
            state.pinConfirmMode = false;
            setText('pin-setup-title', 'Set Security PIN');
            setText('pin-setup-hint', 'Create a 4-digit PIN for payments.');
            setError('pin-setup-error');
            showScreen('pin-setup');
            clearPinGroup('pin-setup');
          }, 800);
        } else if (result.status === 'expired') {
          clearInterval(state.qrPollTimer);
          state.qrPollTimer = null;
          setQrStatus('QR expired. Click refresh.', 'error');
        }
      } catch (pollErr) {
        console.warn('[ChromePe] Poll error (will retry):', pollErr);
      }
    }, 500);
  } catch (err) {
    console.error('[ChromePe] QR session error:', err);
    setQrStatus('Failed to connect to relay server.', 'error');
  }
}

function getPinGroup(groupName) {
  return document.querySelector(`[data-pin-group="${groupName}"]`);
}

function clearPinGroup(groupName) {
  const group = getPinGroup(groupName);
  if (!group) {
    return;
  }

  group.querySelectorAll('.pin-digit').forEach((input) => {
    input.value = '';
  });

  group.querySelector('.pin-digit')?.focus();
}

function getPinValue(groupName) {
  const group = getPinGroup(groupName);
  if (!group) {
    return '';
  }

  return Array.from(group.querySelectorAll('.pin-digit'))
    .map((input) => input.value)
    .join('');
}

function attachPinBehavior() {
  document.querySelectorAll('[data-pin-group]').forEach((group) => {
    const inputs = Array.from(group.querySelectorAll('.pin-digit'));

    inputs.forEach((input, index) => {
      input.addEventListener('input', (event) => {
        event.target.value = event.target.value.replace(/\D/g, '').slice(0, 1);
        if (event.target.value && index < inputs.length - 1) {
          inputs[index + 1].focus();
        }
      });

      input.addEventListener('keydown', (event) => {
        if (event.key === 'Backspace' && !event.target.value && index > 0) {
          inputs[index - 1].focus();
        }
      });
    });
  });
}

async function hashPin(pin) {
  const data = new TextEncoder().encode(pin);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, '0'))
    .join('');
}

function encodeBase64Url(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });

  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

async function createWalletPaymentToken({ txnId, amount, currency, receiverVpa, credentials }) {
  const issuedAt = new Date().toISOString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  const payload = {
    iss: 'chromepe-wallet',
    typ: 'merchant-proof',
    txnId,
    amount,
    currency,
    receiverVpa,
    walletId: credentials.walletId || '',
    userId: credentials.userId,
    vpa: credentials.vpa,
    issuedAt,
    expiresAt,
  };

  const signature = await hashPin(
    [
      String(credentials.jwt || ''),
      txnId,
      String(amount),
      currency,
      receiverVpa,
      issuedAt,
      expiresAt,
    ].join(':'),
  );

  return `${encodeBase64Url(JSON.stringify(payload))}.${signature}`;
}

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) {
    element.textContent = value;
  }
}

function setError(id, message = '') {
  setText(id, message);
}

function renderAmountInto(id, amount) {
  const element = document.getElementById(id);
  if (!element) {
    return;
  }

  const { whole, decimal } = splitAmountParts(amount);
  element.innerHTML = `₹${whole}<span class="balance-decimal">${decimal}</span>`;
}

function resetBalanceTabs(activeTab) {
  document.querySelectorAll('.balance-tab').forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.tab === activeTab);
  });
}

function renderExtraSettingsFields(extraFields = {}) {
  const container = document.getElementById('settings-extra-fields');
  const emptyState = document.getElementById('settings-extra-empty');
  if (!container || !emptyState) {
    return;
  }

  container.replaceChildren();
  const entries = Object.entries(extraFields || {})
    .filter(([key, value]) => String(key || '').trim() && String(value ?? '').trim())
    .sort(([left], [right]) => left.localeCompare(right));

  emptyState.hidden = entries.length > 0;

  entries.forEach(([key, value], index) => {
    const fieldGroup = document.createElement('div');
    fieldGroup.className = 'field-group';

    const label = document.createElement('label');
    label.htmlFor = `settings-extra-${index}`;
    label.textContent = key;

    const input = document.createElement('input');
    input.id = `settings-extra-${index}`;
    input.className = 'input';
    input.type = 'text';
    input.value = String(value);
    input.dataset.settingsExtraKey = key;

    fieldGroup.append(label, input);
    container.append(fieldGroup);
  });
}

function readExtraSettingsFields() {
  return Array.from(document.querySelectorAll('[data-settings-extra-key]')).reduce(
    (accumulator, input) => {
      const key = String(input.dataset.settingsExtraKey || '').trim();
      const value = String(input.value || '').trim();
      if (key && value) {
        accumulator[key] = value;
      }
      return accumulator;
    },
    {},
  );
}

function populateSettingsForm(credentials = {}) {
  const normalized = normalizeLinkedCredentials(credentials);
  document.getElementById('settings-jwt').value = normalized.jwt || '';
  document.getElementById('settings-vpa').value = normalized.vpa || '';
  document.getElementById('settings-userid').value = normalized.userId || '';
  document.getElementById('settings-walletid').value = normalized.walletId || '';
  document.getElementById('settings-name').value = normalized.name || '';
  document.getElementById('settings-avatar').value = normalized.avatar || '';
  renderExtraSettingsFields(normalized.extraFields || {});
}

async function persistCredentials(nextCredentials, previousCredentials = {}) {
  const normalized = normalizeLinkedCredentials(nextCredentials, previousCredentials);
  await chrome.storage.local.set({ credentials: normalized });
  return normalized;
}

async function getStoredCredentials() {
  const { credentials } = await chrome.storage.local.get(['credentials']);
  const normalized = normalizeLinkedCredentials(credentials || {});
  if (JSON.stringify(credentials || {}) !== JSON.stringify(normalized)) {
    await chrome.storage.local.set({ credentials: normalized });
  }
  return normalized;
}

function getDashboardPrimaryText(credentials = {}) {
  return credentials.name || credentials.vpa || 'ChromePe';
}

function getDashboardSecondaryText(credentials = {}) {
  if (credentials.name) {
    return [credentials.vpa, credentials.userId].filter(Boolean).join(' • ');
  }

  return credentials.userId || credentials.vpa || '';
}

function getDashboardAvatarText(credentials = {}) {
  const avatar = String(credentials.avatar || '').trim();
  if (avatar) {
    return avatar;
  }

  return getInitials(getDashboardPrimaryText(credentials));
}

async function ensureWalletContext() {
  const credentials = await getStoredCredentials();

  if (!credentials?.jwt || !credentials?.vpa || !credentials?.userId) {
    return {
      ok: false,
      error: 'Save your JWT, VPA, and User ID in Settings first.',
    };
  }

  if (credentials.walletId) {
    return { ok: true, credentials };
  }

  try {
    const result = await getBalance(
      {
        userId: credentials.userId,
        walletId: credentials.walletId,
      },
      credentials.jwt,
    );
    if (!result.success || !result.walletId) {
      return {
        ok: false,
        error: mapApiError(
          result.responseCode,
          result.message || 'Wallet ID could not be resolved from the stage balance API.',
        ),
      };
    }

    const nextCredentials = {
      ...credentials,
      walletId: result.walletId,
    };
    await chrome.storage.local.set({ credentials: nextCredentials });
    populateSettingsForm(nextCredentials);
    return { ok: true, credentials: nextCredentials };
  } catch (error) {
    return {
      ok: false,
      error: mapApiError('NETWORK_ERROR'),
    };
  }
}

async function routeInitialScreen() {
  const stored = await chrome.storage.local.get([
    'onboarded',
    'credentials',
    'pin',
    'pendingTx',
  ]);

  state.pendingTx = stored.pendingTx || null;
  const nextScreen = getInitialPopupScreen(stored);

  if (nextScreen === 'welcome') {
    showScreen('welcome');
    startQrSession();
    return;
  }

  if (nextScreen === 'confirm-tx') {
    showConfirmTx(stored.pendingTx);
    return;
  }

  if (nextScreen === 'pin-verify') {
    openPinVerify('Session expired. Please re-enter your PIN.', showDashboard);
    return;
  }

  await showDashboard();
}

async function showDashboard() {
  showScreen('dashboard');
  state.pendingTx = null;
  state.retryAction = null;
  state.errorCloseAction = null;

  const credentials = await getStoredCredentials();
  if (!credentials?.vpa || !credentials?.userId) {
    showScreen('credentials');
    return;
  }

  setText('dashboard-vpa', getDashboardPrimaryText(credentials));
  setText('dashboard-userid', getDashboardSecondaryText(credentials));
  setText('dashboard-initials', getDashboardAvatarText(credentials));
  populateSettingsForm(credentials);

  state.currentBalanceTab = 'wallet';
  resetBalanceTabs('wallet');

  // Fetch balance and transaction history in parallel
  const [, txResult] = await Promise.allSettled([
    renderBalanceTab('wallet'),
    getTransactions({ userId: credentials.userId }, credentials.jwt),
  ]);

  if (txResult.status === 'fulfilled' && txResult.value.success) {
    renderActivityList(txResult.value.transactions);
  } else {
    renderActivityList(null);
  }
}

async function openSettingsScreen() {
  populateSettingsForm(await getStoredCredentials());
  setError('settings-error');
  showScreen('settings');
  await renderTouchIdSettings();
}

async function renderTouchIdSettings() {
  const row = document.getElementById('settings-touchid-row');
  const unavailable = document.getElementById('settings-touchid-unavailable');
  const statusEl = document.getElementById('settings-touchid-status');
  const btnEnable = document.getElementById('btn-enable-touchid');
  const btnDisable = document.getElementById('btn-disable-touchid');
  if (!row || !unavailable || !statusEl || !btnEnable || !btnDisable) return;

  const available = await isTouchIdAvailable();
  if (!available) {
    row.style.display = 'none';
    unavailable.style.display = '';
    return;
  }

  unavailable.style.display = 'none';
  row.style.display = '';

  const enrolled = await isTouchIdEnrolled();
  if (enrolled) {
    statusEl.textContent = '✓ Touch ID is enabled for logins and payments.';
    btnEnable.style.display = 'none';
    btnDisable.style.display = '';
  } else {
    statusEl.textContent = 'Touch ID is not enrolled.';
    btnEnable.style.display = '';
    btnDisable.style.display = 'none';
  }
}

async function renderBalanceTab(tabName) {
  state.currentBalanceTab = tabName;
  resetBalanceTabs(tabName);

  if (tabName === 'wallet') {
    setText('balance-amount', 'Loading...');
    try {
      const credentials = await getStoredCredentials();
      const result = await getBalance(
        {
          userId: credentials.userId,
          walletId: credentials.walletId,
        },
        credentials.jwt,
      );

      if (!result.success) {
        setText('balance-amount', 'Unavailable');
        return;
      }

      if (result.walletId && result.walletId !== credentials.walletId) {
        const nextCredentials = await persistCredentials(
          {
          ...credentials,
          walletId: result.walletId,
          },
          credentials,
        );
        populateSettingsForm(nextCredentials);
      }

      renderAmountInto('balance-amount', result.balanceInRupees);
    } catch (error) {
      setText('balance-amount', 'Unavailable');
    }
    return;
  }

  if (tabName === 'upilite') {
    renderAmountInto('balance-amount', 2000);
    return;
  }

  renderAmountInto('balance-amount', 500);
}

async function openPinVerify(context, onSuccess) {
  state.afterPinVerify = onSuccess;
  setText('pin-verify-context', context);
  setError('pin-verify-error');
  setError('pin-verify-touchid-error');
  showScreen('pin-verify');
  clearPinGroup('pin-verify');

  // Show Touch ID section if enrolled
  const touchSection = document.getElementById('pin-verify-touchid-section');
  if (touchSection) {
    const enrolled = await isTouchIdEnrolled();
    touchSection.style.display = enrolled ? '' : 'none';
  }
}

function showProcessing(message) {
  setText('processing-message', message);
  showScreen('processing');
}

function showSuccess(txnId, amount, message = 'Your payment has been completed.') {
  setText('success-message', message);
  setText('success-txn-id', txnId || 'Pending');
  setText('success-amount', formatAmount(amount));
  showScreen('success');
}

function showError(message, retryAction, closeAction = showDashboard) {
  setText('error-message', message);
  state.retryAction = retryAction || null;
  state.errorCloseAction = closeAction || showDashboard;
  showScreen('error');
}

async function showConfirmTx(pendingTx) {
  if (!pendingTx) {
    showDashboard();
    return;
  }

  state.pendingTx = pendingTx;
  state.confirmPaySource = 'wallet'; // reset to wallet on each new tx
  showScreen('confirm-tx');
  setText('confirm-merchant-vpa', pendingTx.receiverVpa);
  setText('confirm-merchant-initials', getInitials(pendingTx.receiverVpa));
  setText('confirm-currency', pendingTx.currency || 'INR');
  setText('confirm-amount', formatAmount(pendingTx.amount));
  setError('confirm-pin-error');
  setError('confirm-touchid-error');
  clearPinGroup('confirm-tx');

  // Wire pay-source toggle buttons
  const paySourceBtns = document.querySelectorAll(
    '#screen-confirm-tx .pay-source:not(.disabled)',
  );
  const enrolled = await isTouchIdEnrolled();
  paySourceBtns.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.source === 'wallet');
    btn.onclick = () => {
      state.confirmPaySource = btn.dataset.source;
      paySourceBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // Show/hide PIN section depending on source
      const pinSection = document.getElementById('confirm-pin-label')?.closest('.field-group');
      const pinGroup = document.querySelector('[data-pin-group="confirm-tx"]');
      const touchSection = document.getElementById('confirm-touchid-section');
      const isUpi = state.confirmPaySource === 'upi';
      if (pinSection) pinSection.style.display = isUpi ? 'none' : '';
      if (pinGroup) pinGroup.style.display = isUpi ? 'none' : '';
      if (touchSection) touchSection.style.display = (isUpi || !enrolled) ? 'none' : '';
      setText('btn-confirm-pay', isUpi
        ? `📱 Send ₹${pendingTx.amount} via UPI to Phone`
        : (enrolled
            ? `Confirm with PIN ${formatAmount(pendingTx.amount)}`
            : `Confirm & Pay ${formatAmount(pendingTx.amount)}`));
    };
  });

  // Show Touch ID as primary if enrolled (already fetched above)
  const touchSection = document.getElementById('confirm-touchid-section');
  if (touchSection) {
    touchSection.style.display = enrolled ? '' : 'none';
    setText('btn-confirm-pay', enrolled
      ? `Confirm with PIN ${formatAmount(pendingTx.amount)}`
      : `Confirm & Pay ${formatAmount(pendingTx.amount)}`);
    if (enrolled) {
      setText('btn-confirm-touchid', `☝ Pay ${formatAmount(pendingTx.amount)} with Touch ID`);
    }
  } else {
    setText('btn-confirm-pay', `Confirm & Pay ${formatAmount(pendingTx.amount)}`);
  }
}

async function notifyMerchantResult(action, txContext, extras = {}) {
  if (!txContext?.requestId || txContext.source !== 'sdk') {
    return;
  }

  await chrome.runtime.sendMessage({
    action,
    requestId: txContext.requestId,
    tabId: txContext.tabId,
    amount: txContext.amount,
    currency: txContext.currency,
    receiverVpa: txContext.receiverVpa,
    redirectUrl: txContext.redirectUrl || '',
    ...extras,
  });
}

async function verifyStoredPin(pin) {
  const { pin: storedPin } = await chrome.storage.local.get(['pin']);
  if (!storedPin?.hash) {
    return false;
  }

  const hash = await hashPin(pin);
  if (hash !== storedPin.hash) {
    return false;
  }

  await chrome.storage.local.set({
    pin: {
      ...storedPin,
      lastValidated: Date.now(),
    },
  });

  return true;
}

async function handleManualSend() {
  const destinationVpa = document.getElementById('send-vpa').value.trim();
  const amount = Number(document.getElementById('send-amount').value);
  const currency = document.getElementById('send-currency').value;

  if (!destinationVpa) {
    setError('send-error', 'Destination VPA is required.');
    return;
  }

  if (!Number.isFinite(amount) || amount <= 0) {
    setError('send-error', 'Enter a valid amount.');
    return;
  }

  // Fast format check before hitting the network
  const fmtCheck = validateVpa(destinationVpa);
  if (!fmtCheck.valid) {
    setError('send-error', fmtCheck.error);
    return;
  }

  // Resolve VPA via payment service — confirms it exists and retrieves payee name
  setError('send-error');
  document.getElementById('send-error').textContent = '🔍 Verifying VPA…';

  const walletContext = await ensureWalletContext();
  if (!walletContext.ok) {
    setError('send-error', walletContext.error);
    return;
  }

  const { credentials } = walletContext;
  const vpaResolution = await resolveVpa(
    { userId: credentials.userId, vpa: destinationVpa },
    credentials.jwt,
  );

  setError('send-error'); // clear verifying message

  if (vpaResolution.valid === false) {
    // Definitive failure — VPA does not exist
    setError('send-error', vpaResolution.error);
    return;
  }

  // Build a confirmation message that includes payee name when resolved
  const payeeLabel =
    vpaResolution.valid === true
      ? `${vpaResolution.name} (${destinationVpa})`
      : destinationVpa;

  openPinVerify(
    `Send ${formatAmount(amount)} to ${payeeLabel}?`,
    async () => {
      showProcessing('Sending money through the wallet service...');

      try {
        const walletContext = await ensureWalletContext();
        if (!walletContext.ok) {
          showError(walletContext.error, handleManualSend, openSettingsScreen);
          return;
        }

        const { credentials } = walletContext;
        const txnId = generateTxnId();
        const result = await interopDebitVpa(
          {
            userId: credentials.userId,
            walletId: credentials.walletId,
            senderVpa: credentials.vpa,
            receiverVpa: destinationVpa,
            amount,
            currency,
            transactionId: txnId,
            message: 'ChromePe direct send',
          },
          credentials.jwt,
        );

        if (!result.success) {
          showError(
            mapApiError(result.responseCode, result.message),
            handleManualSend,
            showDashboard,
          );
          return;
        }

        showSuccess(txnId, amount, 'UPI wallet debit completed successfully.');
      } catch (error) {
        showError(
          mapApiError('NETWORK_ERROR'),
          handleManualSend,
          showDashboard,
        );
      }
    },
  );
}

async function executeConfirmedPayment() {
  const { pendingTx } = await chrome.storage.local.get(['pendingTx']);
  const activeTx = pendingTx || state.pendingTx;

  if (!activeTx) {
    showDashboard();
    return;
  }

  showProcessing('Confirming payment with the merchant...');

  try {
    const walletContext = await ensureWalletContext();
    if (!walletContext.ok) {
      showError(walletContext.error, () => showConfirmTx(activeTx), openSettingsScreen);
      return;
    }

    const { credentials } = walletContext;
    const txnId = generateTxnId();
    const result = await debitWallet(
      {
        userId: credentials.userId,
        walletId: credentials.walletId,
        merchantId: activeTx.receiverVpa,
        amount: activeTx.amount,
        currency: activeTx.currency,
        transactionId: txnId,
      },
      credentials.jwt,
    );

    if (!result.success) {
      await notifyMerchantResult('PAY_REJECTED', activeTx, {
        success: false,
        error: mapApiError(result.responseCode, result.message),
        code: result.responseCode,
      });
      showError(
        mapApiError(result.responseCode, result.message),
        () => showConfirmTx(activeTx),
        showDashboard,
      );
      return;
    }

    const paymentToken = await createWalletPaymentToken({
      txnId,
      amount: activeTx.amount,
      currency: activeTx.currency,
      receiverVpa: activeTx.receiverVpa,
      credentials,
    });

    await notifyMerchantResult('PAY_CONFIRMED', activeTx, {
      success: true,
      txnId,
      paymentToken,
    });
    state.pendingTx = null;
    showSuccess(txnId, activeTx.amount, 'Merchant payment completed successfully.');
  } catch (error) {
    const { pendingTx: retryTx } = await chrome.storage.local.get(['pendingTx']);
    const retryActiveTx = retryTx || state.pendingTx;
    await notifyMerchantResult('PAY_REJECTED', retryActiveTx, {
      success: false,
      error: mapApiError('NETWORK_ERROR'),
      code: 'NETWORK_ERROR',
    });
    showError(
      mapApiError('NETWORK_ERROR'),
      () => showConfirmTx(retryActiveTx),
      showDashboard,
    );
  }
}

async function handleTouchIdSdkPayment() {
  setError('confirm-touchid-error');
  try {
    await verifyWithTouchId();
  } catch {
    setError('confirm-touchid-error', 'Touch ID failed. Use PIN instead.');
    return;
  }
  await executeConfirmedPayment();
}

async function handleSdkPayment() {
  // If UPI is selected, skip PIN and use delegate flow instead
  if (state.confirmPaySource === 'upi') {
    await handleDelegatePayment();
    return;
  }

  const pin = getPinValue('confirm-tx');
  if (pin.length !== 4) {
    setError('confirm-pin-error', 'Enter your 4-digit PIN.');
    return;
  }

  const pinValid = await verifyStoredPin(pin);
  if (!pinValid) {
    setError('confirm-pin-error', 'Incorrect PIN.');
    clearPinGroup('confirm-tx');
    return;
  }

  await executeConfirmedPayment();
}

/**
 * Initiate a delegate (UPI via phone) payment.
 * 1. Calls Cloudflare /payment/initiate
 * 2. Shows the waiting screen with txnId
 * 3. Polls /payment/:txnId/status every 2s
 * 4. On COMPLETED → success; on FAILED/EXPIRED → error
 */
async function handleDelegatePayment() {
  const { pendingTx } = await chrome.storage.local.get(['pendingTx']);
  const activeTx = pendingTx || state.pendingTx;

  if (!activeTx) {
    showDashboard();
    return;
  }

  // Need the logged-in user's VPA as the payer — the worker stores pending:{payerVpa} in KV
  const walletContext = await ensureWalletContext();
  if (!walletContext.ok) {
    showError(walletContext.error, () => showConfirmTx(activeTx), openSettingsScreen);
    return;
  }
  const { credentials } = walletContext;

  const merchantName = activeTx.receiverVpa.split('@')[0] || activeTx.receiverVpa;
  const description = `Pay ₹${activeTx.amount} to ${activeTx.receiverVpa}`;

  let txnId;
  try {
    const result = await initiateDelegate({
      amount: activeTx.amount,
      vpa: credentials.vpa,          // payer's VPA — app polls with this
      merchantName,
      description,
    });
    txnId = result.txnId;
  } catch (err) {
    showError(
      `Could not initiate UPI payment: ${err.message}`,
      () => showConfirmTx(activeTx),
      showDashboard,
    );
    return;
  }

  // Show waiting screen
  showScreen('delegate-waiting');
  setText('delegate-waiting-amount', formatAmount(activeTx.amount));
  setText('delegate-waiting-vpa', activeTx.receiverVpa);
  setText('delegate-waiting-txnid', txnId);
  setText('delegate-waiting-message',
    `Open your ChromePe app and approve the ₹${activeTx.amount} payment to ${merchantName}.`,
  );

  // Stop any previous poll
  if (state.delegatePollTimer) {
    clearInterval(state.delegatePollTimer);
    state.delegatePollTimer = null;
  }

  state.delegatePollTimer = setInterval(async () => {
    try {
      const statusData = await pollDelegateStatus(txnId);
      console.log('[ChromePe] delegate poll:', txnId, statusData.status);
      if (statusData.status === 'SUCCESS' || statusData.status === 'COMPLETED') {
        clearInterval(state.delegatePollTimer);
        state.delegatePollTimer = null;
        state.pendingTx = null;
        await notifyMerchantResult('PAY_CONFIRMED', activeTx, {
          success: true,
          txnId,
          paymentToken: null,
        });
        showSuccess(txnId, activeTx.amount, 'UPI payment approved on your phone.');
      } else if (statusData.status === 'FAILED' || statusData.status === 'EXPIRED' || statusData.status === 'FAILURE') {
        clearInterval(state.delegatePollTimer);
        state.delegatePollTimer = null;
        await notifyMerchantResult('PAY_REJECTED', activeTx, {
          success: false,
          error: `Payment ${statusData.status.toLowerCase()}`,
          code: statusData.status,
        });
        showError(
          `UPI payment ${statusData.status.toLowerCase()}. Please try again.`,
          () => showConfirmTx(activeTx),
          showDashboard,
        );
      }
    } catch {
      // Network hiccup — keep polling
    }
  }, 2000);
}

function attachEventHandlers() {
  document.getElementById('btn-get-started').addEventListener('click', () => {
    if (state.qrPollTimer) {
      clearInterval(state.qrPollTimer);
      state.qrPollTimer = null;
    }
    showScreen('credentials');
  });

  document.getElementById('btn-refresh-qr').addEventListener('click', () => {
    startQrSession();
  });

  document.getElementById('btn-save-credentials').addEventListener('click', async () => {
    const jwt = document.getElementById('input-jwt').value.trim();
    const vpa = document.getElementById('input-vpa').value.trim();
    const userId = document.getElementById('input-userid').value.trim();

    if (!jwt || !vpa || !userId) {
      setError('credentials-error', 'All credential fields are required.');
      return;
    }

    setError('credentials-error');
    await persistCredentials({ jwt, vpa, userId, walletId: '' });

    state.pinSetupFirst = '';
    state.pinConfirmMode = false;
    setText('pin-setup-title', 'Set Security PIN');
    setText('pin-setup-hint', 'Create a 4-digit PIN for payments.');
    setError('pin-setup-error');
    showScreen('pin-setup');
    clearPinGroup('pin-setup');
  });

  document.getElementById('btn-confirm-pin').addEventListener('click', async () => {
    const pin = getPinValue('pin-setup');

    if (pin.length !== 4) {
      setError('pin-setup-error', 'Enter a 4-digit PIN.');
      return;
    }

    if (!state.pinConfirmMode) {
      state.pinSetupFirst = pin;
      state.pinConfirmMode = true;
      setText('pin-setup-title', 'Re-enter PIN to Confirm');
      setText('pin-setup-hint', 'Enter the same 4 digits again.');
      setError('pin-setup-error');
      clearPinGroup('pin-setup');
      return;
    }

    if (pin !== state.pinSetupFirst) {
      state.pinSetupFirst = '';
      state.pinConfirmMode = false;
      setText('pin-setup-title', 'Set Security PIN');
      setText('pin-setup-hint', 'Create a 4-digit PIN for payments.');
      setError('pin-setup-error', 'PINs do not match. Try again.');
      clearPinGroup('pin-setup');
      return;
    }

    const hash = await hashPin(pin);
    await chrome.storage.local.set({
      onboarded: true,
      pin: {
        hash,
        lastValidated: Date.now(),
      },
    });

    state.pinSetupFirst = '';
    state.pinConfirmMode = false;

    // Offer Touch ID enrollment if the platform supports it
    const touchAvailable = await isTouchIdAvailable();
    if (touchAvailable) {
      const enableNow = window.confirm(
        'Touch ID is available. Enable it for faster logins and payments?',
      );
      if (enableNow) {
        try {
          await enrollTouchId();
        } catch {
          // Silent - user can enable later from Settings
        }
      }
    }

    await showDashboard();
  });

  document.getElementById('btn-verify-pin').addEventListener('click', async () => {
    const pin = getPinValue('pin-verify');
    if (pin.length !== 4) {
      setError('pin-verify-error', 'Enter your 4-digit PIN.');
      return;
    }

    const pinValid = await verifyStoredPin(pin);
    if (!pinValid) {
      setError('pin-verify-error', 'Incorrect PIN.');
      clearPinGroup('pin-verify');
      return;
    }

    setError('pin-verify-error');
    const nextAction = state.afterPinVerify;
    state.afterPinVerify = null;
    if (typeof nextAction === 'function') {
      await nextAction();
    }
  });

  document.getElementById('btn-verify-touchid').addEventListener('click', async () => {
    setError('pin-verify-touchid-error');
    try {
      await verifyWithTouchId();
    } catch {
      setError('pin-verify-touchid-error', 'Touch ID failed. Use PIN instead.');
      return;
    }
    const nextAction = state.afterPinVerify;
    state.afterPinVerify = null;
    if (typeof nextAction === 'function') {
      await nextAction();
    }
  });

  document.getElementById('btn-confirm-touchid').addEventListener('click', handleTouchIdSdkPayment);

  document.querySelectorAll('.balance-tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      renderBalanceTab(tab.dataset.tab);
    });
  });

  document.getElementById('btn-refresh-balance').addEventListener('click', async () => {
    await renderBalanceTab(state.currentBalanceTab);
  });

  document.getElementById('btn-settings').addEventListener('click', openSettingsScreen);
  document.getElementById('btn-settings-back').addEventListener('click', showDashboard);

  document.getElementById('btn-enable-touchid').addEventListener('click', async () => {
    try {
      await enrollTouchId();
      await renderTouchIdSettings();
    } catch {
      setError('settings-error', 'Touch ID enrollment failed. Try again.');
    }
  });

  document.getElementById('btn-disable-touchid').addEventListener('click', async () => {
    await disableTouchId();
    await renderTouchIdSettings();
  });

  document.getElementById('btn-save-settings').addEventListener('click', async () => {
    const jwt = document.getElementById('settings-jwt').value.trim();
    const vpa = document.getElementById('settings-vpa').value.trim();
    const userId = document.getElementById('settings-userid').value.trim();
    const walletId = document.getElementById('settings-walletid').value.trim();
    const name = document.getElementById('settings-name').value.trim();
    const avatar = document.getElementById('settings-avatar').value.trim();

    if (!jwt || !vpa || !userId) {
      setError('settings-error', 'JWT, VPA, and User ID are required.');
      return;
    }

    setError('settings-error');
    const currentCredentials = await getStoredCredentials();
    const nextCredentials = await persistCredentials(
      {
        ...currentCredentials,
        jwt,
        vpa,
        userId,
        walletId,
        name,
        avatar,
        extraFields: readExtraSettingsFields(),
      },
      currentCredentials,
    );
    populateSettingsForm(nextCredentials);
    await showDashboard();
  });

  document.getElementById('btn-reset-storage').addEventListener('click', async () => {
    if (!window.confirm('Reset ChromePe and clear saved wallet data?')) {
      return;
    }

    await chrome.storage.local.clear();
    showScreen('welcome');
    startQrSession();
  });

  document.getElementById('btn-open-send').addEventListener('click', () => {
    setError('send-error');
    showScreen('send');
  });

  document.getElementById('btn-back-dashboard').addEventListener('click', showDashboard);
  document.getElementById('btn-send-pay').addEventListener('click', handleManualSend);

  document.getElementById('btn-receive').addEventListener('click', async () => {
    const credentials = await getStoredCredentials();
    try {
      await navigator.clipboard.writeText(credentials.vpa);
      alert(`Copied ${credentials.vpa} to clipboard.`);
    } catch (error) {
      alert(`Your receive VPA is ${credentials.vpa}`);
    }
  });

  document.querySelectorAll('.pay-source').forEach((button) => {
    button.addEventListener('click', () => {
      // 'upi' is now supported via delegate payment; only block truly disabled sources
      if (button.classList.contains('disabled')) {
        alert('This payment method is not available yet.');
        return;
      }

      if (button.dataset.source !== 'wallet' && button.dataset.source !== 'upi') {
        alert('Only Wallet and UPI are active in this demo.');
        return;
      }

      button
        .closest('.pay-sources')
        .querySelectorAll('.pay-source')
        .forEach((source) => {
          source.classList.toggle('active', source.dataset.source === button.dataset.source);
        });
    });
  });

  document.getElementById('btn-confirm-pay').addEventListener('click', handleSdkPayment);

  document.getElementById('btn-delegate-cancel').addEventListener('click', async () => {
    if (state.delegatePollTimer) {
      clearInterval(state.delegatePollTimer);
      state.delegatePollTimer = null;
    }
    const { pendingTx } = await chrome.storage.local.get(['pendingTx']);
    const activeTx = pendingTx || state.pendingTx;
    await notifyMerchantResult('PAY_REJECTED', activeTx, {
      success: false,
      error: 'User cancelled UPI payment.',
      code: 'REJECTED',
    });
    state.pendingTx = null;
    await showDashboard();
  });

  document.getElementById('btn-reject-tx').addEventListener('click', async () => {
    const { pendingTx } = await chrome.storage.local.get(['pendingTx']);
    const activeTx = pendingTx || state.pendingTx;
    await notifyMerchantResult('PAY_REJECTED', activeTx, {
      success: false,
      error: 'User rejected payment.',
      code: 'REJECTED',
    });
    state.pendingTx = null;
    await showDashboard();
  });

  document.getElementById('btn-success-done').addEventListener('click', showDashboard);

  document.getElementById('btn-error-retry').addEventListener('click', () => {
    if (typeof state.retryAction === 'function') {
      state.retryAction();
      return;
    }
    showDashboard();
  });

  document.getElementById('btn-error-close').addEventListener('click', () => {
    if (typeof state.errorCloseAction === 'function') {
      state.errorCloseAction();
      return;
    }
    showDashboard();
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  attachPinBehavior();
  attachEventHandlers();
  await routeInitialScreen();
});
