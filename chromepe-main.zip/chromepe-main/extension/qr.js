/**
 * Minimal QR Code generator for ChromePe extension.
 * Generates a QR code and draws it onto a canvas element.
 * Based on the QR Code specification (ISO/IEC 18004).
 * Supports up to ~150 chars (version 1-6, error correction L).
 */

const QR = (() => {
  // Galois field arithmetic for Reed-Solomon
  const EXP = new Uint8Array(256);
  const LOG = new Uint8Array(256);
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x = (x << 1) ^ (x & 128 ? 0x11d : 0);
  }
  EXP[255] = EXP[0];

  function gfMul(a, b) {
    return a && b ? EXP[(LOG[a] + LOG[b]) % 255] : 0;
  }

  function rsGenPoly(n) {
    let poly = [1];
    for (let i = 0; i < n; i++) {
      const next = new Array(poly.length + 1).fill(0);
      for (let j = 0; j < poly.length; j++) {
        next[j] ^= poly[j];
        next[j + 1] ^= gfMul(poly[j], EXP[i]);
      }
      poly = next;
    }
    return poly;
  }

  function rsEncode(data, ecLen) {
    const gen = rsGenPoly(ecLen);
    const msg = new Uint8Array(data.length + ecLen);
    msg.set(data);
    for (let i = 0; i < data.length; i++) {
      const coef = msg[i];
      if (coef) {
        for (let j = 0; j < gen.length; j++) {
          msg[i + j] ^= gfMul(gen[j], coef);
        }
      }
    }
    return msg.slice(data.length);
  }

  // Version capacity (byte mode, EC level L)
  const VERSIONS = [
    null,
    { total: 26, data: 19, ec: 7, ecBlocks: [1] },
    { total: 44, data: 34, ec: 10, ecBlocks: [1] },
    { total: 70, data: 55, ec: 15, ecBlocks: [1] },
    { total: 100, data: 80, ec: 20, ecBlocks: [1] },
    { total: 134, data: 108, ec: 26, ecBlocks: [1] },
    { total: 172, data: 136, ec: 18, ecBlocks: [2] },
  ];

  function chooseVersion(len) {
    for (let v = 1; v <= 6; v++) {
      if (len <= VERSIONS[v].data) return v;
    }
    throw new Error('Data too long for QR (max ~136 bytes for version 6-L)');
  }

  function encodeData(text, version) {
    const vInfo = VERSIONS[version];
    const bytes = new TextEncoder().encode(text);
    const bits = [];

    function pushBits(val, len) {
      for (let i = len - 1; i >= 0; i--) bits.push((val >> i) & 1);
    }

    // Mode: byte (0100)
    pushBits(0b0100, 4);
    // Character count (8 bits for versions 1-9)
    pushBits(bytes.length, 8);
    // Data
    for (const b of bytes) pushBits(b, 8);
    // Terminator
    const maxBits = vInfo.data * 8;
    const termLen = Math.min(4, maxBits - bits.length);
    pushBits(0, termLen);
    // Pad to byte boundary
    while (bits.length % 8) bits.push(0);
    // Pad bytes
    const padBytes = [0xec, 0x11];
    let pi = 0;
    while (bits.length < maxBits) {
      pushBits(padBytes[pi % 2], 8);
      pi++;
    }

    const dataBytes = new Uint8Array(bits.length / 8);
    for (let i = 0; i < dataBytes.length; i++) {
      let val = 0;
      for (let b = 0; b < 8; b++) val = (val << 1) | bits[i * 8 + b];
      dataBytes[i] = val;
    }

    return dataBytes;
  }

  function createMatrix(version) {
    const size = version * 4 + 17;
    const matrix = Array.from({ length: size }, () => new Uint8Array(size));
    const reserved = Array.from({ length: size }, () => new Uint8Array(size));
    return { matrix, reserved, size };
  }

  function setModule(m, r, x, y, val) {
    m.matrix[y][x] = val ? 1 : 0;
    r.reserved[y][x] = 1;
  }

  function addFinderPattern(m, r, cx, cy) {
    for (let dy = -4; dy <= 4; dy++) {
      for (let dx = -4; dx <= 4; dx++) {
        const x = cx + dx, y = cy + dy;
        if (x < 0 || y < 0 || x >= m.size || y >= m.size) continue;
        const adx = Math.abs(dx), ady = Math.abs(dy);
        const max = Math.max(adx, ady);
        const val = max === 4 ? 0 : max === 3 ? 1 : max === 2 ? 0 : 1;
        setModule(m, r, x, y, val);
      }
    }
  }

  function addAlignmentPattern(m, r, cx, cy) {
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const ad = Math.max(Math.abs(dx), Math.abs(dy));
        setModule(m, r, cx + dx, cy + dy, ad === 2 ? 1 : ad === 1 ? 0 : 1);
      }
    }
  }

  function addTimingPatterns(m, r) {
    for (let i = 8; i < m.size - 8; i++) {
      const val = i % 2 === 0 ? 1 : 0;
      if (!r.reserved[6][i]) setModule(m, r, i, 6, val);
      if (!r.reserved[i][6]) setModule(m, r, 6, i, val);
    }
  }

  function reserveFormatArea(m, r) {
    // Around top-left finder
    for (let i = 0; i <= 8; i++) {
      if (i < m.size) { r.reserved[8][i] = 1; r.reserved[i][8] = 1; }
    }
    // Around top-right finder
    for (let i = 0; i <= 7; i++) {
      r.reserved[8][m.size - 1 - i] = 1;
    }
    // Around bottom-left finder
    for (let i = 0; i <= 7; i++) {
      r.reserved[m.size - 1 - i][8] = 1;
    }
    // Dark module
    setModule(m, r, 8, m.size - 8, 1);
  }

  function placeData(m, r, dataStream) {
    let bitIdx = 0;
    let upward = true;
    for (let col = m.size - 1; col >= 0; col -= 2) {
      if (col === 6) col = 5; // skip timing column
      const rows = upward
        ? Array.from({ length: m.size }, (_, i) => m.size - 1 - i)
        : Array.from({ length: m.size }, (_, i) => i);

      for (const row of rows) {
        for (const c of [col, col - 1]) {
          if (c < 0 || r.reserved[row][c]) continue;
          m.matrix[row][c] = bitIdx < dataStream.length ? dataStream[bitIdx++] : 0;
        }
      }
      upward = !upward;
    }
  }

  function applyMask(m, r, maskId) {
    const maskFn = [
      (r, c) => (r + c) % 2 === 0,
      (r) => r % 2 === 0,
      (_, c) => c % 3 === 0,
      (r, c) => (r + c) % 3 === 0,
      (r, c) => (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0,
      (r, c) => ((r * c) % 2) + ((r * c) % 3) === 0,
      (r, c) => (((r * c) % 2) + ((r * c) % 3)) % 2 === 0,
      (r, c) => (((r + c) % 2) + ((r * c) % 3)) % 2 === 0,
    ][maskId];

    for (let y = 0; y < m.size; y++) {
      for (let x = 0; x < m.size; x++) {
        if (!r.reserved[y][x] && maskFn(y, x)) {
          m.matrix[y][x] ^= 1;
        }
      }
    }
  }

  function writeFormatInfo(m, maskId) {
    // EC level L = 01, mask pattern
    const data = (0b01 << 3) | maskId;
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >> 9) * 0x537);
    const bits = ((data << 10) | rem) ^ 0x5412;

    const formatPositions1 = [
      [0, 8], [1, 8], [2, 8], [3, 8], [4, 8], [5, 8], [7, 8], [8, 8],
      [8, 7], [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], [8, 0],
    ];
    const formatPositions2 = [];
    for (let i = 0; i < 8; i++) formatPositions2.push([8, m.size - 1 - i]);
    for (let i = 0; i < 7; i++) formatPositions2.push([m.size - 7 + i, 8]);

    for (let i = 0; i < 15; i++) {
      const bit = (bits >> (14 - i)) & 1;
      const [y1, x1] = formatPositions1[i];
      m.matrix[y1][x1] = bit;
      if (i < formatPositions2.length) {
        const [y2, x2] = formatPositions2[i];
        m.matrix[y2][x2] = bit;
      }
    }
  }

  function generate(text) {
    const version = chooseVersion(new TextEncoder().encode(text).length);
    const vInfo = VERSIONS[version];
    const dataBytes = encodeData(text, version);

    // Reed-Solomon
    const ecBytesPerBlock = vInfo.ec;
    const numBlocks = vInfo.ecBlocks.reduce((s, n) => s + n, 0);
    const blockDataSize = Math.floor(dataBytes.length / numBlocks);

    const dataBlocks = [];
    const ecBlocks = [];
    let offset = 0;
    for (let i = 0; i < numBlocks; i++) {
      const block = dataBytes.slice(offset, offset + blockDataSize);
      dataBlocks.push(block);
      ecBlocks.push(rsEncode(block, ecBytesPerBlock));
      offset += blockDataSize;
    }

    // Interleave
    const interleaved = [];
    const maxDataLen = Math.max(...dataBlocks.map((b) => b.length));
    for (let i = 0; i < maxDataLen; i++) {
      for (const block of dataBlocks) {
        if (i < block.length) interleaved.push(block[i]);
      }
    }
    for (let i = 0; i < ecBytesPerBlock; i++) {
      for (const block of ecBlocks) {
        if (i < block.length) interleaved.push(block[i]);
      }
    }

    // Convert to bit stream
    const bitStream = [];
    for (const byte of interleaved) {
      for (let b = 7; b >= 0; b--) bitStream.push((byte >> b) & 1);
    }

    // Build matrix
    const { matrix, reserved, size } = createMatrix(version);
    const m = { matrix, size };
    const r = { reserved };

    addFinderPattern(m, r, 3, 3);
    addFinderPattern(m, r, size - 4, 3);
    addFinderPattern(m, r, 3, size - 4);

    // Alignment patterns (version 2+)
    if (version >= 2) {
      const positions = [6, version * 4 + 10];
      for (const ay of positions) {
        for (const ax of positions) {
          if (r.reserved[ay][ax]) continue;
          addAlignmentPattern(m, r, ax, ay);
        }
      }
    }

    addTimingPatterns(m, r);
    reserveFormatArea(m, r);
    placeData(m, r, bitStream);
    applyMask(m, r, 0); // mask 0
    writeFormatInfo(m, 0);

    return { matrix: m.matrix, size };
  }

  function drawCanvas(canvas, text, opts = {}) {
    const { scale = 4, darkColor = '#5f259f', lightColor = '#ffffff', quietZone = 4 } = opts;
    const { matrix, size } = generate(text);
    const totalSize = size + quietZone * 2;
    canvas.width = totalSize * scale;
    canvas.height = totalSize * scale;

    const ctx = canvas.getContext('2d');
    ctx.fillStyle = lightColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = darkColor;
    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        if (matrix[y][x]) {
          ctx.fillRect((x + quietZone) * scale, (y + quietZone) * scale, scale, scale);
        }
      }
    }
  }

  return { generate, drawCanvas };
})();

export default QR;
