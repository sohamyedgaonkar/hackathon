export const PIN_SESSION_MS = 5 * 60 * 1000;

// Registered UPI bank handles (covers ~99% of real-world usage).
// Handles NOT in this set trigger a typo warning before sending.
const KNOWN_UPI_HANDLES = new Set([
  // PhonePe / Yes Bank
  'ybl',
  // Google Pay
  'okhdfcbank', 'okicici', 'oksbi', 'okaxis',
  // Paytm
  'paytm', 'ptyes', 'pthdfc', 'ptaxis', 'ptkotak', 'ptidfc', 'ptpnb',
  // Amazon Pay
  'apl',
  // BHIM / NPCI
  'upi', 'bhim',
  // CRED / Axis
  'axl',
  // Major bank direct handles
  'icici', 'hdfcbank', 'sbi', 'axisbank', 'kotak', 'idfcbank', 'idfc',
  'indus', 'pnb', 'unionbank', 'bob', 'cnrb', 'federal', 'rbl',
  'aubank', 'idbi', 'dcb', 'lvb', 'kvb', 'tmb', 'karb', 'fbl',
  'centralbank', 'allbank', 'uco', 'boi', 'mahb', 'syndicatebank',
  'saraswat', 'dbs', 'hsbc', 'scb', 'citibank', 'yesbankltd',
  // Neo-banks / fin-techs
  'jupiteraxis', 'sliceaxis', 'fiety', 'naviaxis', 'niyoicici',
  // NSDL / CAMS
  'nsdl', 'cams',
  // ibl (IDFC First legacy)
  'ibl',
]);

const VPA_REGEX = /^[a-zA-Z0-9._-]{2,50}@[a-zA-Z]{2,20}$/;

/**
 * Validates a UPI VPA.
 * Returns { valid: true } on OK.
 * Returns { valid: false, error: string } on hard failure (bad format).
 * Returns { valid: true, warning: string } when format is good but handle is unrecognised.
 */
export function validateVpa(vpa) {
  const trimmed = String(vpa || '').trim();
  if (!trimmed) {
    return { valid: false, error: 'VPA is required.' };
  }
  if (!VPA_REGEX.test(trimmed)) {
    return {
      valid: false,
      error: `"${trimmed}" is not a valid UPI VPA. Expected format: name@bankhandle`,
    };
  }
  const handle = trimmed.split('@')[1].toLowerCase();
  if (!KNOWN_UPI_HANDLES.has(handle)) {
    return {
      valid: true,
      warning: `Unknown bank handle "@${handle}". Check for typos before sending.`,
    };
  }
  return { valid: true };
}

const CREDENTIAL_ALIASES = {
  jwt: ['jwt', 'token', 'authToken', 'accessToken', 'authorization', 'stageToken'],
  vpa: ['vpa', 'upiVpa', 'handle'],
  userId: [
    'userId',
    'userid',
    'user_id',
    'mobileNumber',
    'mobile',
    'phoneNumber',
    'phone',
    'phoneNo',
    'number',
    'msisdn',
  ],
  walletId: ['walletId', 'walletid', 'wallet_id'],
  name: ['name', 'displayName', 'fullName', 'username'],
  avatar: ['avatar', 'avatarText', 'profileAvatar', 'profileInitials'],
};
const CANONICAL_CREDENTIAL_KEYS = new Set([
  'jwt',
  'vpa',
  'userid',
  'walletid',
  'name',
  'avatar',
  'extrafields',
]);

function tryParseJson(value) {
  const text = String(value || '').trim();
  if (!text || !['{', '['].includes(text[0])) {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function collectCredentialEntries(value, entries = new Map()) {
  if (Array.isArray(value)) {
    value.forEach((item) => collectCredentialEntries(item, entries));
    return entries;
  }

  if (!value || typeof value !== 'object') {
    const parsed = typeof value === 'string' ? tryParseJson(value) : null;
    if (parsed) {
      collectCredentialEntries(parsed, entries);
    }
    return entries;
  }

  Object.entries(value).forEach(([rawKey, rawValue]) => {
    const key = String(rawKey || '').trim();
    if (!key || rawValue === undefined || rawValue === null) {
      return;
    }

    if (typeof rawValue === 'string') {
      const trimmed = rawValue.trim();
      if (trimmed && !entries.has(key)) {
        entries.set(key, trimmed);
      }

      const parsed = tryParseJson(trimmed);
      if (parsed) {
        collectCredentialEntries(parsed, entries);
      }
      return;
    }

    if (typeof rawValue === 'object') {
      const serialized = JSON.stringify(rawValue);
      if (serialized && serialized !== '{}' && serialized !== '[]' && !entries.has(key)) {
        entries.set(key, serialized);
      }
      collectCredentialEntries(rawValue, entries);
      return;
    }

    if (!entries.has(key)) {
      entries.set(key, String(rawValue));
    }
  });

  return entries;
}

function findCredentialValue(entries, aliases) {
  const aliasSet = new Set(aliases.map((alias) => alias.toLowerCase()));
  for (const [key, value] of entries.entries()) {
    if (aliasSet.has(String(key).toLowerCase())) {
      return String(value || '').trim();
    }
  }
  return '';
}

function toExtraFieldRecord(entries, payload = {}) {
  const inputExtraFields =
    payload && typeof payload.extraFields === 'object' && !Array.isArray(payload.extraFields)
      ? payload.extraFields
      : {};
  const extraFields = {};

  Object.entries(inputExtraFields).forEach(([key, value]) => {
    const normalizedKey = String(key || '').trim();
    const normalizedValue = String(value ?? '').trim();
    if (normalizedKey && normalizedValue) {
      extraFields[normalizedKey] = normalizedValue;
    }
  });

  for (const [key, value] of entries.entries()) {
    if (CANONICAL_CREDENTIAL_KEYS.has(String(key).toLowerCase())) {
      continue;
    }

    const normalizedValue = String(value ?? '').trim();
    if (normalizedValue) {
      extraFields[key] = normalizedValue;
    }
  }

  return extraFields;
}

export function getInitials(value = '') {
  const seed = String(value).split('@')[0].replace(/[^a-z0-9]/gi, '').slice(0, 2);
  return seed ? seed.toUpperCase() : 'PP';
}

export function splitAmountParts(amount) {
  const numericAmount = Number(amount || 0);
  const absoluteAmount = Math.abs(numericAmount);
  const whole = Math.floor(absoluteAmount).toLocaleString('en-IN');
  const decimal = (absoluteAmount % 1).toFixed(2).slice(1);

  return {
    whole: numericAmount < 0 ? `-${whole}` : whole,
    decimal,
  };
}

export function formatAmount(amount, currency = 'INR') {
  const { whole, decimal } = splitAmountParts(amount);
  const prefix = currency === 'INR' ? '₹' : `${currency} `;
  return `${prefix}${whole}${decimal}`;
}

export function toPaise(amount) {
  return Math.round(Number(amount || 0) * 100);
}

export function isPinExpired(lastValidated, now = Date.now()) {
  if (!lastValidated) {
    return true;
  }

  return now - Number(lastValidated) > PIN_SESSION_MS;
}

export function getInitialPopupScreen({ onboarded, pin, pendingTx } = {}) {
  if (!onboarded) {
    return 'welcome';
  }

  if (pendingTx) {
    return 'confirm-tx';
  }

  if (isPinExpired(pin?.lastValidated)) {
    return 'pin-verify';
  }

  return 'dashboard';
}

export function createPendingTx(
  payload,
  { source = 'sdk', tabId = null, requestId = null, now = Date.now() } = {},
) {
  return {
    receiverVpa: String(payload.receiverVpa || '').trim(),
    amount: Number(payload.amount || 0),
    currency: String(payload.currency || 'INR').trim().toUpperCase() || 'INR',
    source,
    tabId,
    requestId,
    timestamp: now,
  };
}

export function normalizeLinkedCredentials(payload = {}, previous = {}) {
  const nextPayload =
    payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : {};
  const previousCredentials =
    previous && typeof previous === 'object' && !Array.isArray(previous) ? previous : {};
  const payloadEntries =
    nextPayload && typeof nextPayload === 'object' && !Array.isArray(nextPayload)
      ? (() => {
          const { extraFields, ...rest } = nextPayload;
          return rest;
        })()
      : nextPayload;
  const entries = collectCredentialEntries(payloadEntries);
  const nextExtraFields = toExtraFieldRecord(entries, nextPayload);
  const shouldReplaceExtraFields = Object.prototype.hasOwnProperty.call(
    nextPayload,
    'extraFields',
  );

  return {
    jwt:
      String(
        nextPayload.jwt ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.jwt) ||
          previousCredentials.jwt ||
          '',
      ).trim(),
    vpa:
      String(
        nextPayload.vpa ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.vpa) ||
          previousCredentials.vpa ||
          '',
      ).trim(),
    userId:
      String(
        nextPayload.userId ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.userId) ||
          previousCredentials.userId ||
          '',
      ).trim(),
    walletId:
      String(
        nextPayload.walletId ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.walletId) ||
          previousCredentials.walletId ||
          '',
      ).trim(),
    name:
      String(
        nextPayload.name ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.name) ||
          previousCredentials.name ||
          '',
      ).trim(),
    avatar:
      String(
        nextPayload.avatar ||
          findCredentialValue(entries, CREDENTIAL_ALIASES.avatar) ||
          previousCredentials.avatar ||
          '',
      ).trim(),
    extraFields: shouldReplaceExtraFields
      ? nextExtraFields
      : {
          ...(previousCredentials.extraFields || {}),
          ...nextExtraFields,
        },
  };
}
