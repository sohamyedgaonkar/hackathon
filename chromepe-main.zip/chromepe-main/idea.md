You are an expert Senior Full-Stack Engineer and Browser Extension Developer. I am building a Web3-style browser extension for a PhonePe Hackathon that mimics the behavior of MetaMask but operates on a simulated PhonePe Wallet ecosystem. Wallet repo is in same parent dir as current. This project name is ChromePe

I need you to generate a fully functional, end-to-end Proof of Concept (PoC) comprising three components:

A React SDK Button component.
A single-page Dummy Merchant Website that implements this SDK.
A Chrome Extension (Manifest V3) that handles onboarding, authentication, and payments via a mock/direct Wallet API.


ARCHITECTURE & COMMUNICATION PROTOCOL
Trigger Flow: The Merchant Website clicks the SDK Button -> SDK emits a CustomEvent or uses window.postMessage -> Extension Content Script intercepts it -> Relays message to Background Script (service_worker) -> Background Script launches the extension Popup or updates its state.
Payload Structure from SDK: { receiverVpa: string, amount: number, currency: string }


COMPONENT SPECIFICATIONS
1. React SDK Button
Create a lightweight, reusable React component (PhonePePayButton.jsx).

Props accepted: receiverVpa, amount, currency, onSuccess, onFailure.
Behavior: When clicked, it checks if the extension is installed (via a global object like window.phonepe). If installed, it triggers the payment request payload to the extension. If not, it alerts the user to install the extension.
2. Dummy Merchant Website
A clean, single-page React application (App.jsx) representing an e-commerce checkout page.

It must import and render the PhonePePayButton with hardcoded dummy checkout values (e.g., receiverVpa: "merchant@phonepe", amount: 500, currency: "INR").
Include a visual status log on the page to display success/failure callbacks received from the SDK button.
3. Chrome Extension (Manifest V3)
Provide the full codebase for the extension structure:

manifest.json: Configure Manifest V3 with appropriate permissions (storage, scripting, activeTab).

Content/Background Scripts: Handle the communication bridge between the merchant tab and the extension popup.

Extension UI (React or Vanilla JS/HTML - choose the cleanest for a single response):

A. Onboarding/Wallet Lifecycle Flow (First-time user):

Welcome Screen: Displays a dummy sign-in QR Code (placeholder image/UI component).
PoC Credential Inputs: Text fields for JWT Token, VPA, and UserId. These will be saved to chrome.storage.local to bypass regular OAuth/payment routing for stage testing.
PIN Setup: Prompt user to set a 4-digit security PIN.
PIN Expiry Logic: Store a timestamp. The extension must re-prompt for this PIN if 1 hour has elapsed since the last validation OR whenever a payment transaction is initiated.

B. Main Dashboard UI (Post-Onboarding):

Profile Header: Clean header showing user's VPA and a MetaMask-style identicon/profile avatar.
Balances Grid: Display balances for three tabs: Wallet, UPI Lite, and Send to Mobile. (Only the "Wallet" balance needs to pull actual data; others can be mock values).
Direct Send Feature: A "Send" button that opens an in-extension form where the user can manually type a destination VPA, Amount, and Currency, then hit "Pay".

C. Transaction Interception UI:

When triggered by the SDK merchant button, open the extension view showing a confirmation screen: Merchant VPA, Amount, and Currency.
Dropdown selector for payment source (Wallet, UPI Lite, Send to Mobile) — Force "Wallet" as the only functional option for this demo.
Prompt for the 4-digit PIN before executing the payment.


BACKEND API INTEGRATION PLACEHOLDERS
Provide clean Axios/Fetch helper functions inside the extension where the actual PhonePe Stage/Sandbox Wallet API endpoints will be hit for debiting/crediting. Use the JWT Token, VPA, and UserId stored in chrome.storage for authorization headers.
Comment clearly where these endpoints should be plugged in.
DELIVERABLES EXPECTED
Please output the code blocks categorized clearly by file path:

sdk/PhonePePayButton.jsx
merchant-demo/App.jsx
extension/manifest.json
extension/background.js / content.js
extension/popup.html & popup.js (including UI states for Onboarding, Dashboard, and PIN entry)
