import React, { useEffect, useMemo, useState } from 'react';

import PhonePePayButton from '@sdk/PhonePePayButton.jsx';
import PhonePeRedirectStatusPage from '@sdk/PhonePeRedirectStatusPage.jsx';
import { hasRedirectPayload } from '@sdk/bridge.js';
import {
  calculateSubtotal,
  DEFAULT_RETAILER_ID,
  getInitialItems,
  getRetailerById,
  RETAILERS,
} from './checkout-config.js';

const STAGE_REFERENCES = {
  merchantId: 'FXM',
  balanceUserId: 'U2605201223014578543009',
  p2pSenderWalletId: 'W2404031647228269257058',
  p2pReceiverWalletId: 'W2401051240402297012173',
};

const statusToneStyles = {
  info: { color: '#2563eb' },
  success: { color: '#15803d' },
  error: { color: '#b91c1c' },
  warning: { color: '#b45309' },
};

function createLog(message, tone = 'info') {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    message,
    tone,
    timestamp: new Date().toLocaleTimeString('en-IN', { hour12: false }),
  };
}

function formatCurrency(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(value);
}

function buildQtyButton(primary = false) {
  return {
    width: 32,
    height: 32,
    borderRadius: 8,
    border: `1px solid ${primary ? '#ffd814' : '#d5d9d9'}`,
    background: primary ? '#ffd814' : '#ffffff',
    color: '#111827',
    fontSize: 18,
    fontWeight: 700,
    cursor: 'pointer',
  };
}

export default function App() {
  const [logs, setLogs] = useState([
    createLog('Amazon-style checkout is ready. Waiting for ChromePe extension…', 'info'),
  ]);
  const [extensionDetected, setExtensionDetected] = useState(false);
  const [items, setItems] = useState(() => getInitialItems());
  const [selectedRetailerId, setSelectedRetailerId] = useState(() => {
    if (typeof window === 'undefined') {
      return DEFAULT_RETAILER_ID;
    }

    return getRetailerById(
      new URLSearchParams(window.location.search).get('retailer') || DEFAULT_RETAILER_ID,
    ).id;
  });
  const [showRedirectPage, setShowRedirectPage] = useState(() =>
    typeof window !== 'undefined' && hasRedirectPayload(window.location.search),
  );

  const log = (message, tone) => {
    setLogs((current) => [createLog(message, tone), ...current].slice(0, 4));
  };

  const selectedRetailer = useMemo(
    () => getRetailerById(selectedRetailerId),
    [selectedRetailerId],
  );

  const redirectUrl = useMemo(() => {
    if (typeof window === 'undefined') {
      return '';
    }

    const url = new URL(window.location.pathname, window.location.origin);
    url.searchParams.set('retailer', selectedRetailer.id);
    return url.toString();
  }, [selectedRetailer.id]);

  useEffect(() => {
    const updateDetection = () => {
      const available = Boolean(
        window.phonepe &&
          window.phonepe.isChromePe &&
          typeof window.phonepe.request === 'function',
      );

      setExtensionDetected(available);
      log(
        available ? 'ChromePe extension detected ✓' : 'ChromePe extension not found ✗',
        available ? 'success' : 'warning',
      );
    };

    const handleStarted = (event) => {
      log(
        `Payment initiated for ${formatCurrency(event.detail.amount)} → ${event.detail.receiverVpa}`,
        'warning',
      );
    };

    const handleSuccess = (event) => {
      log(`Payment success — ${event.detail.txnId}`, 'success');
    };

    const handleError = (event) => {
      log(
        `Payment failed — ${event.detail.error || event.detail.code || 'Unknown error'}`,
        'error',
      );
    };

    const handleRedirect = (event) => {
      log(`Redirecting to Amazon order confirmation for ${event.detail.txnId}`, 'info');
    };

    updateDetection();
    window.addEventListener('phonepe#initialized', updateDetection);
    window.addEventListener('chromepe:payment-start', handleStarted);
    window.addEventListener('chromepe:payment-success', handleSuccess);
    window.addEventListener('chromepe:payment-error', handleError);
    window.addEventListener('chromepe:payment-redirect', handleRedirect);

    const timers = [500, 1500, 3000].map((delay) =>
      window.setTimeout(updateDetection, delay),
    );

    return () => {
      window.removeEventListener('phonepe#initialized', updateDetection);
      window.removeEventListener('chromepe:payment-start', handleStarted);
      window.removeEventListener('chromepe:payment-success', handleSuccess);
      window.removeEventListener('chromepe:payment-error', handleError);
      window.removeEventListener('chromepe:payment-redirect', handleRedirect);
      timers.forEach((timer) => window.clearTimeout(timer));
    };
  }, []);

  const filteredItems = useMemo(() => items.filter((item) => item.quantity > 0), [items]);
  const subtotal = useMemo(() => calculateSubtotal(filteredItems), [filteredItems]);
  const totalItems = useMemo(
    () => filteredItems.reduce((total, item) => total + item.quantity, 0),
    [filteredItems],
  );

  const updateQuantity = (itemId, delta) => {
    setItems((current) =>
      current.map((item) =>
        item.id === itemId
          ? { ...item, quantity: Math.max(0, item.quantity + delta) }
          : item,
      ),
    );
  };

  if (showRedirectPage) {
    return (
      <PhonePeRedirectStatusPage
        merchantName={`Amazon.in • ${selectedRetailer.name}`}
        onVerified={(verification) => {
          log(
            `Wallet API verified ${verification.txnId} with ${verification.responseCode}`,
            'success',
          );
        }}
        onError={(error) => {
          log(
            `Wallet verification failed — ${error.message || error.responseCode || error.code}`,
            'error',
          );
        }}
        onContinue={() => {
          setShowRedirectPage(false);
          log('Returned to Amazon checkout from success page.', 'info');
        }}
      />
    );
  }

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#eaeded',
        fontFamily:
          'Amazon Ember, Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
        color: '#111827',
      }}
    >
      <div
        style={{
          background: '#131921',
          color: '#ffffff',
          padding: '12px 24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 16,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ fontSize: 28, fontWeight: 800 }}>
            amazon<span style={{ color: '#f3a847' }}>.in</span>
          </div>
          <div style={{ fontSize: 18, fontWeight: 700 }}>Checkout</div>
        </div>
        <div
          style={{
            padding: '8px 14px',
            borderRadius: 999,
            background: extensionDetected ? '#1f5131' : '#5f3b00',
            fontSize: 13,
            fontWeight: 700,
          }}
        >
          {extensionDetected ? 'ChromePe Ready' : 'ChromePe Missing'}
        </div>
      </div>

      <div style={{ padding: '16px 24px 28px' }}>
        <div style={{ fontSize: 30, fontWeight: 400, marginBottom: 18 }}>Review your order</div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'minmax(0, 1fr) 420px',
            gap: 20,
            alignItems: 'start',
          }}
        >
          <div style={{ display: 'grid', gap: 16 }}>
            <section
              style={{
                background: '#ffffff',
                borderRadius: 12,
                border: '1px solid #d5d9d9',
                padding: 20,
                display: 'grid',
                gap: 18,
              }}
            >
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                  gap: 16,
                }}
              >
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: '#0f1111' }}>
                    Delivery address
                  </div>
                  <div style={{ fontSize: 14, color: '#565959', marginTop: 8, lineHeight: 1.6 }}>
                    Arya Intern
                    <br />
                    ChromePe Hackathon Desk
                    <br />
                    Bengaluru, Karnataka
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: '#0f1111' }}>
                    Payment method
                  </div>
                  <div style={{ fontSize: 14, color: '#565959', marginTop: 8, lineHeight: 1.6 }}>
                    ChromePe Wallet via SDK
                    <br />
                    Retailer: {selectedRetailer.name}
                    <br />
                    Receiver VPA: {selectedRetailer.receiverVpa}
                    <br />
                    Redirect: {redirectUrl}
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  flexWrap: 'wrap',
                  gap: 10,
                  paddingTop: 12,
                  borderTop: '1px solid #eaeded',
                }}
              >
                {RETAILERS.map((retailer) => {
                  const active = retailer.id === selectedRetailer.id;
                  return (
                    <button
                      key={retailer.id}
                      type="button"
                      onClick={() => setSelectedRetailerId(retailer.id)}
                      style={{
                        borderRadius: 999,
                        border: `1px solid ${active ? '#f3a847' : '#d5d9d9'}`,
                        background: active ? '#fff7e6' : '#ffffff',
                        padding: '10px 14px',
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      <div style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>
                        {retailer.name}
                      </div>
                      <div style={{ fontSize: 12, color: '#565959', marginTop: 2 }}>
                        {retailer.badge} • {retailer.receiverVpa}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div
                style={{
                  borderTop: '1px solid #eaeded',
                  paddingTop: 18,
                  display: 'grid',
                  gap: 18,
                }}
              >
                {filteredItems.map((item) => (
                  <div
                    key={item.id}
                    style={{
                      display: 'grid',
                      gridTemplateColumns: '120px minmax(0, 1fr) auto',
                      gap: 16,
                      alignItems: 'center',
                    }}
                  >
                    <div
                      style={{
                        height: 120,
                        borderRadius: 12,
                        background: '#f7f8f8',
                        border: '1px solid #eaeded',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 42,
                      }}
                    >
                      {item.id === 'desk-mat' ? '🧩' : item.id === 'fire-stick' ? '📺' : '⚡'}
                    </div>
                    <div>
                      <div style={{ fontSize: 18, fontWeight: 700, color: '#0f1111' }}>
                        {item.name}
                      </div>
                      <div style={{ fontSize: 14, color: '#565959', marginTop: 6 }}>
                        {item.description}
                      </div>
                      <div style={{ fontSize: 18, color: '#b12704', fontWeight: 700, marginTop: 10 }}>
                        {formatCurrency(item.price)}
                      </div>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 10,
                          marginTop: 12,
                        }}
                      >
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, -1)}
                          style={buildQtyButton(false)}
                        >
                          −
                        </button>
                        <div style={{ minWidth: 24, textAlign: 'center', fontWeight: 700 }}>
                          {item.quantity}
                        </div>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.id, 1)}
                          style={buildQtyButton(true)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div style={{ fontSize: 18, fontWeight: 700 }}>{formatCurrency(item.price * item.quantity)}</div>
                  </div>
                ))}
              </div>
            </section>

          </div>

          <aside
            style={{
              background: '#ffffff',
              borderRadius: 12,
              border: '1px solid #d5d9d9',
              padding: 20,
              display: 'grid',
              gap: 16,
              position: 'sticky',
              top: 16,
            }}
          >
            <div style={{ fontSize: 28, fontWeight: 700, color: '#b12704' }}>
              {formatCurrency(subtotal)}
            </div>
            <div style={{ fontSize: 14, color: '#565959', lineHeight: 1.6 }}>
              Order contains {totalItems} item{totalItems === 1 ? '' : 's'}.
              <br />
              Paying {selectedRetailer.name} via {selectedRetailer.receiverVpa}.
            </div>

            <PhonePePayButton
              receiverVpa={selectedRetailer.receiverVpa}
              amount={subtotal}
              currency="INR"
              redirectUrl={redirectUrl}
              onSuccess={(result) => {
                log(`Merchant callback received success for ${result.txnId}`, 'success');
              }}
              onFailure={(error) => {
                log(`Merchant callback received failure: ${error.error}`, 'error');
              }}
            />

            <div
              style={{
                borderTop: '1px solid #eaeded',
                paddingTop: 16,
                display: 'grid',
                gap: 10,
                fontSize: 14,
                color: '#565959',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Items</span>
                <span>
                  {formatCurrency(
                    filteredItems
                      .filter((item) => item.id !== 'express-delivery')
                      .reduce((total, item) => total + item.price * item.quantity, 0),
                  )}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Express delivery</span>
                <span>
                  {formatCurrency(
                    filteredItems
                      .filter((item) => item.id === 'express-delivery')
                      .reduce((total, item) => total + item.price * item.quantity, 0),
                  )}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>Taxes</span>
                <span>{formatCurrency(0)}</span>
              </div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  fontSize: 18,
                  fontWeight: 700,
                  color: '#111827',
                  paddingTop: 8,
                  borderTop: '1px solid #eaeded',
                }}
              >
                <span>Order total</span>
                <span>{formatCurrency(subtotal)}</span>
              </div>
            </div>

            <div
              style={{
                fontSize: 11,
                color: '#565959',
                lineHeight: 1.5,
                background: '#fcfcfc',
                borderRadius: 10,
                border: '1px solid #eaeded',
                padding: 12,
                display: 'grid',
                gap: 8,
              }}
            >
              <strong style={{ fontSize: 12, color: '#111827' }}>SDK activity</strong>
              {logs.map((entry) => (
                <div key={entry.id}>
                  <div style={{ fontSize: 10, color: '#6b7280' }}>{entry.timestamp}</div>
                  <div style={{ marginTop: 2, ...statusToneStyles[entry.tone] }}>{entry.message}</div>
                </div>
              ))}
            </div>

            <div
              style={{
                fontSize: 12,
                color: '#565959',
                lineHeight: 1.6,
                background: '#f7fafa',
                borderRadius: 10,
                border: '1px solid #d5d9d9',
                padding: 14,
              }}
            >
              <strong>Stage references</strong>
              <br />
              Balance User: {STAGE_REFERENCES.balanceUserId}
              <br />
              P2P Sender Wallet: {STAGE_REFERENCES.p2pSenderWalletId}
              <br />
              P2P Receiver Wallet: {STAGE_REFERENCES.p2pReceiverWalletId}
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
