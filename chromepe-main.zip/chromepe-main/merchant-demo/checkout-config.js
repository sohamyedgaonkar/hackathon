export const RETAILERS = [
  {
    id: 'amazon-fresh',
    name: 'Amazon Fresh',
    receiverVpa: 'fresh.collect@ibl',
    badge: 'Groceries',
  },
  {
    id: 'amazon-bazaar',
    name: 'Amazon Bazaar',
    receiverVpa: 'bazaar.collect@ybl',
    badge: 'Daily finds',
  },
  {
    id: 'amazon-electronics',
    name: 'Amazon Electronics',
    receiverVpa: 'electronics.collect@axl',
    badge: 'Gadgets',
  },
];

export const DEFAULT_RETAILER_ID = RETAILERS[0].id;

const INITIAL_ITEMS = [
  {
    id: 'desk-mat',
    name: 'Desk Cable Organiser',
    description: 'A neat little add-on under Rs.100',
    price: 79,
    quantity: 1,
  },
  {
    id: 'express-delivery',
    name: 'Express delivery',
    description: 'Get it today by 9 PM',
    price: 9,
    quantity: 1,
  },
  {
    id: 'fire-stick',
    name: 'Fire TV Stick Lite',
    description: 'Streaming made easy',
    price: 349,
    quantity: 1,
  },
];

export function getRetailerById(retailerId) {
  return RETAILERS.find((retailer) => retailer.id === retailerId) || RETAILERS[0];
}

export function getInitialItems() {
  return INITIAL_ITEMS.map((item) => ({ ...item }));
}

export function calculateSubtotal(items) {
  return items.reduce(
    (total, item) => total + Number(item.price || 0) * Number(item.quantity || 0),
    0,
  );
}
