import test from 'node:test';
import assert from 'node:assert/strict';

import {
  RETAILERS,
  DEFAULT_RETAILER_ID,
  getRetailerById,
  getInitialItems,
  calculateSubtotal,
} from './checkout-config.js';

test('default retailer maps to a real receiver VPA', () => {
  const retailer = getRetailerById(DEFAULT_RETAILER_ID);

  assert.equal(retailer.id, DEFAULT_RETAILER_ID);
  assert.match(retailer.receiverVpa, /@/);
});

test('starter checkout items stay in the requested price bands', () => {
  const items = getInitialItems();
  const prices = items.map((item) => item.price);

  assert.equal(items.length, 3);
  assert.ok(prices.some((price) => price < 100), 'expected one item under 100');
  assert.ok(prices.includes(9), 'expected express delivery at 9');
  assert.ok(
    prices.some((price) => price >= 300 && price <= 400),
    'expected one item between 300 and 400',
  );
});

test('subtotal uses the selected quantities', () => {
  const subtotal = calculateSubtotal([
    { price: 79, quantity: 1 },
    { price: 9, quantity: 1 },
    { price: 349, quantity: 2 },
  ]);

  assert.equal(subtotal, 786);
});

test('retailer list offers multiple choices for switching receiver vpas', () => {
  const vpas = new Set(RETAILERS.map((retailer) => retailer.receiverVpa));

  assert.ok(RETAILERS.length >= 3);
  assert.equal(vpas.size, RETAILERS.length);
});
