 TOKEN='O-Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJpZGVudGl0eU1hbmFnZXIiLCJ2ZXJzaW9uIjoiNC4wIiwidGlkIjoiZDU2YzkxMTAtZjY3MC00YmM3LThkYmUtNmE5MjVjNThmOGJhIiwic2lkIjoiNDljZjhhMDEtNGI3OS00M2JjLThkYWMtYWM5MTQ0YjU4MWY4IiwiaWF0IjoxNzc5OTY0NzExLCJleHAiOjE3Nzk5NzU1MTF9.PPBkrcb2M-b1xnPB2WtQ0wpcDcycwCsp-EXZvlRzFTQtln7kqPe-AHHfo9w8cPdkPdywt7k34BeY5vFi9mBbjg'
 TXN_ID="HACK39485uehudfffdeh"
 NOW="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

 curl -X POST \
   'http://walletservice.nixy.stg-drove.phonepe.nb6/credit/v1/topup?understandsMinKycV2=false' \
   -H "Authorization: $TOKEN" \
   -H 'Content-Type: application/json' \
   --data-raw "{
     \"merchantInformation\": {
       \"merchantId\": \"PHONEPEWALLETTOPUP\"
     },
     \"walletInformation\": {
       \"walletId\": \"W2602031505158102534238\",
       \"userId\": \"U2602031504530168449331\",
       \"kycType\": \"FULL_KYC_V2\"
     },
     \"amount\": 80000,
     \"currencyCode\": \"INR\",
     \"transactionId\": \"$TXN_ID\",
     \"context\": {
       \"merchantTransactionId\": \"$TXN_ID\",
       \"topupPaymentInstrument\": \"CREDIT_CARD\",
       \"topupAccountType\": \"CREDIT\",
       \"topupProcessingRail\": \"PG\",
       \"paymentReference\": \"$TXN_ID\",
       \"source\": \"NEXUS\",
       \"autoTopup\": false
     },
     \"transactionTime\": \"$NOW\"
   }"