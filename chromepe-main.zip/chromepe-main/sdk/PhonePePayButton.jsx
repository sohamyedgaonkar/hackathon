import React, { useEffect, useMemo, useState } from 'react';

import {
  buildPaymentPayload,
  isChromePeAvailable,
  requestPayment,
} from './bridge.js';

const baseButtonStyle = {
  width: '100%',
  padding: '16px 24px',
  border: 'none',
  borderRadius: '14px',
  background: 'linear-gradient(135deg, #5f259f 0%, #8e44ad 100%)',
  color: '#ffffff',
  fontSize: '15px',
  fontWeight: 700,
  letterSpacing: '0.01em',
  boxShadow: '0 14px 30px rgba(95, 37, 159, 0.24)',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: '10px',
  cursor: 'pointer',
  transition: 'transform 0.15s ease, box-shadow 0.15s ease, opacity 0.15s ease',
  fontFamily:
    'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
};

const symbolStyle = {
  width: 24,
  height: 24,
  borderRadius: '999px',
  background: '#ffffff',
  color: '#5f259f',
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  fontWeight: 800,
  fontSize: 12,
  boxShadow: '0 2px 8px rgba(17, 24, 39, 0.16)',
};

const spinnerStyle = {
  width: 16,
  height: 16,
  borderRadius: '50%',
  border: '2px solid rgba(255,255,255,0.35)',
  borderTopColor: '#ffffff',
  animation: 'chromepe-spin 0.8s linear infinite',
};

function emitLifecycleEvent(name, detail) {
  if (typeof window === 'undefined') {
    return;
  }

  window.dispatchEvent(new CustomEvent(name, { detail }));
}

function buildRedirectTarget(redirectUrl, result) {
  if (typeof window === 'undefined') {
    return '';
  }

  const rawTarget = String(result?.redirectUrl || redirectUrl || '').trim();
  if (!rawTarget) {
    return '';
  }

  try {
    const url = new URL(rawTarget, window.location.href);
    url.searchParams.set('chromepe_status', String(result?.status || 'SUCCESS').toLowerCase());

    if (result?.txnId) {
      url.searchParams.set('chromepe_txn_id', result.txnId);
    }

    if (Number.isFinite(Number(result?.amount))) {
      url.searchParams.set('chromepe_amount', String(Number(result.amount)));
    }

    if (result?.currency) {
      url.searchParams.set('chromepe_currency', result.currency);
    }

    if (result?.receiverVpa) {
      url.searchParams.set('chromepe_receiver', result.receiverVpa);
    }

    if (result?.paymentToken) {
      url.searchParams.set('chromepe_token', result.paymentToken);
    }

    return url.toString();
  } catch {
    return '';
  }
}

export default function PhonePePayButton({
  receiverVpa,
  amount,
  currency = 'INR',
  redirectUrl = '',
  onSuccess,
  onFailure,
}) {
  const [loading, setLoading] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return undefined;
    }

    const refreshProviderState = () => {
      setInstalled(isChromePeAvailable(window));
    };

    refreshProviderState();
    window.addEventListener('phonepe#initialized', refreshProviderState);

    const timers = [300, 900, 1800].map((delay) =>
      window.setTimeout(refreshProviderState, delay),
    );

    return () => {
      window.removeEventListener('phonepe#initialized', refreshProviderState);
      timers.forEach((timer) => window.clearTimeout(timer));
    };
  }, []);

  const payload = useMemo(
    () => ({
      receiverVpa,
      amount,
      currency,
      redirectUrl,
    }),
    [amount, currency, receiverVpa, redirectUrl],
  );

  const buttonStyle = useMemo(
    () => ({
      ...baseButtonStyle,
      transform: hovered && !loading ? 'translateY(-1px)' : 'translateY(0)',
      boxShadow:
        hovered && !loading
          ? '0 18px 34px rgba(95, 37, 159, 0.3)'
          : baseButtonStyle.boxShadow,
      opacity: loading ? 0.8 : installed ? 1 : 0.95,
      cursor: loading ? 'wait' : 'pointer',
    }),
    [hovered, installed, loading],
  );

  async function handleClick() {
    if (loading) {
      return;
    }

    let normalizedPayload;
    try {
      normalizedPayload = buildPaymentPayload(payload);
    } catch (error) {
      const failure = {
        error: error.message || 'Invalid payment request.',
        code: 'INVALID_REQUEST',
      };
      onFailure?.(failure);
      emitLifecycleEvent('chromepe:payment-error', failure);
      return;
    }

    if (!isChromePeAvailable(window)) {
      const failure = {
        error: 'ChromePe extension is not installed. Please install it first.',
        code: 'NOT_INSTALLED',
      };
      alert(failure.error);
      onFailure?.(failure);
      emitLifecycleEvent('chromepe:payment-error', failure);
      return;
    }

    setLoading(true);
    emitLifecycleEvent('chromepe:payment-start', normalizedPayload);

    try {
      const result = await requestPayment(window, normalizedPayload);
      onSuccess?.(result);
      emitLifecycleEvent('chromepe:payment-success', result);

      const redirectTarget = buildRedirectTarget(redirectUrl, result);
      if (redirectTarget) {
        emitLifecycleEvent('chromepe:payment-redirect', {
          ...result,
          redirectUrl: redirectTarget,
        });
        window.location.assign(redirectTarget);
      }
    } catch (error) {
      const failure = {
        error: error?.error || error?.message || 'Payment failed.',
        code: error?.code || 'FAILED',
      };
      onFailure?.(failure);
      emitLifecycleEvent('chromepe:payment-error', failure);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <style>{`
        @keyframes chromepe-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
      <button
        type="button"
        style={buttonStyle}
        onClick={handleClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        aria-label={`Pay ${amount} ${currency} with ChromePe`}
      >
        {loading ? (
          <>
            <span style={spinnerStyle} aria-hidden="true" />
            Processing payment...
          </>
        ) : (
          <>
            <span style={symbolStyle} aria-hidden="true">
              पे
            </span>
            Pay with ChromePe
          </>
        )}
      </button>
    </>
  );
}
