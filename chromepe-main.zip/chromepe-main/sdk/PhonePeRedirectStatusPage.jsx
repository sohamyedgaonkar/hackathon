import React, { useEffect, useMemo, useRef, useState } from 'react';

import {
  clearRedirectPayloadFromUrl,
  readRedirectPayload,
  verifyRedirectPayment,
} from './bridge.js';
import { getRedirectStatusModel } from './redirect-status-model.js';
import { createVerificationRunner } from './verification-runner.js';

const pageStyle = {
  minHeight: '100vh',
  background: '#eaeded',
  fontFamily:
    'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  color: '#1f2937',
};

const buttonStyle = {
  border: 'none',
  borderRadius: 999,
  padding: '14px 18px',
  fontWeight: 700,
  fontSize: 14,
  cursor: 'pointer',
};

function formatCurrency(amount, currency = 'INR') {
  const numericAmount = Number(amount || 0);
  return currency === 'INR'
    ? `₹${numericAmount.toFixed(2)}`
    : `${currency} ${numericAmount.toFixed(2)}`;
}

function formatVerifiedAmount(result) {
  const verifiedAmount = Number(result?.verifiedTransaction?.amount || 0);
  if (verifiedAmount > 0) {
    return formatCurrency(verifiedAmount / 100, result?.verifiedTransaction?.currencyCode || 'INR');
  }

  return formatCurrency(result?.amount || 0, result?.currency || 'INR');
}

function getDisplayReceiver(result) {
  return (
    result?.verifiedTransaction?.externalVpa ||
    result?.verifiedTransaction?.merchantId ||
    result?.receiverVpa ||
    'Missing'
  );
}

function formatTransactionTime(result) {
  const value = Number(result?.verifiedTransaction?.transactionTime || 0);
  if (!value) {
    return 'Pending';
  }

  return new Date(value).toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function getPaymentTone(paymentState) {
  if (paymentState === 'success') {
    return {
      background: '#ecfdf5',
      border: '1px solid #bbf7d0',
      iconBackground: '#16a34a',
      iconText: '#ffffff',
      text: '#166534',
    };
  }

  if (paymentState === 'error') {
    return {
      background: '#fef2f2',
      border: '1px solid #fecaca',
      iconBackground: '#dc2626',
      iconText: '#ffffff',
      text: '#991b1b',
    };
  }

  return {
    background: '#f6f3ff',
    border: '1px solid #e9d5ff',
    iconBackground: '#5f259f',
    iconText: '#ffffff',
    text: '#5b21b6',
  };
}

function getVerificationTone(verificationState) {
  if (verificationState === 'verified') {
    return { color: '#166534', background: '#ecfdf5', border: '#bbf7d0' };
  }

  if (verificationState === 'warning') {
    return { color: '#92400e', background: '#fffbeb', border: '#fde68a' };
  }

  if (verificationState === 'failed') {
    return { color: '#991b1b', background: '#fef2f2', border: '#fecaca' };
  }

  return { color: '#5b21b6', background: '#f6f3ff', border: '#e9d5ff' };
}

function buildFailureResult(payload, error) {
  return {
    ...payload,
    verified: false,
    status: String(error?.status || payload.status || 'FAILED').toUpperCase(),
    redirectStatus: String(payload.status || '').toUpperCase(),
    responseCode: String(error?.responseCode || error?.code || '').toUpperCase(),
    transactionState: String(error?.transactionState || '').toUpperCase(),
    walletId: String(error?.walletId || ''),
    message:
      error?.error ||
      error?.message ||
      'ChromePe could not verify the payment with the wallet API.',
    verifiedAt: String(error?.verifiedAt || ''),
    paymentToken: String(error?.paymentToken || payload.paymentToken || ''),
    txnId: String(error?.txnId || payload.txnId || ''),
    amount:
      error?.amount !== undefined && error?.amount !== null
        ? Number(error.amount)
        : Number(payload.amount || 0),
    currency: String(error?.currency || payload.currency || 'INR').toUpperCase(),
    receiverVpa: String(error?.receiverVpa || payload.receiverVpa || '').trim(),
    verifiedTransaction: null,
  };
}

export default function PhonePeRedirectStatusPage({
  merchantName = 'Merchant',
  targetWindow = typeof window !== 'undefined' ? window : null,
  search,
  onVerified,
  onError,
  onContinue,
}) {
  const searchValue = search ?? targetWindow?.location?.search ?? '';
  const redirectPayload = useMemo(() => readRedirectPayload(searchValue), [searchValue]);
  const verificationKey = useMemo(
    () =>
      [
        redirectPayload.txnId,
        redirectPayload.paymentToken,
        redirectPayload.amount,
        redirectPayload.currency,
        redirectPayload.receiverVpa,
        redirectPayload.status,
      ].join('|'),
    [redirectPayload],
  );
  const [phase, setPhase] = useState(redirectPayload.hasPayload ? 'verifying' : 'error');
  const [result, setResult] = useState(
    redirectPayload.hasPayload
      ? null
      : buildFailureResult(redirectPayload, {
          error: 'No ChromePe redirect payload was found on this page.',
          code: 'MISSING_REDIRECT_PAYLOAD',
        }),
  );
  // True when payment was made via UPI delegate (no wallet token — confirmed on phone)
  const isUpiPayment = redirectPayload.hasPayload && !redirectPayload.paymentToken;
  const onVerifiedRef = useRef(onVerified);
  const onErrorRef = useRef(onError);
  const verificationRunnerRef = useRef(null);

  if (!verificationRunnerRef.current) {
    verificationRunnerRef.current = createVerificationRunner();
  }

  useEffect(() => {
    onVerifiedRef.current = onVerified;
  }, [onVerified]);

  useEffect(() => {
    onErrorRef.current = onError;
  }, [onError]);

  useEffect(() => {
    let cancelled = false;

    if (!redirectPayload.hasPayload) {
      const failure = buildFailureResult(redirectPayload, {
        error: 'No ChromePe redirect payload was found on this page.',
        code: 'MISSING_REDIRECT_PAYLOAD',
      });
      setPhase('error');
      setResult(failure);
      onErrorRef.current?.(failure);
      return () => {
        cancelled = true;
      };
    }

    // UPI delegate payment — no wallet token, confirmed on phone. Skip wallet verification.
    if (isUpiPayment) {
      const upiResult = {
        verified: true,
        txnId: redirectPayload.txnId,
        amount: redirectPayload.amount,
        currency: redirectPayload.currency || 'INR',
        receiverVpa: redirectPayload.receiverVpa,
        paymentToken: '',
        status: 'SUCCESS',
        redirectStatus: redirectPayload.status,
        responseCode: 'SUCCESS',
        transactionState: 'SUCCESS',
        walletId: '',
        message: 'Payment approved via ChromePe UPI on mobile.',
        verifiedAt: new Date().toISOString(),
        verifiedTransaction: {
          transactionId: redirectPayload.txnId,
          merchantId: '',
          externalVpa: redirectPayload.receiverVpa,
          amount: Math.round((redirectPayload.amount || 0) * 100),
          currencyCode: redirectPayload.currency || 'INR',
          transactionState: 'SUCCESS',
          transactionType: 'UPI_COLLECT',
          category: 'P2P',
          responseCode: 'SUCCESS',
          message: 'Payment approved via ChromePe UPI on mobile.',
          transactionTime: Date.now(),
        },
      };
      setPhase('success');
      setResult(upiResult);
      onVerifiedRef.current?.(upiResult);
      return () => {
        cancelled = true;
      };
    }

    setPhase('verifying');
    setResult(null);

    verificationRunnerRef.current
      .run(verificationKey, () => verifyRedirectPayment(targetWindow, redirectPayload))
      .then((verification) => {
        if (cancelled) {
          return;
        }

        setPhase('success');
        setResult(verification);
        onVerifiedRef.current?.(verification);
      })
      .catch((error) => {
        if (cancelled) {
          return;
        }

        const failure = buildFailureResult(redirectPayload, error);
        setPhase('error');
        setResult(failure);
        onErrorRef.current?.(failure);
      });

    return () => {
      cancelled = true;
    };
  }, [redirectPayload, targetWindow, verificationKey]);

  const statusResult = result || redirectPayload;
  const statusModel = getRedirectStatusModel({
    redirectStatus: redirectPayload.status,
    phase,
    result: statusResult,
  });
  const paymentTone = getPaymentTone(statusModel.paymentState);
  const verificationTone = getVerificationTone(statusModel.verificationState);
  const statusIcon =
    statusModel.paymentState === 'success'
      ? '✓'
      : statusModel.paymentState === 'error'
        ? '!'
        : '…';
  const displayTxnId = statusResult?.verifiedTransaction?.transactionId || statusResult.txnId || 'Missing';
  const displayReceiver = getDisplayReceiver(statusResult);
  const displayAmount = formatVerifiedAmount(statusResult);
  const verifiedTransaction = statusResult?.verifiedTransaction;

  function handleContinue() {
    clearRedirectPayloadFromUrl(targetWindow);
    onContinue?.(statusResult);
  }

  return (
    <div style={pageStyle}>
      <div
        style={{
          background: '#131921',
          color: '#ffffff',
          padding: '14px 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: 16,
          flexWrap: 'wrap',
        }}
      >
        <div style={{ fontSize: 24, fontWeight: 800 }}>
          amazon<span style={{ color: '#f3a847' }}>.in</span>
        </div>
        <div style={{ fontSize: 14, opacity: 0.92 }}>
          {merchantName} order confirmation via ChromePe
        </div>
      </div>

      <div style={{ padding: 24 }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'minmax(0, 1.45fr) minmax(320px, 420px)',
            gap: 24,
            alignItems: 'start',
          }}
        >
          <div style={{ display: 'grid', gap: 20 }}>
            <div
              style={{
                ...paymentTone,
                border: paymentTone.border,
                borderRadius: 18,
                padding: 24,
                display: 'flex',
                gap: 18,
                alignItems: 'flex-start',
                background: '#ffffff',
              }}
            >
              <div
                style={{
                  width: 56,
                  height: 56,
                  borderRadius: '50%',
                  background: paymentTone.iconBackground,
                  color: paymentTone.iconText,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 800,
                  fontSize: 28,
                  flexShrink: 0,
                }}
              >
                {statusIcon}
              </div>
              <div style={{ display: 'grid', gap: 8 }}>
                <div style={{ fontSize: 32, fontWeight: 800, color: '#111827' }}>
                  {statusModel.paymentHeadline}
                </div>
                <div style={{ fontSize: 15, color: '#4b5563', lineHeight: 1.5 }}>
                  {statusModel.paymentMessage}
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: paymentTone.text }}>
                  {statusModel.verificationMessage}
                </div>
              </div>
            </div>

            <div
              style={{
                background: '#ffffff',
                borderRadius: 18,
                border: '1px solid #d5d9d9',
                padding: 24,
              }}
            >
              <div style={{ fontSize: 24, fontWeight: 700, color: '#111827' }}>
                Order details
              </div>
              <div
                style={{
                  marginTop: 18,
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                  gap: 16,
                }}
              >
                <div>
                  <div style={{ fontSize: 12, color: '#565959', textTransform: 'uppercase' }}>
                    Order total
                  </div>
                  <div style={{ fontSize: 28, fontWeight: 800, marginTop: 4 }}>
                    {displayAmount}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: '#565959', textTransform: 'uppercase' }}>
                    Transaction ID
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>
                    {displayTxnId}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: '#565959', textTransform: 'uppercase' }}>
                    Paid to
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>
                    {displayReceiver}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: 12, color: '#565959', textTransform: 'uppercase' }}>
                    Paid on
                  </div>
                  <div style={{ fontSize: 16, fontWeight: 700, marginTop: 4 }}>
                    {formatTransactionTime(statusResult)}
                  </div>
                </div>
              </div>
            </div>

            <div
              style={{
                background: '#ffffff',
                borderRadius: 18,
                border: '1px solid #d5d9d9',
                padding: 24,
                display: 'grid',
                gap: 16,
              }}
            >
              <div style={{ fontSize: 22, fontWeight: 700, color: '#111827' }}>
                {isUpiPayment ? 'UPI payment' : 'Wallet verification'}
              </div>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 12px',
                  borderRadius: 999,
                  fontSize: 13,
                  fontWeight: 700,
                  background: verificationTone.background,
                  border: `1px solid ${verificationTone.border}`,
                  color: verificationTone.color,
                  width: 'fit-content',
                }}
              >
                {statusModel.verificationLabel}:{' '}
                {statusModel.verificationState === 'verified'
                  ? 'Verified'
                  : statusModel.verificationState === 'pending'
                    ? 'Pending'
                    : statusModel.verificationState === 'warning'
                      ? 'Needs attention'
                      : 'Failed'}
              </div>
              {phase === 'verifying' ? (
                <div style={{ fontSize: 14, color: '#5f259f' }}>{statusModel.verificationMessage}</div>
              ) : (
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                    gap: 14,
                    fontSize: 14,
                    color: '#4b5563',
                  }}
                >
                  <div>
                    <strong>Verified:</strong> {statusResult.verified ? 'Yes' : 'No'}
                  </div>
                  <div>
                    <strong>Wallet response:</strong> {statusResult.responseCode || 'N/A'}
                  </div>
                  <div>
                    <strong>Transaction state:</strong> {statusResult.transactionState || 'N/A'}
                  </div>
                  <div>
                    <strong>Verified at:</strong> {statusResult.verifiedAt || 'Pending'}
                  </div>
                  <div style={{ gridColumn: '1 / -1' }}>
                    <strong>Message:</strong> {statusResult.message || 'No message'}
                  </div>
                </div>
              )}
            </div>

            {verifiedTransaction ? (
              <div
                style={{
                  background: '#ffffff',
                  borderRadius: 18,
                  border: '1px solid #d5d9d9',
                  padding: 24,
                  display: 'grid',
                  gap: 14,
                }}
              >
                <div style={{ fontSize: 22, fontWeight: 700, color: '#111827' }}>
                  Verified transaction details
                </div>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
                    gap: 14,
                    fontSize: 14,
                    color: '#4b5563',
                  }}
                >
                  <div>
                    <strong>Category:</strong> {verifiedTransaction.category || 'N/A'}
                  </div>
                  <div>
                    <strong>Type:</strong> {verifiedTransaction.transactionType || 'N/A'}
                  </div>
                  <div>
                    <strong>Wallet merchant:</strong> {verifiedTransaction.merchantId || 'N/A'}
                  </div>
                  <div>
                    <strong>Wallet receiver:</strong> {verifiedTransaction.externalVpa || 'N/A'}
                  </div>
                </div>
              </div>
            ) : null}
          </div>

          <div style={{ display: 'grid', gap: 20 }}>
            <div
              style={{
                background: '#ffffff',
                borderRadius: 18,
                border: '1px solid #d5d9d9',
                padding: 24,
                display: 'grid',
                gap: 14,
              }}
            >
              <div style={{ fontSize: 20, fontWeight: 700, color: '#111827' }}>
                Payment summary
              </div>
              <div style={{ display: 'grid', gap: 10, fontSize: 14, color: '#4b5563' }}>
                <div>
                  <strong>Reported status:</strong>{' '}
                  {statusResult.redirectStatus || statusResult.status || 'N/A'}
                </div>
                <div>
                  <strong>Merchant:</strong> {merchantName}
                </div>
                <div>
                  <strong>{isUpiPayment ? 'Payment type:' : 'Wallet ID:'}</strong>{' '}
                  {isUpiPayment ? 'UPI Collect' : (statusResult.walletId || 'N/A')}
                </div>
                <div style={{ wordBreak: 'break-all' }}>
                  <strong>{isUpiPayment ? 'UPI transaction ID:' : 'Wallet token:'}</strong>{' '}
                  {isUpiPayment
                    ? (statusResult.txnId || 'N/A')
                    : (statusResult.paymentToken || 'Missing')}
                </div>
              </div>
              <button
                type="button"
                onClick={handleContinue}
                style={{
                  ...buttonStyle,
                  background: '#ffd814',
                  color: '#111827',
                  border: '1px solid #fcd200',
                }}
              >
                Continue shopping
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
