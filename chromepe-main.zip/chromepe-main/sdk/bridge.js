export function isChromePeAvailable(target = globalThis) {
  return Boolean(
    target &&
      target.phonepe &&
      target.phonepe.isChromePe &&
      typeof target.phonepe.request === 'function',
  );
}

export function isChromePeVerificationAvailable(target = globalThis) {
  return Boolean(
    target &&
      target.phonepe &&
      target.phonepe.isChromePe &&
      typeof target.phonepe.verifyPayment === 'function',
  );
}

function getSearchString(input = '') {
  if (typeof input === 'string') {
    return input.startsWith('?') || !input ? input : `?${input}`;
  }

  if (input && typeof input.search === 'string') {
    return input.search;
  }

  return '';
}

export function buildPaymentPayload({
  receiverVpa,
  amount,
  currency = 'INR',
  redirectUrl = '',
}) {
  const trimmedVpa = String(receiverVpa || '').trim();
  const normalizedAmount = Number(amount);
  const normalizedRedirectUrl = String(redirectUrl || '').trim();

  if (!trimmedVpa) {
    throw new Error('A valid receiver VPA is required.');
  }

  if (!Number.isFinite(normalizedAmount) || normalizedAmount <= 0) {
    throw new Error('A valid payment amount is required.');
  }

  return {
    receiverVpa: trimmedVpa,
    amount: normalizedAmount,
    currency: String(currency || 'INR').trim().toUpperCase() || 'INR',
    ...(normalizedRedirectUrl ? { redirectUrl: normalizedRedirectUrl } : {}),
  };
}

export function buildVerificationPayload({
  txnId,
  amount = 0,
  currency = 'INR',
  receiverVpa = '',
  paymentToken,
  status = '',
}) {
  const normalizedTxnId = String(txnId || '').trim();
  const normalizedToken = String(paymentToken || '').trim();

  if (!normalizedTxnId) {
    throw new Error('A valid ChromePe transaction ID is required.');
  }

  if (!normalizedToken) {
    throw new Error('A valid ChromePe payment token is required.');
  }

  return {
    txnId: normalizedTxnId,
    amount: Number(amount || 0),
    currency: String(currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(receiverVpa || '').trim(),
    paymentToken: normalizedToken,
    status: String(status || '').trim().toUpperCase(),
  };
}

export function readRedirectPayload(input = '') {
  const params = new URLSearchParams(getSearchString(input));
  const paymentToken = String(params.get('chromepe_token') || '').trim();
  const txnId = String(params.get('chromepe_txn_id') || '').trim();
  const status = String(params.get('chromepe_status') || '').trim().toUpperCase();

  return {
    hasPayload: Boolean(paymentToken || txnId || status),
    txnId,
    amount: Number(params.get('chromepe_amount') || 0),
    currency: String(params.get('chromepe_currency') || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(params.get('chromepe_receiver') || '').trim(),
    paymentToken,
    status,
  };
}

export function hasRedirectPayload(input = '') {
  return readRedirectPayload(input).hasPayload;
}

export function clearRedirectPayloadFromUrl(target = globalThis) {
  if (!target?.location?.href || !target?.history?.replaceState) {
    return;
  }

  const url = new URL(target.location.href);
  [
    'chromepe_status',
    'chromepe_txn_id',
    'chromepe_amount',
    'chromepe_currency',
    'chromepe_receiver',
    'chromepe_token',
  ].forEach((key) => {
    url.searchParams.delete(key);
  });

  target.history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
}

export function normalizePaymentResult(result = {}) {
  return {
    txnId: String(result.txnId || ''),
    amount: Number(result.amount || 0),
    currency: String(result.currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(result.receiverVpa || '').trim(),
    paymentToken: String(result.paymentToken || ''),
    redirectUrl: String(result.redirectUrl || '').trim(),
    status: String(result.status || 'SUCCESS').toUpperCase(),
  };
}

export function normalizeVerificationResult(result = {}) {
  const verifiedTransaction =
    result.verifiedTransaction && typeof result.verifiedTransaction === 'object'
      ? {
          transactionId: String(result.verifiedTransaction.transactionId || ''),
          merchantId: String(result.verifiedTransaction.merchantId || '').trim(),
          externalVpa: String(result.verifiedTransaction.externalVpa || '').trim(),
          amount: Number(result.verifiedTransaction.amount || 0),
          currencyCode:
            String(result.verifiedTransaction.currencyCode || 'INR').trim().toUpperCase() ||
            'INR',
          transactionState: String(result.verifiedTransaction.transactionState || '')
            .trim()
            .toUpperCase(),
          transactionType: String(result.verifiedTransaction.transactionType || '')
            .trim()
            .toUpperCase(),
          category: String(result.verifiedTransaction.category || '').trim().toUpperCase(),
          responseCode: String(result.verifiedTransaction.responseCode || '')
            .trim()
            .toUpperCase(),
          message: String(result.verifiedTransaction.message || '').trim(),
          transactionTime: Number(result.verifiedTransaction.transactionTime || 0),
        }
      : null;

  return {
    verified: Boolean(result.verified ?? result.success),
    txnId: String(result.txnId || ''),
    amount: Number(result.amount || 0),
    currency: String(result.currency || 'INR').trim().toUpperCase() || 'INR',
    receiverVpa: String(result.receiverVpa || '').trim(),
    paymentToken: String(result.paymentToken || ''),
    status: String(result.status || (result.verified ? 'SUCCESS' : 'FAILED')).toUpperCase(),
    redirectStatus: String(result.redirectStatus || '').toUpperCase(),
    responseCode: String(result.responseCode || result.code || '').toUpperCase(),
    transactionState: String(result.transactionState || '').toUpperCase(),
    walletId: String(result.walletId || ''),
    message: String(result.message || ''),
    verifiedAt: String(result.verifiedAt || ''),
    verifiedTransaction,
  };
}

export async function requestPayment(target, payload) {
  if (!isChromePeAvailable(target)) {
    throw {
      error: 'ChromePe extension is not installed.',
      code: 'NOT_INSTALLED',
    };
  }

  const result = await target.phonepe.request(buildPaymentPayload(payload));
  return normalizePaymentResult(result);
}

export async function verifyRedirectPayment(target, payload) {
  if (!isChromePeVerificationAvailable(target)) {
    throw {
      error:
        'ChromePe extension is required to verify this payment. Reload the page with the extension enabled.',
      code: 'NOT_AVAILABLE',
    };
  }

  const result = await target.phonepe.verifyPayment(buildVerificationPayload(payload));
  return normalizeVerificationResult(result);
}
