import test from 'node:test';
import assert from 'node:assert/strict';

import { normalizeVerificationResult } from './bridge.js';

test('normalizeVerificationResult preserves verified wallet transaction details', () => {
  const result = normalizeVerificationResult({
    verified: true,
    txnId: 'TXN123',
    amount: 499,
    currency: 'inr',
    receiverVpa: 'amazon@pay',
    responseCode: 'success',
    transactionState: 'success',
    verifiedTransaction: {
      transactionId: 'TXN123',
      merchantId: 'FXM',
      externalVpa: 'amazon@pay',
      amount: 49900,
      currencyCode: 'INR',
      transactionState: 'SUCCESS',
      category: 'ORDER',
      transactionTime: 1710000000000,
    },
  });

  assert.equal(result.verified, true);
  assert.equal(result.currency, 'INR');
  assert.equal(result.responseCode, 'SUCCESS');
  assert.equal(result.transactionState, 'SUCCESS');
  assert.equal(result.verifiedTransaction.transactionId, 'TXN123');
  assert.equal(result.verifiedTransaction.merchantId, 'FXM');
  assert.equal(result.verifiedTransaction.externalVpa, 'amazon@pay');
  assert.equal(result.verifiedTransaction.amount, 49900);
  assert.equal(result.verifiedTransaction.currencyCode, 'INR');
  assert.equal(result.verifiedTransaction.transactionState, 'SUCCESS');
  assert.equal(result.verifiedTransaction.category, 'ORDER');
  assert.equal(result.verifiedTransaction.transactionTime, 1710000000000);
});
