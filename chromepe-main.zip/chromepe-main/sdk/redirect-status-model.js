function normalizeStatus(value, fallback = '') {
  return String(value || fallback).trim().toUpperCase();
}

function buildVerificationWarning(result = {}) {
  const responseCode = normalizeStatus(result.responseCode || result.code);
  const message = String(result.message || result.error || '').trim();

  if (responseCode === 'OIM010' || /token expired/i.test(message)) {
    return 'Automatic wallet verification could not complete because the stage token has expired in ChromePe Settings.';
  }

  if (responseCode === 'OIM004' || /unauthorized|token absent/i.test(message)) {
    return 'Automatic wallet verification could not complete because the wallet token in ChromePe Settings is invalid.';
  }

  if (responseCode === 'MISSING_CREDENTIALS' || responseCode === 'MISSING_WALLET_ID') {
    return 'Automatic wallet verification could not complete because ChromePe Settings are incomplete.';
  }

  return message || 'Automatic wallet verification could not confirm this payment yet.';
}

export function getRedirectStatusModel({
  redirectStatus = '',
  phase = 'verifying',
  result = null,
}) {
  const normalizedRedirectStatus = normalizeStatus(
    redirectStatus,
    result?.redirectStatus || result?.status,
  );
  const isUpi = result?.verifiedTransaction?.transactionType === 'UPI_COLLECT';
  const verificationLabel = isUpi ? 'UPI payment' : 'Wallet verification';

  const paymentState =
    normalizedRedirectStatus === 'SUCCESS'
      ? 'success'
      : normalizedRedirectStatus === 'FAILED'
        ? 'error'
        : phase === 'success'
          ? 'success'
          : phase === 'error'
            ? 'error'
            : 'pending';

  const paymentHeadline =
    paymentState === 'success'
      ? 'Payment successful'
      : paymentState === 'error'
        ? 'Payment failed'
        : 'Payment status pending';

  const paymentMessage =
    paymentState === 'success'
      ? 'ChromePe redirected back with a successful payment result.'
      : paymentState === 'error'
        ? 'ChromePe redirected back with a failed payment result.'
        : 'ChromePe is still waiting for a final payment outcome.';

  if (phase === 'success') {
    return {
      paymentState,
      paymentHeadline,
      paymentMessage,
      verificationState: 'verified',
      verificationLabel,
      verificationMessage:
        String(result?.message || '').trim() ||
        (isUpi ? 'Approved on ChromePe mobile app.' : 'Verified with wallet API.'),
    };
  }

  if (phase === 'verifying') {
    return {
      paymentState,
      paymentHeadline,
      paymentMessage,
      verificationState: 'pending',
      verificationLabel,
      verificationMessage: 'Verifying this transaction with the wallet API...',
    };
  }

  if (paymentState === 'success') {
    return {
      paymentState,
      paymentHeadline,
      paymentMessage,
      verificationState: 'warning',
      verificationLabel,
      verificationMessage: buildVerificationWarning(result || {}),
    };
  }

  return {
    paymentState,
    paymentHeadline,
    paymentMessage,
    verificationState: 'failed',
    verificationLabel,
    verificationMessage:
      String(result?.message || result?.error || '').trim() ||
      'Wallet verification failed.',
  };
}
