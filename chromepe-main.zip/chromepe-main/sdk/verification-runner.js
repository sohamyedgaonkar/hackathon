export function createVerificationRunner() {
  let lastKey = '';
  let lastPromise = null;
  let lastResult = null;

  return {
    async run(key, verify) {
      const normalizedKey = String(key || '');

      if (normalizedKey && normalizedKey === lastKey && lastResult) {
        return lastResult;
      }

      if (normalizedKey && normalizedKey === lastKey && lastPromise) {
        return lastPromise;
      }

      lastKey = normalizedKey;
      lastResult = null;
      lastPromise = Promise.resolve()
        .then(() => verify())
        .then((result) => {
          lastResult = result;
          return result;
        })
        .catch((error) => {
          lastPromise = null;
          throw error;
        });

      return lastPromise;
    },
  };
}
