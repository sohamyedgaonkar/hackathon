import test from 'node:test';
import assert from 'node:assert/strict';

import { createVerificationRunner } from './verification-runner.js';

test('createVerificationRunner reuses the same successful verification for the same payload key', async () => {
  let calls = 0;
  const runner = createVerificationRunner();

  const first = await runner.run('txn:TXN123', async () => {
    calls += 1;
    return { verified: true, txnId: 'TXN123', responseCode: 'SUCCESS' };
  });

  const second = await runner.run('txn:TXN123', async () => {
    calls += 1;
    return { verified: true, txnId: 'TXN123', responseCode: 'SUCCESS' };
  });

  assert.equal(calls, 1);
  assert.deepEqual(second, first);
});
