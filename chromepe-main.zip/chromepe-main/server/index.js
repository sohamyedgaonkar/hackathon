import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';

const app = express();
const PORT = process.env.PORT || 3456;
const SESSION_TTL_MS = 5 * 60 * 1000; // 5 minutes

app.use(cors());
app.use(express.json());

function cloneLinkedPayload(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }

  const payload = JSON.parse(JSON.stringify(value));
  return Object.keys(payload).length ? payload : null;
}

// In-memory session store: sessionId → { credentials, createdAt }
const sessions = new Map();

// Garbage-collect expired sessions every 60s
setInterval(() => {
  const now = Date.now();
  for (const [id, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL_MS) {
      sessions.delete(id);
    }
  }
}, 60_000);

// 1. Extension creates a new session
app.post('/session', (_req, res) => {
  const sessionId = crypto.randomUUID();
  sessions.set(sessionId, { credentials: null, createdAt: Date.now() });
  res.json({ sessionId });
});

// 2. Mobile app posts credentials after scanning QR
app.post('/session/:id/credentials', (req, res) => {
  const session = sessions.get(req.params.id);

  if (!session) {
    return res.status(404).json({ error: 'Session not found or expired.' });
  }

  const payload = cloneLinkedPayload(req.body);
  if (!payload) {
    return res.status(400).json({ error: 'A JSON object payload is required.' });
  }

  session.credentials = payload;
  session.linkedAt = Date.now();

  res.json({ ok: true, message: 'Credentials linked successfully.' });
});

// 3. Extension polls for credentials
app.get('/session/:id', (req, res) => {
  const session = sessions.get(req.params.id);

  if (!session) {
    return res.status(404).json({ error: 'Session not found or expired.' });
  }

  if (!session.credentials) {
    return res.json({ status: 'pending' });
  }

  // Return credentials and delete session (one-time use)
  const { credentials } = session;
  sessions.delete(req.params.id);
  res.json({ status: 'linked', credentials });
});

// Simple landing page when mobile scans QR — uses device biometric/PIN
app.get('/link', (req, res) => {
  const sessionId = req.query.session;

  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(404).send(`
      <html><body style="font-family:system-ui;padding:40px;text-align:center;">
        <h2>Session expired or invalid</h2>
        <p>Open ChromePe extension and generate a new QR code.</p>
      </body></html>
    `);
  }

  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ChromePe Authentication</title>
  <style>
    * { box-sizing: border-box; margin: 0; }
    body {
      font-family: Inter, system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #5f259f 0%, #8e44ad 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: #fff;
      border-radius: 24px;
      padding: 32px 24px;
      width: 100%;
      max-width: 380px;
      box-shadow: 0 24px 60px rgba(0,0,0,0.2);
      text-align: center;
    }
    .brand-icon {
      width: 72px; height: 72px; border-radius: 20px;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      color: #fff; font-size: 36px; font-weight: 800;
      display: inline-flex; align-items: center; justify-content: center;
      margin-bottom: 16px;
    }
    h1 { font-size: 22px; font-weight: 800; color: #1f2937; }
    .subtitle { font-size: 14px; color: #6b7280; margin-top: 8px; margin-bottom: 24px; }
    .btn {
      width: 100%; padding: 16px; border: none; border-radius: 14px;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      color: #fff; font-size: 16px; font-weight: 800; cursor: pointer;
      box-shadow: 0 12px 24px rgba(95,37,159,0.22);
      transition: transform 0.12s, box-shadow 0.12s;
      display: flex; align-items: center; justify-content: center; gap: 10px;
    }
    .btn:active { transform: scale(0.98); }
    .btn:disabled { opacity: 0.6; cursor: wait; }
    .btn svg { width: 24px; height: 24px; }
    .success-view { display: none; }
    .success-view.show { display: block; }
    .form-view.hide { display: none; }
    .checkmark {
      width: 80px; height: 80px; border-radius: 50%;
      background: #10b981; color: #fff;
      font-size: 40px; display: inline-flex;
      align-items: center; justify-content: center;
      margin-bottom: 16px;
    }
    .success-title { font-size: 22px; font-weight: 800; color: #1f2937; margin-bottom: 8px; }
    .success-text { font-size: 14px; color: #6b7280; }
    .error { color: #dc2626; font-size: 13px; margin-top: 16px; display: none; }
    .error.show { display: block; }
    .fingerprint-icon { font-size: 64px; margin-bottom: 20px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="form-view" id="form-view">
      <div class="brand-icon">₹</div>
      <h1>Link Browser Extension</h1>
      <p class="subtitle">Verify your identity to connect ChromePe</p>
      <div class="fingerprint-icon">🔐</div>
      <button class="btn" id="auth-btn">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4"/></svg>
        Authenticate with Device
      </button>
      <div class="error" id="error"></div>
    </div>
    <div class="success-view" id="success-view">
      <div class="checkmark">✓</div>
      <div class="success-title">Device Connected!</div>
      <p class="success-text">Your browser extension is now linked.<br/>You can close this page.</p>
    </div>
  </div>
  <script>
    const sessionId = new URLSearchParams(location.search).get('session');
    const authBtn = document.getElementById('auth-btn');
    const errorEl = document.getElementById('error');
    const formView = document.getElementById('form-view');
    const successView = document.getElementById('success-view');

    async function linkDevice() {
      const res = await fetch(location.origin + '/session/' + sessionId + '/credentials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jwt: 'authenticated-jwt-' + Date.now(),
          vpa: 'user@chromepe',
          userId: 'U' + Math.random().toString(36).substr(2, 9).toUpperCase()
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Failed to link device.');
      }
      formView.classList.add('hide');
      successView.classList.add('show');
    }

    function resetBtn() {
      authBtn.disabled = false;
      authBtn.innerHTML = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A13.916 13.916 0 008 11a4 4 0 118 0c0 1.017-.07 2.019-.203 3m-2.118 6.844A21.88 21.88 0 0015.171 17m3.839 1.132c.645-2.266.99-4.659.99-7.132A8 8 0 008 4.07M3 15.364c.64-1.319 1-2.8 1-4.364 0-1.457.39-2.823 1.07-4"/></svg> Authenticate with Device';
    }

    authBtn.addEventListener('click', async () => {
      errorEl.className = 'error';
      authBtn.disabled = true;
      authBtn.textContent = 'Verifying...';

      // Use WebAuthn to trigger device unlock (fingerprint/face/PIN)
      if (window.PublicKeyCredential) {
        try {
          const challenge = new Uint8Array(32);
          crypto.getRandomValues(challenge);

          await navigator.credentials.create({
            publicKey: {
              challenge: challenge,
              rp: { name: 'ChromePe', id: location.hostname },
              user: {
                id: new Uint8Array(16),
                name: 'chromepe-user',
                displayName: 'ChromePe User'
              },
              pubKeyCredParams: [
                { type: 'public-key', alg: -7 },
                { type: 'public-key', alg: -257 }
              ],
              authenticatorSelection: {
                authenticatorAttachment: 'platform',
                userVerification: 'required'
              },
              timeout: 60000
            }
          });

          await linkDevice();
        } catch (err) {
          if (err.name === 'NotAllowedError') {
            errorEl.textContent = 'Authentication cancelled.';
            errorEl.className = 'error show';
            resetBtn();
          } else if (err.name === 'NotSupportedError' || err.name === 'SecurityError') {
            // Device auth not available, link directly
            await linkDevice();
          } else {
            errorEl.textContent = err.message;
            errorEl.className = 'error show';
            resetBtn();
          }
        }
      } else {
        // WebAuthn not supported, link directly
        await linkDevice();
      }
    });
  </script>
</body>
</html>
  `);
});

// Mobile scanner app - scans QR and submits credentials
app.get('/scan', (_req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
  <title>ChromePe Scanner</title>
  <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; }
    body {
      font-family: Inter, system-ui, -apple-system, sans-serif;
      background: linear-gradient(135deg, #5f259f 0%, #8e44ad 100%);
      min-height: 100vh;
      padding: 16px;
    }
    .card {
      background: #fff;
      border-radius: 24px;
      padding: 24px 20px;
      max-width: 400px;
      margin: 0 auto;
      box-shadow: 0 24px 60px rgba(0,0,0,0.2);
    }
    .brand { text-align: center; margin-bottom: 20px; }
    .brand-icon {
      width: 48px; height: 48px; border-radius: 14px;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      color: #fff; font-size: 24px; font-weight: 800;
      display: inline-flex; align-items: center; justify-content: center;
      margin-bottom: 8px;
    }
    h1 { font-size: 18px; font-weight: 800; color: #1f2937; }
    .subtitle { font-size: 13px; color: #6b7280; margin-top: 4px; }
    #reader { width: 100%; border-radius: 16px; overflow: hidden; margin-bottom: 16px; }
    #reader video { border-radius: 16px; }
    .field { margin-bottom: 14px; }
    label { display: block; font-size: 12px; font-weight: 700; color: #374151; margin-bottom: 4px; }
    input, textarea {
      width: 100%; padding: 10px 12px; border: 2px solid #e5e7eb;
      border-radius: 10px; font-size: 14px; outline: none;
    }
    input:focus, textarea:focus { border-color: #5f259f; }
    textarea { min-height: 70px; resize: vertical; font-family: monospace; font-size: 12px; }
    .btn {
      width: 100%; padding: 12px; border: none; border-radius: 12px;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      color: #fff; font-size: 14px; font-weight: 800; cursor: pointer;
      box-shadow: 0 8px 20px rgba(95,37,159,0.22);
    }
    .btn:disabled { opacity: 0.6; }
    .status {
      margin-top: 14px; padding: 10px 14px; border-radius: 10px;
      font-size: 12px; font-weight: 600; text-align: center; display: none;
    }
    .status.success { display: block; background: #ecfdf5; color: #059669; }
    .status.error { display: block; background: #fef2f2; color: #dc2626; }
    .status.info { display: block; background: #f3e8ff; color: #5f259f; }
    .scanned-info { background: #f9fafb; border-radius: 10px; padding: 12px; margin-bottom: 14px; font-size: 12px; }
    .scanned-info strong { color: #5f259f; }
    .hidden { display: none !important; }
    .section-title { font-size: 14px; font-weight: 800; color: #1f2937; margin-bottom: 12px; }
  </style>
</head>
<body>
  <div class="card">
    <div class="brand">
      <div class="brand-icon">₹</div>
      <h1>ChromePe Scanner</h1>
      <p class="subtitle">Scan QR from extension to link device</p>
    </div>

    <div id="scanner-section">
      <div id="reader"></div>
      <div id="scan-status" class="status info">Point camera at the QR code in the extension</div>
    </div>

    <div id="form-section" class="hidden">
      <div class="scanned-info">
        <strong>Session detected!</strong><br/>
        <span id="session-display"></span>
      </div>

      <div class="section-title">Enter Wallet Credentials</div>

      <form id="link-form">
        <div class="field">
          <label for="jwt">JWT Token</label>
          <textarea id="jwt" placeholder="Bearer eyJhbGciOi..." spellcheck="false"></textarea>
        </div>
        <div class="field">
          <label for="vpa">VPA</label>
          <input id="vpa" type="text" placeholder="user@phonepe"/>
        </div>
        <div class="field">
          <label for="userId">User ID</label>
          <input id="userId" type="text" placeholder="U1234567890"/>
        </div>
        <button type="submit" class="btn" id="submit-btn">Link to Extension</button>
      </form>
      <div id="form-status" class="status"></div>

      <button type="button" class="btn" style="margin-top:12px; background:#6b7280;" onclick="resetScanner()">Scan Another QR</button>
    </div>
  </div>

  <script>
    let html5QrCode;
    let currentSessionId = null;
    let serverBase = location.origin; // Same server

    function showSection(section) {
      document.getElementById('scanner-section').classList.toggle('hidden', section !== 'scanner');
      document.getElementById('form-section').classList.toggle('hidden', section !== 'form');
    }

    function parseSessionFromUrl(url) {
      try {
        const u = new URL(url);
        return u.searchParams.get('session');
      } catch {
        // Try regex fallback
        const match = url.match(/session=([a-f0-9-]+)/i);
        return match ? match[1] : null;
      }
    }

    function onScanSuccess(decodedText) {
      const sessionId = parseSessionFromUrl(decodedText);
      if (!sessionId) {
        document.getElementById('scan-status').textContent = 'Invalid QR - no session found';
        document.getElementById('scan-status').className = 'status error';
        return;
      }

      currentSessionId = sessionId;
      html5QrCode.stop();
      document.getElementById('session-display').textContent = sessionId.slice(0, 8) + '...';
      showSection('form');
    }

    function startScanner() {
      showSection('scanner');
      document.getElementById('scan-status').textContent = 'Point camera at the QR code in the extension';
      document.getElementById('scan-status').className = 'status info';

      html5QrCode = new Html5Qrcode("reader");
      html5QrCode.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 250, height: 250 } },
        onScanSuccess
      ).catch(err => {
        document.getElementById('scan-status').textContent = 'Camera error: ' + err;
        document.getElementById('scan-status').className = 'status error';
      });
    }

    function resetScanner() {
      currentSessionId = null;
      document.getElementById('jwt').value = '';
      document.getElementById('vpa').value = '';
      document.getElementById('userId').value = '';
      document.getElementById('form-status').className = 'status';
      startScanner();
    }

    document.getElementById('link-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const statusEl = document.getElementById('form-status');
      const submitBtn = document.getElementById('submit-btn');
      statusEl.className = 'status';
      submitBtn.disabled = true;
      submitBtn.textContent = 'Linking...';

      const jwt = document.getElementById('jwt').value.trim();
      const vpa = document.getElementById('vpa').value.trim();
      const userId = document.getElementById('userId').value.trim();

      if (!jwt || !vpa || !userId) {
        statusEl.textContent = 'All fields are required.';
        statusEl.className = 'status error';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Link to Extension';
        return;
      }

      try {
        const res = await fetch(serverBase + '/session/' + currentSessionId + '/credentials', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jwt, vpa, userId }),
        });
        const data = await res.json();

        if (res.ok) {
          statusEl.textContent = '✓ Linked! The extension will log you in automatically.';
          statusEl.className = 'status success';
          submitBtn.textContent = 'Linked ✓';
        } else {
          throw new Error(data.error || 'Failed to link.');
        }
      } catch (err) {
        statusEl.textContent = err.message;
        statusEl.className = 'status error';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Link to Extension';
      }
    });

    // Start scanner on load
    startScanner();
  </script>
</body>
</html>
  `);
});

// Test page with large QR code for debugging
app.get('/test-qr', (_req, res) => {
  const sessionId = crypto.randomUUID();
  sessions.set(sessionId, { credentials: null, createdAt: Date.now() });
  const linkUrl = `http://10.31.191.109:${PORT}/link?session=${sessionId}`;
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(linkUrl)}`;
  
  res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Test QR</title>
  <style>
    body { font-family: system-ui; text-align: center; padding: 40px; background: #f0f0f0; }
    img { margin: 20px auto; display: block; border-radius: 12px; }
    .url { word-break: break-all; font-size: 12px; color: #666; margin-top: 20px; padding: 10px; background: #fff; border-radius: 8px; max-width: 400px; margin-left: auto; margin-right: auto; }
  </style>
</head>
<body>
  <h2>Scan this QR with your phone camera</h2>
  <img src="${qrImageUrl}" alt="QR Code" width="300" height="300"/>
  <div class="url">${linkUrl}</div>
  <p style="margin-top:20px;color:#888;">Session ID: ${sessionId}</p>
</body>
</html>
  `);
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('ChromePe relay server running on http://localhost:' + PORT);
  console.log('Mobile scanner available at http://<your-ip>:' + PORT + '/scan');
});
