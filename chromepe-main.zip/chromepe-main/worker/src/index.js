// ChromePe Relay Server - Cloudflare Worker
// Bridges extension and mobile app for QR-based device linking,
// and handles delegate payment intents from merchants to the mobile app.
//
// Architecture:
//   KV (SESSIONS)      — tracks session existence with automatic TTL expiry
//   SessionRelay DO    — stores credentials with strong consistency
//   PaymentRelay DO    — stores delegate payment intents and callbacks

const SESSION_TTL_SECONDS = 5 * 60;  // 5 minutes
const PAYMENT_TTL_SECONDS = 10 * 60; // 10 minutes

function cloneLinkedPayload(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    return null;
  }

  const payload = JSON.parse(JSON.stringify(value));
  return Object.keys(payload).length ? payload : null;
}

// ---------------------------------------------------------------------------
// SessionRelay Durable Object — one instance per session ID
// Provides strongly-consistent credential exchange (no propagation delay)
// ---------------------------------------------------------------------------
export class SessionRelay {
  constructor(state) {
    this.state = state;
  }

  async fetch(request) {
    const { method } = request;

    if (method === 'POST') {
      const payload = cloneLinkedPayload(await request.json());
      if (!payload) {
        return jsonResponse({ error: 'A JSON object payload is required.' }, 400);
      }
      await this.state.storage.put('credentials', JSON.stringify(payload));
      // Auto-delete after TTL
      await this.state.storage.setAlarm(Date.now() + SESSION_TTL_SECONDS * 1000);
      return jsonResponse({ ok: true, message: 'Credentials linked successfully.' });
    }

    if (method === 'GET') {
      const raw = await this.state.storage.get('credentials');
      if (!raw) {
        return jsonResponse({ status: 'pending' });
      }
      // One-time use — delete after reading
      await this.state.storage.deleteAll();
      return jsonResponse({ status: 'linked', credentials: JSON.parse(raw) });
    }

    return jsonResponse({ error: 'Not found' }, 404);
  }

  async alarm() {
    await this.state.storage.deleteAll();
  }
}

// ---------------------------------------------------------------------------
// PaymentRelay Durable Object — one instance per txnId
// Stores delegate payment intent and callback result with strong consistency.
//
// Routes (internal):
//   POST /init      — merchant stores payment intent
//   GET  /          — app/merchant fetches payment details
//   POST /callback  — app posts SUCCESS or FAILED result
// ---------------------------------------------------------------------------
export class PaymentRelay {
  constructor(state) {
    this.state = state;
  }

  async fetch(request) {
    const url = new URL(request.url);
    const { method } = request;
    const path = url.pathname;

    if (method === 'POST' && path === '/init') {
      const body = await request.json();
      const intent = {
        txnId: body.txnId,
        amount: body.amount,
        vpa: body.vpa,
        merchantName: body.merchantName,
        description: body.description || '',
        status: 'PENDING',
        createdAt: new Date().toISOString(),
      };
      await this.state.storage.put('intent', JSON.stringify(intent));
      await this.state.storage.setAlarm(Date.now() + PAYMENT_TTL_SECONDS * 1000);
      return jsonResponse({ ok: true });
    }

    if (method === 'GET' && path === '/') {
      const raw = await this.state.storage.get('intent');
      if (!raw) return jsonResponse({ error: 'Payment not found or expired.' }, 404);
      return jsonResponse(JSON.parse(raw));
    }

    if (method === 'POST' && path === '/callback') {
      const raw = await this.state.storage.get('intent');
      if (!raw) return jsonResponse({ error: 'Payment not found or expired.' }, 404);
      const intent = JSON.parse(raw);
      const { status, timestamp } = await request.json();
      intent.status = status || 'SUCCESS';
      intent.completedAt = timestamp || new Date().toISOString();
      await this.state.storage.put('intent', JSON.stringify(intent));
      return jsonResponse({ ok: true });
    }

    return jsonResponse({ error: 'Not found' }, 404);
  }

  async alarm() {
    await this.state.storage.deleteAll();
  }
}

// ---------------------------------------------------------------------------
// Helper functions
// ---------------------------------------------------------------------------
function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  };
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', ...corsHeaders() },
  });
}

function htmlResponse(html, status = 200) {
  return new Response(html, {
    status,
    headers: { 'Content-Type': 'text/html', ...corsHeaders() },
  });
}

// ---------------------------------------------------------------------------
// Main Worker
// ---------------------------------------------------------------------------
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders() });
    }

    // POST /session — Create new session
    if (method === 'POST' && path === '/session') {
      const sessionId = crypto.randomUUID();
      // KV tracks existence (for /link page validation and 404 responses)
      await env.SESSIONS.put(sessionId, '1', { expirationTtl: SESSION_TTL_SECONDS });
      return jsonResponse({ sessionId });
    }

    // POST /session/:id/credentials — Mobile app posts credentials
    if (method === 'POST' && path.match(/^\/session\/[^/]+\/credentials$/)) {
      const sessionId = path.split('/')[2];
      const exists = await env.SESSIONS.get(sessionId);
      if (!exists) {
        return jsonResponse({ error: 'Session not found or expired.' }, 404);
      }
      // Delegate to DO for strongly-consistent write
      const stub = env.SESSION_RELAY.get(env.SESSION_RELAY.idFromName(sessionId));
      return stub.fetch(new Request('https://do/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: request.body,
      }));
    }

    // GET /session/:id — Extension polls for credentials
    if (method === 'GET' && path.match(/^\/session\/[^/]+$/) && !path.includes('/credentials')) {
      const sessionId = path.split('/')[2];
      const exists = await env.SESSIONS.get(sessionId);
      if (!exists) {
        return jsonResponse({ error: 'Session not found or expired.' }, 404);
      }
      // Delegate to DO for strongly-consistent read
      const stub = env.SESSION_RELAY.get(env.SESSION_RELAY.idFromName(sessionId));
      const result = await stub.fetch(new Request('https://do/', { method: 'GET' }));
      // If linked, clean up KV entry too
      const body = await result.json();
      if (body.status === 'linked') {
        await env.SESSIONS.delete(sessionId);
      }
      return jsonResponse(body, result.status);
    }

    // GET /link — Fallback web page for browsers (if app not installed)
    if (method === 'GET' && path === '/link') {
      const sessionId = url.searchParams.get('session');
      const sessionRaw = sessionId ? await env.SESSIONS.get(sessionId) : null;

      if (!sessionRaw) {
        return htmlResponse(`
          <html><body style="font-family:system-ui;padding:40px;text-align:center;">
            <h2>Session expired or invalid</h2>
            <p>Open ChromePe extension and generate a new QR code.</p>
          </body></html>
        `, 404);
      }

      return htmlResponse(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ChromePe</title>
  <style>
    * { box-sizing: border-box; margin: 0; }
    body {
      font-family: Inter, system-ui, sans-serif;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: #fff;
      border-radius: 24px;
      padding: 32px 24px;
      max-width: 380px;
      text-align: center;
      box-shadow: 0 24px 60px rgba(0,0,0,0.2);
    }
    .icon { font-size: 64px; margin-bottom: 16px; }
    h1 { font-size: 22px; color: #1f2937; margin-bottom: 8px; }
    p { font-size: 14px; color: #6b7280; margin-bottom: 24px; }
    .btn {
      display: inline-block;
      padding: 14px 28px;
      background: linear-gradient(135deg, #5f259f, #8e44ad);
      color: #fff;
      font-size: 16px;
      font-weight: 700;
      border-radius: 14px;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">📱</div>
    <h1>Open in ChromePe App</h1>
    <p>Install the ChromePe app to link your wallet to the browser extension.</p>
    <a href="chromepe://link?session=${sessionId}" class="btn">Open App</a>
  </div>
</body>
</html>
      `);
    }

    // GET / — Health check
    if (method === 'GET' && path === '/') {
      return jsonResponse({ status: 'ok', service: 'ChromePe Relay' });
    }

    // -----------------------------------------------------------------------
    // Delegate Payment APIs
    // -----------------------------------------------------------------------

    // POST /payment/initiate — Merchant creates a payment intent
    // Body: { amount, vpa, merchantName, description? }
    // Returns: { txnId, deepLink, statusUrl }
    if (method === 'POST' && path === '/payment/initiate') {
      const body = await request.json().catch(() => null);
      if (!body || !body.amount || !body.vpa) {
        return jsonResponse({ error: 'amount and vpa are required.' }, 400);
      }

      const txnId = `TXN${Date.now()}`;
      const description = body.description || '';
      const encodedVpa = encodeURIComponent(body.vpa);
      const encodedName = encodeURIComponent(body.merchantName || body.vpa);
      const encodedDesc = encodeURIComponent(description);
      const deepLink = `chromepe://pay?amount=${body.amount}&vpa=${encodedVpa}&name=${encodedName}&txnId=${txnId}${encodedDesc ? `&desc=${encodedDesc}` : ''}`;

      // Store payment intent in Durable Object
      const stub = env.PAYMENT_RELAY.get(env.PAYMENT_RELAY.idFromName(txnId));
      await stub.fetch(new Request('https://do/init', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ txnId, amount: body.amount, vpa: body.vpa, merchantName: body.merchantName || body.vpa, description }),
      }));

      // Also store in KV so the app can poll by VPA: key = "pending:{vpa}", value = txnId
      // Only one pending payment per VPA at a time (latest wins)
      await env.SESSIONS.put(`pending:${body.vpa}`, txnId, { expirationTtl: PAYMENT_TTL_SECONDS });

      return jsonResponse({
        ok: true,
        txnId,
        deepLink,
        statusUrl: `${url.origin}/payment/${txnId}/status`,
      });
    }

    // GET /payment/pending?vpa=<vpa> — App polls for pending payment targeted at its VPA
    // Returns the full payment intent if one exists, or { pending: false }
    if (method === 'GET' && path === '/payment/pending') {
      const vpa = url.searchParams.get('vpa');
      if (!vpa) return jsonResponse({ error: 'vpa query param required.' }, 400);

      const txnId = await env.SESSIONS.get(`pending:${vpa}`);
      if (!txnId) return jsonResponse({ pending: false });

      const stub = env.PAYMENT_RELAY.get(env.PAYMENT_RELAY.idFromName(txnId));
      const result = await stub.fetch(new Request('https://do/', { method: 'GET' }));
      const intent = await result.json();

      // Only surface PENDING payments (don't re-trigger already completed ones)
      if (!intent || intent.status !== 'PENDING') {
        await env.SESSIONS.delete(`pending:${vpa}`);
        return jsonResponse({ pending: false });
      }

      return jsonResponse({ pending: true, ...intent });
    }

    // GET /payment/:txnId — App or merchant fetches payment details
    if (method === 'GET' && path.match(/^\/payment\/[^/]+$/) && !path.includes('/status')) {
      const txnId = path.split('/')[2];
      const stub = env.PAYMENT_RELAY.get(env.PAYMENT_RELAY.idFromName(txnId));
      const result = await stub.fetch(new Request('https://do/', { method: 'GET' }));
      const body = await result.json();
      return jsonResponse(body, result.status);
    }

    // POST /payment/:txnId/callback — App posts payment result
    // Body: { status: 'SUCCESS' | 'FAILED', timestamp }
    if (method === 'POST' && path.match(/^\/payment\/[^/]+\/callback$/)) {
      const txnId = path.split('/')[2];
      const stub = env.PAYMENT_RELAY.get(env.PAYMENT_RELAY.idFromName(txnId));
      const result = await stub.fetch(new Request('https://do/callback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: request.body,
      }));
      const body = await result.json();
      return jsonResponse(body, result.status);
    }

    // GET /payment/:txnId/status — Merchant polls for payment result
    if (method === 'GET' && path.match(/^\/payment\/[^/]+\/status$/)) {
      const txnId = path.split('/')[2];
      const stub = env.PAYMENT_RELAY.get(env.PAYMENT_RELAY.idFromName(txnId));
      const result = await stub.fetch(new Request('https://do/', { method: 'GET' }));
      const body = await result.json();
      return jsonResponse(body, result.status);
    }

    return jsonResponse({ error: 'Not found' }, 404);
  },
};
