import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import colors from '../theme/colors';

interface Props {
  icon: string;
  label: string;
  onPress: () => void;
}

export default function QuickActionButton({icon, label, onPress}: Props) {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.iconWrapper}>
        <Icon name={icon} size={24} color={colors.primary} />
      </View>
      <Text style={styles.label}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {alignItems: 'center', width: 70},
  iconWrapper: {
    backgroundColor: '#f3e8ff',
    borderRadius: 14,
    padding: 12,
    marginBottom: 6,
  },
  label: {fontSize: 11, color: colors.textPrimary, textAlign: 'center'},
});
