import React from 'react';
import {ScrollView, StatusBar, StyleSheet, Text, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import type {NativeStackNavigationProp} from '@react-navigation/native-stack';
import BalanceCard from '../components/BalanceCard';
import QuickActionButton from '../components/QuickActionButton';
import TransactionItem from '../components/TransactionItem';
import {currentUser, transactions} from '../data/mockData';
import type {HomeStackParams} from '../navigation/AppNavigator';
import colors from '../theme/colors';

type Props = {
  navigation: NativeStackNavigationProp<HomeStackParams, 'Home'>;
};

export default function HomeScreen({navigation}: Props) {
  const recent = transactions.slice(0, 5);

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.primary} />
      <ScrollView>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning 👋</Text>
            <Text style={styles.name}>{currentUser.name}</Text>
          </View>
        </View>
        <View style={styles.headerBg}>
          <BalanceCard
            balance={currentUser.walletBalance}
            bankName="HDFC Bank"
            accountMasked="•••• 4521"
          />
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>QUICK ACTIONS</Text>
          <View style={styles.actionsRow}>
            <QuickActionButton
              icon="send"
              label="Send"
              onPress={() => navigation.navigate('SendMoney')}
            />
            <QuickActionButton icon="call-received" label="Request" onPress={() => {}} />
            <QuickActionButton
              icon="smartphone"
              label="Recharge"
              onPress={() => navigation.navigate('Recharge')}
            />
            <QuickActionButton
              icon="receipt-long"
              label="Bills"
              onPress={() => navigation.navigate('Bills')}
            />
          </View>
        </View>
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>RECENT TRANSACTIONS</Text>
          {recent.map(t => (
            <TransactionItem
              key={t.id}
              name={t.name}
              amount={t.amount}
              type={t.type}
              date={t.date}
              note={t.note}
            />
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {flex: 1, backgroundColor: colors.primary},
  header: {backgroundColor: colors.primary, paddingHorizontal: 20, paddingTop: 16},
  greeting: {color: 'rgba(255,255,255,0.8)', fontSize: 13},
  name: {color: '#fff', fontSize: 20, fontWeight: '700', marginTop: 2},
  headerBg: {backgroundColor: colors.primary, paddingHorizontal: 20, paddingBottom: 24},
  section: {backgroundColor: colors.card, marginTop: 8, paddingHorizontal: 20, paddingVertical: 16},
  sectionLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.textSecondary,
    letterSpacing: 0.5,
    marginBottom: 14,
  },
  actionsRow: {flexDirection: 'row', justifyContent: 'space-between'},
});
