const colors = {
  primary: '#5f259f',
  primaryDark: '#4a1a7d',
  accent: '#f5a623',
  background: '#f5f5f5',
  card: '#ffffff',
  success: '#28a745',
  error: '#dc3545',
  textPrimary: '#1a1a1a',
  textSecondary: '#666666',
};

export default colors;
