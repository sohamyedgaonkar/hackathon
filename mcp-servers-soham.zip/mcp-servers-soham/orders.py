from datetime import datetime, timezone

import httpx

PHONEPE_BASE_URL = "https://api.phonepe.com"


class OrderManager:
    def __init__(self, phonepe_token: str):
        if not phonepe_token:
            raise ValueError("PHONEPE_TOKEN is required but was empty")
        self._token = phonepe_token
        self._orders: dict[str, dict] = {}
        self._counter = 0

    def _next_order_id(self) -> str:
        self._counter += 1
        return f"ORD-{self._counter}"

    async def create_order(
        self,
        items: list[dict],
        total: int,
        customer_name: str,
        phone_number: str,
    ) -> dict:
        order_id = self._next_order_id()
        order = {
            "order_id": order_id,
            "customer_name": customer_name,
            "phone_number": phone_number,
            "items": items,
            "total": total,
            "status": "pending",
            "payment_response": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        url = f"{PHONEPE_BASE_URL}/phonepe/pay/{self._token}"
        payload = {
            "order_id": order_id,
            "amount": total,
            "customer_name": customer_name,
            "phone_number": phone_number,
            "items": items,
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload)

            if response.status_code >= 200 and response.status_code < 300:
                order["status"] = "paid"
                order["payment_response"] = response.json()
            else:
                order["status"] = "payment_failed"
                order["error"] = f"Payment failed (HTTP {response.status_code}): {response.text}"
                order["payment_response"] = response.json()
        except Exception as e:
            order["status"] = "payment_failed"
            order["error"] = str(e)

        self._orders[order_id] = order
        return order

    def get_order(self, order_id: str) -> dict | None:
        return self._orders.get(order_id)
