from datetime import datetime, timezone

import httpx

PHONEPE_BASE_URL = "https://api.phonepe.com"


class BookingManager:
    def __init__(self, phonepe_token: str):
        if not phonepe_token:
            raise ValueError("PHONEPE_TOKEN is required but was empty")
        self._token = phonepe_token
        self._bookings: dict[str, dict] = {}
        self._counter = 0

    def _next_booking_id(self) -> str:
        self._counter += 1
        return f"TRV-{self._counter}"

    @staticmethod
    def _get_transport_type(option_id: str) -> str:
        prefix_map = {"BUS": "bus", "TRN": "train", "FLT": "flight"}
        prefix = option_id.split("-")[0] if "-" in option_id else ""
        return prefix_map.get(prefix, "unknown")

    async def book(
        self,
        option: dict,
        passenger_name: str,
        phone_number: str,
    ) -> dict:
        booking_id = self._next_booking_id()
        booking = {
            "booking_id": booking_id,
            "transport_type": self._get_transport_type(option["id"]),
            "option": option,
            "passenger_name": passenger_name,
            "phone_number": phone_number,
            "status": "pending",
            "payment_response": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }

        url = f"{PHONEPE_BASE_URL}/phonepe/pay/{self._token}"
        payload = {
            "booking_id": booking_id,
            "amount": option["price"],
            "passenger_name": passenger_name,
            "phone_number": phone_number,
            "option": option,
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload)

            if response.status_code >= 200 and response.status_code < 300:
                booking["status"] = "paid"
                booking["payment_response"] = response.json()
            else:
                booking["status"] = "payment_failed"
                booking["error"] = f"Payment failed (HTTP {response.status_code}): {response.text}"
                booking["payment_response"] = response.json()
        except Exception as e:
            booking["status"] = "payment_failed"
            booking["error"] = str(e)

        self._bookings[booking_id] = booking
        return booking

    def get_booking(self, booking_id: str) -> dict | None:
        return self._bookings.get(booking_id)
